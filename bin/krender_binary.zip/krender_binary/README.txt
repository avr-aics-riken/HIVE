- krender and KAnim binary (MacOSX and Linux)
2013.12.6

  1.Setup
  2.Run - krender
  3.Run - KAnim
  4.Compile shader
  5.備考


1. Setup
LSGLのGLSLコンパイラの設定が必要です．
glsl/glsl_config.py を編集してGLSL適切なコンパイラへのフルパスを設定してください．

mesa_glsl_compiler_path="/path/to/glslcompiler"

GLSLコンパイラの各プラットフォームバージョンはglsl/bin以下に格納されています．
  Mac  : glsl/bin/macosx64/glsl_compiler
  Linux: glsl/bin/linux64/glsl_compiler


2. Run - krender
GLSLコンパイラの設定が完了したらレンダリングを実行してみましょう．
それぞれの環境に合ったバイナリを選択します．
MacOSXの場合は macosxフォルダに移動します．

  $cd macosx

Linuxの場合は linuxフォルダに移動します．

  $cd linux

krenderを利用してレンダリングをします．
krenderはコンソールタイプのレンダラーです．
簡単に実行できるシェルスクリプトを用意しているので
以下のコマンドを実行してください．

  $sh rendering_scene.sh

正しくレンダリングできたら
output.jpgが生成され，bunny.objがレンダリングされると思います．
ここでbunnyがレンダリングされない場合は1.Setupの設定からやり直す必要があります．


3. Run - KAnim
KAnimを利用してレンダリングしてみます．
KAnimはWindowタイプのレンダラーです．
簡単に実行できるシェルスクリプトを用意しているので

  $sh run_KAnim.sh

を実行してください.
実行するとファイルを開くダイアログが表示されますので，
開きたいobj,stl,sph,scnファイルなどを選択してください．
(付属のファイルではbunny.objもしくはscene.scnを開く事ができます)
ファイルを開くと開いたファイルがウインドウにレンダリングされるはずです．

4. Compile shader
独自シェーダを利用したい場合にLSGLのGLSLコンパイラを利用して
シェーダのコンパイルを行います．

簡単にコンパイルする方法としてシェルスクリプトを用意しています．

  $sh compile_shader.sh

def_polygon.fragをコンパイルするようなサンプルになっています．
適宜編集しコンパイルしてみてください．


5. 備考
def_polygon.fragはデフォルトのポリゴン用シェーダです．
KAnimでobj,stlファイルを開く場合,sceneファイルで特にシェーダの指定が無い場合に
def_polygon.fragが利用されます．

def_volume.fragはデフォルトのポリゴン用シェーダです．
KAnimでvol,sphファイルを開く場合,sceneファイルで特にシェーダの指定が無い場合に
def_volume.fragが利用されます．



