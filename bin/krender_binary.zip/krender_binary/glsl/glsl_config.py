## Mac/linux

# linux
#mesa_glsl_compiler_path = "/home/username/krender_binary/glsl/bin/linux_x64/glsl_compiler"
# mac
mesa_glsl_compiler_path = "/Users/username/krender_binary/glsl/bin/macosx64/glsl_compiler"

cxx_compiler_path = "g++"
additional_compiler_options = ["-O2"]

###################

## K/FX10 cross
#mesa_glsl_compiler_path = "/home/ra000004/a03026/work/lsgl/glsl/bin/linux_x64/glsl_compiler"
#cxx_compiler_path = "FCCpx"
#additional_compiler_options = ["-Kfast"]

## Windows example.
#mesa_glsl_compiler_path = "z:/work/lsgl/glsl/bin/windows_x64/glsl_compiler.exe"
#cxx_compiler_path = "x86_64-w64-mingw32-g++.exe"
