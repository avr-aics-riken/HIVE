# import py2exe

from distutils.core import setup

setup(name='glslc',
      version='0.1',
      description='GLSL compiler',
      packages=['glslc'],
     )
