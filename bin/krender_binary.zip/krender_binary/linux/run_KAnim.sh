#!/usr/bin/sh

export LD_LIBRARY_PATH=`pwd`
export GLSL_COMPILER=`pwd`/../glsl/glslc
./KAnim
