#!/usr/bin/sh

export GLSL_COMPILER=`pwd`/../glsl/glslc
../glsl/glslc -o def_polygon.so def_polygon.frag
