KRender(web)/KRender/KAnim prebuild for MacOSX
====
2014.05.15

# Requires
- MacOSX 10.8.5
- node.js 0.10(http://nodejs.org) or higher

bundle GCC runtime version.

# Run
## run KRender(web)
    $sh run.sh
    
    ACCESS> http://localhost:8082/
    
## run KRender
	$./krender scene.scn
	
## run KAnim
	$./KAnim	    
    
# Limitation
現在は以下の制限があります.

1. OBJ, STL(binary)のみの読み込みに対応
2. アニメーションは未対応
3. Export sceneボタンを押した場合は，このディレクトリのscene.scnファイルに出力される
4. 任意の場所へのシーンファイルのエクスポートに対応していない
   - scene.scn内のモデルファイルは絶対パスで記述されている.
   - scene.scn を利用してkrenderでレンダリングする場合は，shaderディレクトリ内のシェーダファイルをscene.scnと同階層に手動でコピーする必要がある.

# Rendering by krender
KRender(web) でエクスポートしたscene.scn をkrender でレンダリングを行う.
(shaderディレクトリ内のshaderのコピーを忘れずに行う -> Limitation.4)

    $./krender scene.scn
    --> output.jpg
    
  