#include <node.h>
#include <v8.h>

#define CHECK_ARGS_NUM(args,num) \
	if (args.Length() < num) { \
		ThrowException(Exception::TypeError(String::New("Wrong number of arguments"))); \
		return scope.Close(Undefined()); \
	}

#define CHECK_ARG_IS_NUMBER(args,n) \
	if (!args[n]->IsNumber()) { \
		ThrowException(Exception::TypeError(String::New("Wrong argument #" #n " is not number."))); \
		return scope.Close(Undefined()); \
	}

#define CHECK_ARG_IS_STRING(args,n) \
	if (!args[n]->IsString()) { \
		ThrowException(Exception::TypeError(String::New("Wrong argument #" #n " is not string."))); \
		return scope.Close(Undefined()); \
	}
#define CHECK_ARG_IS_FUNCTION(args,n) \
	if (!args[n]->IsFunction()) { \
		ThrowException(Exception::TypeError(String::New("Wrong argument #" #n " is not function."))); \
		return scope.Close(Undefined()); \
	}

#define CHECK_ARG_IS_OBJECT(args,n) \
	if (!args[n]->IsObject()) { \
		ThrowException(Exception::TypeError(String::New("Wrong argument #" #n " is not object."))); \
		return scope.Close(Undefined()); \
	}

#define ARG_TO_NUMBER(args,n) args[n]->NumberValue()

inline std::string js_func_argString(const v8::Arguments& args, int n) {
	v8::Local<v8::String> strvar = args[n]->ToString(); \
	char strbuf[strvar->Utf8Length()+1];
	memset(strbuf, 0, strvar->Utf8Length()+1);
	strvar->WriteUtf8(strbuf,strvar->Utf8Length()+1);
	return std::string(strbuf);
}

#define ARG_TO_STRING(args,n) js_func_argString(args,n)

#define ARG_TO_OBJECT(args,n) node::Buffer::Data(args[n]->ToObject())

#define ARG_TO_FUNCTION(args,n) (Local<Function>::Cast(args[n]))

#define JS_FUNC_ARG0(FUNCNAME) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		FUNCNAME(); \
		return scope.Close(Undefined()); \
	}


#define JS_FUNC_ARG1(FUNCNAME,A1) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,1); \
		CHECK_ARG_IS_##A1(args,0); \
		FUNCNAME(ARG_TO_##A1(args,0)); \
		return scope.Close(Undefined()); \
	}


#define JS_FUNC_ARG2(FUNCNAME,A1,A2) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,2); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1)); \
		return scope.Close(Undefined()); \
	}


#define JS_FUNC_ARG3(FUNCNAME,A1,A2,A3) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,3); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		CHECK_ARG_IS_##A3(args,2); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1), ARG_TO_##A3(args,2)); \
		return scope.Close(Undefined()); \
	}


#define JS_FUNC_ARG4(FUNCNAME,A1,A2,A3,A4) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,4); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		CHECK_ARG_IS_##A3(args,2); \
		CHECK_ARG_IS_##A4(args,3); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1), ARG_TO_##A3(args,2), ARG_TO_##A4(args,3)); \
		return scope.Close(Undefined()); \
	}


#define JS_FUNC_ARG5(FUNCNAME,A1,A2,A3,A4,A5) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,5); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		CHECK_ARG_IS_##A3(args,2); \
		CHECK_ARG_IS_##A4(args,3); \
		CHECK_ARG_IS_##A5(args,4); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1), ARG_TO_##A3(args,2), ARG_TO_##A4(args,3), ARG_TO_##A5(args,4)); \
		return scope.Close(Undefined()); \
	}

#define JS_FUNC_ARG6(FUNCNAME,A1,A2,A3,A4,A5,A6) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,6); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		CHECK_ARG_IS_##A3(args,2); \
		CHECK_ARG_IS_##A4(args,3); \
		CHECK_ARG_IS_##A5(args,4); \
		CHECK_ARG_IS_##A6(args,5); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1), ARG_TO_##A3(args,2), ARG_TO_##A4(args,3), ARG_TO_##A5(args,4), ARG_TO_##A6(args,5)); \
		return scope.Close(Undefined()); \
	}

#define JS_FUNC_ARG9(FUNCNAME,A1,A2,A3,A4,A5,A6,A7,A8,A9) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		CHECK_ARGS_NUM(args,9); \
		CHECK_ARG_IS_##A1(args,0); \
		CHECK_ARG_IS_##A2(args,1); \
		CHECK_ARG_IS_##A3(args,2); \
		CHECK_ARG_IS_##A4(args,3); \
		CHECK_ARG_IS_##A5(args,4); \
		CHECK_ARG_IS_##A6(args,5); \
		CHECK_ARG_IS_##A7(args,6); \
		CHECK_ARG_IS_##A8(args,7); \
		CHECK_ARG_IS_##A9(args,8); \
		FUNCNAME(ARG_TO_##A1(args,0), ARG_TO_##A2(args,1), ARG_TO_##A3(args,2), \
			ARG_TO_##A4(args,3), ARG_TO_##A5(args,4), ARG_TO_##A6(args,5), \
			ARG_TO_##A7(args,6), ARG_TO_##A8(args,7), ARG_TO_##A9(args,8)); \
		return scope.Close(Undefined()); \
	}


#define JS_RET_FUNC_ARG0(FUNCNAME) \
	static Handle<Value> jsfunc_##FUNCNAME(const Arguments& args) { \
		HandleScope scope; \
		return scope.Close( FUNCNAME() ); \
	}


#define JS_REGISTER_FUNC(exports,FUNCNAME) \
	exports->Set(String::NewSymbol(#FUNCNAME),FunctionTemplate::New(jsfunc_##FUNCNAME)->GetFunction());

typedef v8::Local<v8::Function> jsCallbackFunc;

