#ifndef INCLUDE_MAIN_LIB_H
#define INCLUDE_MAIN_LIB_H

void MakeGLWindow(int w, int h, const char* respath);
void SceneLua(const char* luascript);
void OpenModel(const char* datafile);
void CloseModel();
void DrawGL();

void MouseLeftDown(int x, int y);
void MouseLeftUp(int x, int y);
void MouseRightDown(int x, int y);
void MouseRightUp(int x, int y);
void MouseMiddleDown(int x, int y);
void MouseMiddleUp(int x, int y);
void MouseMove(int x, int y);
void KeyDown(int key);
void KeyUp(int key);
unsigned int* GetColorBuffer();

void SetLookAt(float eye_x, float eye_y, float eye_z,
			   float tar_x, float tar_y, float tar_z,
			   float up_x,  float up_y, float up_z);
float* GetEye();
float* GetLookat();
float* GetUp();
float  GetFov();
void SetFov(float fov);

float  GetNear();
float  GetFar();
void SetNearFar(float nearVal, float farVal);

void SetPixelStep(int step);
int GetPixelStep();

bool SetRendererMode(const char* mode); // OPENGL or LSGL
const char* GetRendererMode();

#endif // INCLUDE_MAIN_LIB_H

