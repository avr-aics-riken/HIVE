#include <v8.h>
#include <node.h>
#include <uv.h>
#include <iostream>
#include <sys/time.h>
#include <node_buffer.h>
#include <string.h>

#include "main_lib.h"

#include "node_util.h"

using namespace v8;

class krender;
class renderData {
public:
	renderData(krender* render_, int w, int h, unsigned int* buf)
	: /*render(render_),*/ image(buf), width(w), height(h) {
	}
	
	~renderData() {
		cb_after.Dispose();
	}
	//krender* render;
	unsigned int* image;
	int width;
	int height;
	Persistent<Value> cb_after;
};

class krender : node::ObjectWrap
{
private:
	static void keydown(int key)             { KeyDown(key); }
	static void keyup(int key)               { KeyUp(key); }
	static void mouserightdown(int x, int y) { MouseRightDown(x,y); }
	static void mouserightup  (int x, int y) { MouseRightUp  (x,y); }
	static void mouseleftdown(int x, int y)  { MouseLeftDown(x,y); }
	static void mouseleftup  (int x, int y)  { MouseLeftUp  (x,y); }
	static void mousemiddledown(int x, int y){ MouseMiddleDown(x,y); }
	static void mousemiddleup  (int x, int y){ MouseMiddleUp  (x,y); }
	static void mousemove  (int x, int y)    { MouseMove  (x,y); }
	static void sceneLua(std::string s)
	{
		SceneLua(s.c_str());
	}
	static void addData(std::string s)
	{
		OpenModel(s.c_str());
	}
	static void loadModel(std::string s)
	{
		CloseModel();
		OpenModel(s.c_str());
	}
	static void closeModel()
	{
		CloseModel();
	}
	static void makeContext(int w, int h, const std::string& datapath)
	{
		MakeGLWindow(w,h,datapath.c_str());
	}

	
	static void AsyncRender(uv_work_t *req) {
		//printf("AsyncRender\n");
		renderData* ed = static_cast<renderData*>(req->data);
		const int w = ed->width;
		const int h = ed->height;
		unsigned int* buf = ed->image;
		//		printf("render(%d,%d,0x%X)\n",w,h,ed->image);
		//		internalRender(w,h,buf);
		unsigned int* cbuf = GetColorBuffer();
		memcpy(buf, cbuf, w*h*sizeof(int));
		// upsidedown
		for (int y = 0; y < h/2; ++y){
			for (int x = 0; x < w; ++x){
				const unsigned int t = buf[x + y * w];
				buf[x + y * w] = buf[x + (h - y - 1) * w];
				buf[x + (h - y - 1) * w] = t;
			}
		}
	}
	static void AfterRender(uv_work_t *req) {
		//printf("AfterRender\n");
		HandleScope scope;
		renderData* ed = static_cast<renderData*>(req->data);
		Local<Value> argv[] = {};
        Persistent<Function>::Cast(ed->cb_after)->Call(Context::GetCurrent()->Global(), 0, argv);
		delete ed;
    }
	static void renderCallback(int w, int h, char* p, jsCallbackFunc func)
	{
		const int width = w;
		const int height = h;
		unsigned int* buf = reinterpret_cast<unsigned int*>(p); //node::Buffer::Data(args[2]->ToObject()));
		//		printf("RenderReq(%d,%d,0x%X)\n",width, height, buf);
		uv_work_t *req = new uv_work_t;
		renderData* ed = new renderData(0, width, height, buf);
		ed->cb_after = Persistent<Function>::New(func);
		req->data = ed;
		uv_queue_work(uv_default_loop(), req, AsyncRender, (uv_after_work_cb)AfterRender);
	}
	
	static void lookAt(float eye_x, float eye_y, float eye_z,
					   float tar_x, float tar_y, float tar_z,
					   float up_x,  float up_y, float up_z)
	{
		SetLookAt(eye_x, eye_y, eye_z,
				  tar_x, tar_y, tar_z,
				  up_x,  up_y,  up_z);
	}
	
	static v8::Handle<v8::Value> getEye()
	{
		float* eye = GetEye();
		Handle<Array> array = Array::New(3);
		array->Set(0,v8::Number::New (eye[0]));
		array->Set(1,v8::Number::New (eye[1]));
		array->Set(2,v8::Number::New (eye[2]));
		return array;
	}
	static v8::Handle<v8::Value> getLookat()
	{
		float* look = GetLookat();
		Handle<Array> array = Array::New(3);
		array->Set(0,v8::Number::New (look[0]));
		array->Set(1,v8::Number::New (look[1]));
		array->Set(2,v8::Number::New (look[2]));
		return array;
	}
	static v8::Handle<v8::Value> getUp()
	{
		float* up = GetUp();
		Handle<Array> array = Array::New(3);
		array->Set(0,v8::Number::New (up[0]));
		array->Set(1,v8::Number::New (up[1]));
		array->Set(2,v8::Number::New (up[2]));
		return array;
	}
	static v8::Handle<v8::Value> getFov()
	{
		return v8::Number::New (GetFov());
	}
	static void setFov(float fov)
	{
		SetFov(fov);
	}
	
	static v8::Handle<v8::Value> getNear()
	{
		return v8::Number::New (GetNear());
	}
	static v8::Handle<v8::Value> getFar()
	{
		return v8::Number::New (GetFar());
	}
	static void setNearFar(float nearVal, float farVal)
	{
		SetNearFar(nearVal,farVal);
	}
	
	static void setPixelStep(int step)
	{
		SetPixelStep(step);
	}
	static v8::Handle<v8::Value> getPixelStep()
	{
		return v8::Number::New (GetPixelStep());
	}
	
	static void setRendererMode(const std::string& mode) // "OPENGL" or "LSGL"
	{
		SetRendererMode(mode.c_str());
	}
	
	static v8::Handle<v8::Value> getRendererMode()
	{
		return v8::String::New (GetRendererMode());
	}

	JS_FUNC_ARG1(keydown,NUMBER)
	JS_FUNC_ARG1(keyup,NUMBER)
	JS_FUNC_ARG2(mouserightdown,NUMBER,NUMBER)
	JS_FUNC_ARG2(mouserightup,NUMBER,NUMBER)
	JS_FUNC_ARG2(mouseleftdown,NUMBER,NUMBER)
	JS_FUNC_ARG2(mouseleftup,NUMBER,NUMBER)
	JS_FUNC_ARG2(mousemiddledown,NUMBER,NUMBER)
	JS_FUNC_ARG2(mousemiddleup,NUMBER,NUMBER)
	JS_FUNC_ARG2(mousemove,NUMBER,NUMBER)
	JS_FUNC_ARG1(sceneLua,STRING)
	JS_FUNC_ARG1(addData,STRING)
	JS_FUNC_ARG1(loadModel,STRING)
	JS_FUNC_ARG0(closeModel)
	JS_FUNC_ARG3(makeContext,NUMBER,NUMBER,STRING)
	JS_FUNC_ARG4(renderCallback,NUMBER,NUMBER,OBJECT,FUNCTION)

	JS_FUNC_ARG9(lookAt,NUMBER,NUMBER,NUMBER,NUMBER,NUMBER,NUMBER,NUMBER,NUMBER,NUMBER)
	JS_FUNC_ARG1(setRendererMode,STRING)
	JS_FUNC_ARG1(setPixelStep,NUMBER)
	JS_FUNC_ARG2(setNearFar,NUMBER,NUMBER)

	JS_RET_FUNC_ARG0(getPixelStep)
	JS_RET_FUNC_ARG0(getEye)
	JS_RET_FUNC_ARG0(getLookat)
	JS_RET_FUNC_ARG0(getUp)
	JS_RET_FUNC_ARG0(getFov)
	JS_RET_FUNC_ARG0(getFar)
	JS_RET_FUNC_ARG0(getNear)
	JS_RET_FUNC_ARG0(getRendererMode)

public:
	static void init(Handle<Object> exports) {
		JS_REGISTER_FUNC(exports,makeContext);
//		JS_REGISTER_FUNC(exports,render);
		JS_REGISTER_FUNC(exports,renderCallback);
		JS_REGISTER_FUNC(exports,sceneLua);
		JS_REGISTER_FUNC(exports,addData);
		JS_REGISTER_FUNC(exports,loadModel);
		JS_REGISTER_FUNC(exports,closeModel);
		JS_REGISTER_FUNC(exports,mouseleftdown);
		JS_REGISTER_FUNC(exports,mouseleftup);
		JS_REGISTER_FUNC(exports,mouserightdown);
		JS_REGISTER_FUNC(exports,mouserightup);
		JS_REGISTER_FUNC(exports,mousemiddledown);
		JS_REGISTER_FUNC(exports,mousemiddleup);
		JS_REGISTER_FUNC(exports,mousemove);
		JS_REGISTER_FUNC(exports,keydown);
		JS_REGISTER_FUNC(exports,keyup);
		
		JS_REGISTER_FUNC(exports,lookAt)
		JS_REGISTER_FUNC(exports,setRendererMode)
		JS_REGISTER_FUNC(exports,setPixelStep)
		JS_REGISTER_FUNC(exports,setNearFar)

		JS_REGISTER_FUNC(exports,getPixelStep);
		JS_REGISTER_FUNC(exports,getEye);
		JS_REGISTER_FUNC(exports,getLookat);
		JS_REGISTER_FUNC(exports,getUp);
		JS_REGISTER_FUNC(exports,getFov);
		JS_REGISTER_FUNC(exports,getFar);
		JS_REGISTER_FUNC(exports,getNear);
		JS_REGISTER_FUNC(exports,getRendererMode);
	}
};

extern "C"
{
	NODE_MODULE(krender, krender::init)
}

