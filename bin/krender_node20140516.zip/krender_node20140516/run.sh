cd `pwd`

#SET PATH to libLSGL.so(for Linux)
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH

#SET PATH to libLSGL.dylib(for MacOSX)
DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:`pwd`
export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH

#set GLSL_COMPILER at environmet setting or define here.
GLSL_COMPILER=`pwd`/glsl/glslc
export GLSL_COMPILER=$GLSL_COMPILER

node kvtools.js