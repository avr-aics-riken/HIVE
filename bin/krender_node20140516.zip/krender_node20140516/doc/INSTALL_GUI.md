
# krender for node.js
## 準備

以下のソフトウェアをインストールする.

- node.js (v0.10以上)のインストール
 
    以下のURLからインストールする: <http://nodejs.org>
    
- node-gypのインストール

        $npm install -g node-gyp

- bowerのインストール

        $npm install -g bower

- 必要な node モジュールのインストール (Socket.io / WebSocket)

        $cd krender_node
        $npm install

- 必要な JS モジュールのインストール (ace / jquery / etc)

.bowerrc でカスタムインストールディレクトリを設定していないことを確認し,

        $cd krender_node/root
        $bower install
    
- libLSGLES.soのビルド

    LSGLをビルドする

- libkrender.aのビルド

        $cd KAnimRender
        $open KAnimRender.xproj    
  
   or 
   
        $cd KAnimRender
        make -f Makefile_lib
    
## krender.nodeをビルド

    $sh build.sh

libLSGL.dylib/libLSGL.so を krender_node/ 以下に配置しておく必要があります.(シンボリックリンク可)
    
## サーバー実行

    $sh run.sh
    
および 

    $open http://localhost:8082
    
としてサーバーにアクセスする.
   
## 設定

必要に応じて以下を設定する．

サーバー設定:

デフォルトシェーダのパスを設定する

- server.js:

        var shaderspath = "/path/to/shader_dir"



## 制約

- 同時セッション数は1セッションのみ対応
