// Edit minN and maxN, then invoke
//
//   $ node zombie_glsl_sandbox_grabber.js
//

// Query range
var minN = 1 
var maxN = 5000

var Browser = require("zombie");
var assert = require("assert");
var fs = require('fs');
sprintf = require('sprintf').sprintf
require('shelljs/global');

var baseurl = 'http://glsl.heroku.com/item/';


function grab(i) {

  if (i >= maxN) {
    return;
  }

  console.log("getting " + i);

  var url = baseurl + i
  Browser.visit(url, function (e, browser) {

    if (e) {
      console.log(e)
    } else {

      // Return value is JSON GLSL code. Sometime it is broken.
      try { 
        var jsoncode = JSON.parse(browser.text())
        console.log(jsoncode);

        var code = jsoncode["code"]

        var filename = sprintf("glsl_sandbox_%05d.frag", i)
        console.log(filename)
        fs.writeFileSync(filename, code);

      } catch (err) {
        console.log(url + ":" + err);

      }

      grab(i+1);

    }

  });
}

grab(minN)



