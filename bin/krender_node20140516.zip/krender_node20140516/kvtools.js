var	KVToolsCore = require('./root/KVToolsCore'),
	ShaderEditor = require('./root/ShaderEditor'),
	io = require('socket.io'),
	http = require('http'),
	filedialog = require('./root/filedialog'),
	fs = require('fs');

var mode = process.argv.slice(2);
console.log("mode="+mode);

var server = http.createServer(function(request, response) {
	var filePath = null;
	if (request.url == '/') {
		if (mode == 'shader')
			filePath = './root/shader.html';
		else
			filePath = './root/index.html';
	} else {
		filePath = './root' + request.url;
	}
	
	console.log((new Date()) + " Received request for " + request.url);
	var data = fs.readFile(filePath, function(response){ return function(err,data){
		if (err){
			response.end("Bad request.");
			return;
		}
		response.end(data);
	}}(response));
});

// Core
var core = new KVToolsCore();


var io = io.listen(server);
io.set('log level', 1);

io.sockets.on('connection', function(socket){
	console.log('socket.io connected:'+socket.id);
	
	// Core Event
	core.RegisterSocketIO(socket);
	filedialog.SocketEvent(socket,'KVToolsObjectDialog');
	ShaderEditor.SocketEvent(socket);
	
	socket.on('disconnect', function(){
		console.log("disconnect:"+socket.id);
	});
});


server.listen(8082, function() {
	console.log((new Date()) + " Server is listening on port 8082");
});


