function includetemplate(filename){
	var xhr = new XMLHttpRequest();
	xhr.open('GET', filename, true);
	xhr.onreadystatechange = function(){
		if (xhr.readyState === 4 && xhr.status === 200){
			var newelem = document.createElement("xtemplate");
			newelem.setAttribute('style','display:none;');
			newelem.innerHTML = xhr.responseText;
			document.body.appendChild(newelem);
		}
		if (xhr.readyState === 4 && xhr.status === 0){
			var newelem = document.createElement("xtemplate");
			newelem.setAttribute('style','display:none;');
			newelem.innerHTML = xhr.responseText;
			document.body.appendChild(newelem);
		}
	};
	xhr.send(null);
}
