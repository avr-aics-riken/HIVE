var ServerImagerPort = 9000;

if (typeof window === 'undefined') { // node.js
	
	var WebSocketServer = require('websocket').server,
		http = require('http');
		
	var ServerImager = function(renderFunc){
		this.width  = 1;
		this.height = 1;
		this.buffer = new Buffer(this.width * this.height * 4);
		
		this.GetBuffer = function(){
			return this.buffer;
		}
		
		this.connection = null;
		this.renderFunc = renderFunc;
		
		var myhttpserver = http.createServer(function(request, response) {
			response.end('bad access');
		});

		myhttpserver.listen(ServerImagerPort, function() {
			console.log((new Date()) + "ServerImager HttpServer is listening on port "+ServerImagerPort);
		});

		
		this.wsServer = new WebSocketServer({
			httpServer: myhttpserver,
			maxReceivedFrameSize: 0x1000000, // more receive buffer!! default 65536B
			autoAcceptConnections: false
		});

		this.Render = function(){
			if (this.renderFunc)
				this.renderFunc(this.width, this.height);
		}
		
		this.reqFunc = function(thisptr){
			return function(request){
				var connection = request.accept(null, request.origin);
				thisptr.connection = connection;
				console.log((new Date()) + " ServerImager Connection accepted.");
				connection.on('message', function(message) {
					var cmd = message.utf8Data.split(':');
					if (cmd[0] == 'ServerImager-RENDER'){
						var w = parseInt(cmd[1]),
							h = parseInt(cmd[2]);
						if (thisptr.width != w || thisptr.height != h){
							console.log('resize:',w,h)
							thisptr.width  = w;
							thisptr.height = h;
							delete thisptr.buffer;
							thisptr.buffer = new Buffer(w*h*4);
						}
						
						if (thisptr.renderFunc)
							thisptr.renderFunc(w, h);
						
						//thisptr.connection.send(thisptr.buffer); // Send
						//thisptr.SendImage(thisptr.buffer);
					}
				});
			}
		}(this);
		this.wsServer.on('request', this.reqFunc);
		
		this.SendImage = function(buf){
			//this.connection.send(buf); // Send
			this.connection.sendBytes(buf);
		}
	}

	module.exports = ServerImager;
	
}else{ // client
	
	var ServerImager = function(recvFunc,connectedFunc){
		this.recvFunc = recvFunc;
		this.connectedFunc = connectedFunc;
		var addr = 'ws://'+ document.location.hostname+':'+ServerImagerPort;
		console.log('ServerImager> '+addr);
		this.socket = new WebSocket(addr);
		this.socket.binaryType = 'arraybuffer';
		this.socket.onopen = function(thisptr){ return function() {
			if (thisptr.connectedFunc)
				thisptr.connectedFunc();
		}}(this);
		this.socket.onmessage = function(thisptr){ return function(buffer){
			//console.log('recv server image');
			if (thisptr.recvFunc)
				thisptr.recvFunc(buffer);
		}}(this);
	}
	ServerImager.prototype.Render = function(w,h){
		//console.log('Render:',w,h);
		this.socket.send('ServerImager-RENDER:'+w+':'+h);
	}
	
	
}