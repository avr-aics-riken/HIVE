if (typeof(window) === 'undefined') { // node.js
  
  var glob = require('glob');
  var exec = require('child_process').exec;
  var fs = require('fs');
  var path = require('path');
  var shaderBasePath = path.join(__dirname, '../shader'); // Assume current dir is krender/root. @todo: move kvtools.js


  // List shader file in the specified directory.
  function ListUpShaderFiles(callback) {
    var options = {}
    glob(path.join(shaderBasePath, "*.frag"), function(err, files) {
			if (err) {
				console.log("glob err:" + err);
			}
			
			var validFiles = []
			for (var i = 0; i < files.length; i++) {
				var pos = files[i].search("tmp.frag");
				if ((pos > -1) && ((pos + "tmp.frag".length) == files[i].length)) { // last match
					// tmp shader file. ignore
				} else {
					validFiles.push({'shadername':path.basename(files[i]), 'icon-filepath':"test-icon.jpg"}); // get basefilename
				}
				
			}
			
      console.log(validFiles);
      
			callback(validFiles);
    });
   
  }

  function ExtractCompilerError(log) {
    var infos = {}
    infos['results'] = []
    infos['log'] = log

    lines = log.split(/(\r?\n)/g);
    //console.log('lines:' + lines);

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i]
      //console.log('line:' + line);
      var reRange = /(\d+):(\d+)\((\d+)\): (\w.+): (.*)/
      var ret = reRange.exec(line)  

      if (ret != null) {
        var lineno = ret[2]
        var column = ret[3]
        var err = ret[5]

        var info = {'lineno':lineno, 'column':column, 'error': err}
        infos['results'].push(info);
      }

      //console.log(ret);
    }
    return infos
  }

  // Compile shader code and return its log to callback
  function CompileShader(shadername, /* string */ code, callback) {

    // Get GLSL compiler from ENV.
    var glslc = process.env.GLSL_COMPILER
    if (glslc == undefined) {
      console.log('GLSL_COMPILER is not set.');
      callback({'status': 'error', 'log': 'GLSL_COMPILER is not set.'});
    }

    if (shadername == undefined) {
      var tmpfilename = path.join(shaderBasePath, 'input.tmp.frag');
    } else {
      var tmpfilename = path.join(shaderBasePath, shadername + 'tmp.frag');
    }

    // Write temporary file
    fs.writeFileSync(tmpfilename, code);

    var cmd = glslc + ' ' + tmpfilename;
    var c = exec(cmd, function(error, stdout, stderr) {
      console.log('stdout: ' + stdout);
      console.log('stderr: ' + stderr);
      if (error) {
        console.log('error: ' + error);
        callback({'status': 'compile_error', 'info': ExtractCompilerError(stdout)});
      } else {
        callback({'status': 'ok'});
      }
    });
  }

	var shadereditor = { SocketEvent:function(socket){

		socket.on('shaderEditorEvent', function(data) {
			console.log(data);
		});

    socket.on('shaderEditorRefreshShaderBrowser', function(/* JSON str */ data) {
      ListUpShaderFiles(function(files) {
				//var t = window.getElementByName("shader-browser");
				//console.log(t);
				socket.emit('shaderBrowserData', JSON.stringify(files));
			});
    });

    socket.on('shaderEditorFileChanged', function(/* JSON str */ data) {
      var j = JSON.parse(data);
      console.log('filename:' + j['filename']);

      var filepath = path.join(shaderBasePath, j['filename'])
      console.log('filepath:' + filepath);

      fs.readFile(filepath, 'utf8', function(error, data) {
        if (err || (data == undefined)) {
          var stat = 'error'
          var err  = 'File not found or read error:' + j['filename'];

          console.log(err);

          var msg = { 'status': stat, 'error': err }
          socket.emit('shaderEditorCode', JSON.stringify(msg));
        } else {
          console.log('code:' + data);
          var msg = { 'status': 'ok', 'shadername': j['filename'], 'code': data }
          socket.emit('shaderEditorCode', JSON.stringify(msg));
        }
      });

    });

    socket.on('shaderEditorCodeUpdate', function(/* JSON str */ data) {
      var j = JSON.parse(data);
      console.log('shadername:' + j['shadername']);
      console.log('code:' + j['code']);

      CompileShader(j['shadername'], j['code'], function(ret) {
        console.log('ret_xyz=' + JSON.stringify(ret));
        socket.emit('shaderEditorCompileStatus', JSON.stringify(ret));
      });
    });
	}}
	
	module.exports = shadereditor;
	
} else { // client side js
	
	var shadereditor = {}
	
}
