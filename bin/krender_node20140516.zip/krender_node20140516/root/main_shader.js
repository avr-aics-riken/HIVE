var wid,hei;
var core;

var lastEditedMsec = (new Date).getTime();
var editorChanged = false;
var hasChanged = false;
var gEditorChangedTick = 200; // in milliseconds

function shaderIdleTick(/* ace editor = */ editor, /* socket */ socket) {
  var msec = (new Date).getTime();

  if (hasChanged && ((msec - lastEditedMsec) > gEditorChangedTick)) {
    console.log("update");
    hasChanged = false;
    lastEditedMsec = msec;

		var shadername = document.getElementById('shadername').value;
    msg = { 'shadername' : shadername
          , 'code' : editor.getValue()
          }

    //console.log(socket);
    socket.emit('shaderEditorCodeUpdate', JSON.stringify(msg));

  }

  window.setTimeout(function() { shaderIdleTick(editor, socket); }, gEditorChangedTick);
}

function updateShaderCode(code) {
  var editor = ace.edit("editor");
  editor.getSession().setValue(code);
}

function shaderEditorInit(/* socket.io */ socket) {

  //
  // Setup ACE editor
  //
  console.log(document.getElementById('editor'))
  var editor = ace.edit("editor");
  //editor.setTheme("ace/theme/twilight");
  editor.setTheme("ace/theme/tomorrow_night_bright");
  editor.setOption("maxLines", 25);
  editor.setOption("minLines", 25);
  //editor.setAutoScrollEditorIntoView();
  document.getElementById('editor').style.fontSize='15px';
  document.getElementById('editor').style.fontFamily="'Inconsolata', sans-serif"

  // Or read shader code from somewhere.
  editor.getSession().setValue('#ifdef GL_ES\nprecision mediump float;\n#endif\n\nvoid main(void) {\n  gl_FragColor = vec4(1,1,1,1);\n}');
  editor.getSession().setMode("ace/mode/glsl");
  editor.getSession().setTabSize(2)
  editor.getSession().setUseSoftTabs(true);
  editor.getSession().setUseWrapMode(true);

  var statusWindow = ace.edit("status-window");
  statusWindow.setTheme("ace/theme/twilight");
  statusWindow.setOption("maxLines", 8);
  statusWindow.setOption("minLines", 8);
  statusWindow.renderer.setShowGutter(false);
  //editor.setAutoScrollEditorIntoView();
  document.getElementById('status-window').style.fontSize='15px';
  document.getElementById('status-window').style.fontFamily="'Inconsolata', sans-serif"
  statusWindow.getSession().setValue("OK");
  statusWindow.getSession().setMode("ace/mode/glsl");
  statusWindow.getSession().setTabSize(2)
  statusWindow.getSession().setUseSoftTabs(true);
  statusWindow.getSession().setUseWrapMode(true);
  statusWindow.setReadOnly(true);


  editor.getSession().on('change', function(e) {
    hasChanged = true;
    lastEditedMsec = (new Date).getTime();

    //console.log("change");
  });

  window.setTimeout(function() { shaderIdleTick(editor, socket); }, gEditorChangedTick);

}

document.oncontextmenu = function(e){ return false }

window.onload = function() {
	kvtoolsUI_init();

  // ACE editor marker needs to be explicitly managed by app
  var editorMarkers = []


	// render canvas size
	wid = 300;
	hei = 300;
	document.getElementById('result').width  = wid;
	document.getElementById('result').height = hei;
	document.getElementById('tmp').width     = wid;
	document.getElementById('tmp').height    = hei;
	
	function renderedFunc(buf){
		var buffer = new Uint8Array(buf.data);
		var rc = document.getElementById('result');
		var tcan = document.getElementById('tmp')
		var rctx = rc.getContext('2d');
		var tctx = tcan.getContext("2d");
		var rimageData = tctx.createImageData(wid, hei);
		var pixels = rimageData.data;
		pixels.set(buffer, 0, buffer.length);
		rctx.fillRect(0, 0, rc.width, rc.height);
		tctx.putImageData(rimageData, 0, 0);
		rctx.drawImage(tcan, 0, 0);
	}
	
  //
  // Socket.io
  //
	var socket = io.connect();
	socket.on('connect',function(){
		console.log('socket.io connected');

    // Request shader browser reflesh
    socket.emit('shaderEditorRefreshShaderBrowser', "");
	});

	// Shader brower update request from the server
	socket.on('shaderBrowserData', function(/* JSON str */ msg) {
		var files = JSON.parse(msg);
		
		// Assume msg is list type.
		
		for (var i = 0; i < files.length; i++) {
			console.log('file:' + files[i]);
		}
		
		//var t = window.getElementById('shader-browser');

		var rr = $("#shader-browser table")

		// Remove existing list.
		rr.empty();

		// Append shader file item
		for (var i = 0; i < files.length; i++) {
			var tag = '<tr><td><img src="' + files[i]['icon-filepath'] + '" width=64 height=64>' + files[i]['shadername'] + '</td></tr>'; 
			rr.append(tag);
		}
		
		// Install event to table row
		$(function(){
    	$("#shader-browser tr td").click(function(event) {
				// text() is shader filename.
				var shadername = $(this).text();

			  // de-Highlight previos item.				
				$("#shader-browser tr td").each(function() {
					$(this).css('background-color', 'rgba(0,0,0,0)');
				});
								
				// Highlight selected item.
				$(this).css('background-color', 'rgba(128,1,0,0.5)');
				
				// Save shader filename.
				document.getElementById('shadername').value = shadername;
				
				// Notify the server for shader file changed.
    		var msg = { 'filename': shadername }
    		socket.emit('shaderEditorFileChanged', JSON.stringify(msg));
				
    });
});
		
	});
						
  // Shader code from the server.
  socket.on('shaderEditorCode', function(/* JSON str */ msg) {
    var j = JSON.parse(msg);
    //console.log('shdcode:' + j['code']);
    if (j['status'] == 'ok') {
      updateShaderCode(j['code']);
    } else {
      console.log('code err:' + msg['error']);
    }
  });

  // Shader compile result from the server.
  socket.on('shaderEditorCompileStatus', function(/* JSON str */ msg) {

    var j = JSON.parse(msg);

    // First remove markers and clear annotations
    var editor = ace.edit("editor");

    for (var i = 0; i < editorMarkers.length; i++) {
      editor.getSession().removeMarker(editorMarkers[i]);
    }
    editorMarkers = []
    editor.getSession().clearAnnotations();

    if (j['status'] == 'compile_error') {

      var results = j['info']['results']
      var annotations = []

      var range = ace.require('ace/range').Range;

      for (var i = 0; i < results.length; i++) {

        var ret = results[i];

        var lineno = ret['lineno']-1
        var column = ret['column']

        var annotation = {
                        row: lineno,
                        column: column,
                        text: ret['error'],
                        type: 'error'
                        }
        annotations.push(annotation);

        var r = new range(lineno, column, lineno, 80);
        var marker = editor.getSession().addMarker(r, 'error', "line");
        editorMarkers.push(marker);
      }

      editor.getSession().setAnnotations(annotations);

    }

    // Update status window
    var statusWindow = ace.edit("status-window");
    if (j['status'] == 'ok') {
      statusWindow.getSession().setValue("OK")
			
			// Set shader
			var shadername = document.getElementById('shadername');
			console.log(shadername.value);
			core.SetShader('teapot',shadername.value + 'tmp.frag'); // Use tmp filename
			
    } else {
      // Show compile log to statusWindow.
      var info = j['info'];
      statusWindow.getSession().setValue(info['log'])
    }

  });

  //
  // --
  //
	
	core = new KVToolsCore(socket, wid, hei, renderedFunc);
	
	// Load model
	core.LoadModel('./teapot.obj','teapot');
	
	// Events
	var rmode = "OPENGL";
	$('#rendermodebtn').click(function(){
		if (rmode === "OPENGL"){
			rmode = "LSGL";
		} else {
			rmode = "OPENGL";
		}
		core.SetRenderMode(rmode);
	});

	$('#shaderchangebtn').click(function(){
		var shadername = document.getElementById('shadername');
		console.log(shadername.value);
		core.SetShader('teapot',shadername.value);

    // Notify the server for shader file changed.
    var msg = { 'filename': shadername.value }
    socket.emit('shaderEditorFileChanged', JSON.stringify(msg));
	});

  // Init shader editor and browser.
  shaderEditorInit(socket);
	
	var view = document.getElementById('result');
	view.addEventListener('mousedown', function(e){
		var press = true;
		e.preventDefault();
		e.stopPropagation();
		console.log(e.button);
		if (e.button == 0)
			core.Mouse('mouseleftdown',e.clientX,e.clientY);
		else if (e.button == 1)
			core.Mouse('mousemiddledown',e.clientX,e.clientY);
		else if (e.button == 2)
			core.Mouse('mouserightdown',e.clientX,e.clientY);
				
		var mmove = function(e){
			if (press){
				core.Mouse('mousemove',e.clientX,e.clientY);
				core.Render(wid,hei);
			}
		}
		var mup = function(e){
			document.removeEventListener('mousemove',mmove);
			document.removeEventListener('mouseup',mup);
			press = false;
			core.Mouse('mouseleftup',e.clientX,e.clientY);
			core.Mouse('mousemiddleup',e.clientX,e.clientY);
			core.Mouse('mouserightup',e.clientX,e.clientY);
		}
		document.addEventListener('mousemove', mmove);
		document.addEventListener('mouseup', mup);

	});
}

