if (typeof(window) === 'undefined') { // node.js

	var objcount = 0;
	var path = require('path'),
		ServerImager = require('./ServerImager'),
		render = require(__dirname + '/../build/Release/krender'),
		fs = require('fs');
	
	//var shaderspath = "/Users/kioku/git/lsgl_github/app/KAnimRender"
	//var shaderspath = __dirname + '/../..';
	
	var shaderspath = __dirname + '/../shader'; // relative path from this file.

	var KVToolsCore = function(){
		this.r_w = 0;
		this.r_h = 0;
		this.rendering = false;

		this.socket = null;
		this.objProperty = {};
		
		var core = this;
		function renderFunc(w,h){
			if (core.rendering)
				return;
			core.rendering = true;

			var buf = this.GetBuffer();
			if (core.r_w != w || core.r_h != h){
				console.log('create context',w,h);
				render.makeContext(w,h,shaderspath);
				render.setPixelStep(1);
				core.r_w = w;
				core.r_h = h;
			}
			render.renderCallback(w,h,buf, function(si,buf){return function(){
				si.SendImage(buf);
				core.rendering = false;
			}}(this,buf));
		}
		this.simage = new ServerImager(renderFunc);
	}
	KVToolsCore.prototype.Render = function(){
		this.simage.Render();
	}
	KVToolsCore.prototype.ResizeRender = function(w,h){
		this.simage.Resize(w,h);
	}
	
	KVToolsCore.prototype.NewObject = function(name,datapath){
		
		this.objProperty[name] = {
			translation:[0,0,0],
			rotation:[0,0,0],
			scale:[1,1,1],
			color:[1,1,1,1],
			path:datapath,
			shader:'def_polygon.frag'
		}
	}
	KVToolsCore.prototype.DeleteObject = function(name,datapath){
		delete this.objProperty[name];
	}

	KVToolsCore.prototype.DeleteAllObjects = function(name,datapath){
		this.objProperty = {};
	}
	
	KVToolsCore.prototype.RegisterSocketIO = function(socket){
		this.socket = socket;
		socket.on('message', function(message) {
			
		});
		
		socket.on('KVToolsCore-Loadmodel',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name;
			if (data.name == undefined)
				name = 'object'+objcount;
			else
				name = data.name;
			var datapath = data.path;
			var luasrc;
			var ext = path.extname(datapath).toLowerCase();
			var tarModel = ''
			if (ext === '.obj') {
				luasrc = 'local objdata = OBJLoader();';
				tarModel = 'PolygonModel';
			} else if (ext === '.stl') {
				luasrc = 'local objdata = STLLoader();';
				tarModel = 'PolygonModel';
			} else if (ext === '.vol') {
				luasrc = 'local objdata = VOLLoader();';
				tarModel = 'VolumeModel';
			} else if (ext === '.sph') {
				luasrc = 'local objdata = SPHLoader();';
				tarModel = 'VolumeModel';
			} else if (ext === '.lpt') {
				luasrc = 'local objdata = LPTLoader();';
				tarModel = 'ParticleModel';
			} else {
				console.log('Unsupported data format:'+ext);
				return;
			}
			
			console.log("Type="+tarModel, datapath);
			
			luasrc += 'objdata:Load("'+datapath+'");';
			if (tarModel === 'PolygonModel'){
				luasrc += 'local mdl = PolygonModel();';
				luasrc += 'mdl:Create(objdata:GetPosition(), objdata:GetNormal(), objdata:GetMaterial(), objdata:GetIndex());';
				luasrc += 'mdl:SetShader("'+shaderspath+'/def_polygon.frag");';
			}else if (tarModel === 'VolumeModel'){
				luasrc += 'local mdl = VolumeModel();';
				luasrc += 'mdl:Create(objdata:GetWidth(), objdata:GetHeight(), objdata:GetDepth(), objdata:GetComponent(), objdata:GetBuffer());';// TODO
				luasrc += 'mdl:SetShader("'+shaderspath+'/def_volume.frag");';
			}else if (tarModel === 'ParticleModel'){
				luasrc += 'local mdl = ParticleModel();';
				console.log("TODO:ParticleModel func");
				//luasrc += 'mdl:Create(objdata:GetPosition(), objdata:GetNormal(), objdata:GetMaterial(), objdata:GetIndex());';// TODO
				luasrc += 'mdl:SetShader("'+shaderspath+'/def_point.frag");';
			} else {
				console.log('Unsupported model type:'+tarModel);
				return;
			}
			luasrc += 'print("metatable=",getmetatable(mdl));';
			luasrc += 'local c = Core();';
			luasrc += 'c:AddRenderObject("'+name+'",mdl);';
			render.sceneLua(luasrc);
			objcount++;

			core.NewObject(name,datapath);
			core.SyncObjectList();
			
			core.Render();
		}}(this));
		socket.on('KVToolsCore-RemoveModel',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			console.log('REMOVE:'+name);
			var luasrc = 'Core():RemoveRenderObject("'+name+'");';
			render.sceneLua(luasrc);

			core.DeleteObject(name);
			core.SyncObjectList();
			
			core.Render();
		}}(this));
		
		socket.on('KVToolsCore-RemoveAllModels',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.closeModel();
			
			core.DeleteAllObjects();
			core.SyncObjectList();
			
			//core.Render();
		}}(this));
		
		socket.on('KVToolsCore-Transform', function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name,
				tx = data.translate_x,
				ty = data.translate_y,
				tz = data.translate_z,
				rx = data.rotate_x,
				ry = data.rotate_y,
				rz = data.rotate_z,
				sx = data.scale_x,
				sy = data.scale_y,
				sz = data.scale_z;
			var luasrc = 'local obj = Core():GetRenderObjectByName("'+name+'"); \
						if (obj) then \
							obj:SetTranslate('+tx+','+ty+','+tz+') \
							obj:SetRotate('+rx+','+ry+','+rz+') \
							obj:SetScale('+sx+','+sy+','+sz+') \
						end';
			render.sceneLua(luasrc);

			core.objProperty[name].translation = [tx,ty,tz];
			core.objProperty[name].rotation    = [rx,ry,rz];
			core.objProperty[name].scale       = [sx,sy,sz];
				
			core.SyncObjectList();
			core.Render();
		}}(this));
		
		socket.on('KVToolsCore-mousecommand',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var cmd = data.event;
			var x = data.x;
			var y = data.y;
			if(cmd == "mouseleftdown") {
				//console.log('mouseleftdown('+x+","+y+")");
				render.mouseleftdown(x,y);
			} else if(cmd == "mouseleftup") {
				//console.log('mouseleftup('+x+","+y+")");
				render.mouseleftup(x,y);
			} else if(cmd == "mouserightdown") {
				//console.log('mouserightdown('+x+","+y+")");
				render.mouserightdown(x,y);
			} else if(cmd == "mouserightup") {
				//console.log('mouserightup('+x+","+y+")");
				render.mouserightup(x,y);
			} else if(cmd == "mousemiddledown") {
				//console.log('mousemiddledown('+x+","+y+")");
				render.mousemiddledown(x,y);
			} else if(cmd == "mousemiddleup") {
				//console.log('mousemiddleup('+x+","+y+")");
				render.mousemiddleup(x,y);
			} else if(cmd == "mousemove") {
				//console.log('mousemove('+x+","+y+")");
				render.mousemove(x,y);
			}
		}}(this));
		
		socket.on('KVToolsCore-ChangeColor',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var luasrc = 'local obj = Core():GetRenderObjectByName("'+name+'"); \
						if (obj) then \
							obj:SetVec4("color",'+data.r+','+data.g+','+data.b+','+data.a+') \
						end';
			render.sceneLua(luasrc);

			core.objProperty[name].color = [data.r, data.g, data.b, data.a];

			core.SyncObjectList();
			core.Render();
		}}(this));

		
		socket.on('KVToolsCore-SetShader',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var shader = data.shader;
			console.log('SET shader>'+name +':'+shader);
			var luasrc = 'local obj = Core():GetRenderObjectByName("'+name+'"); \
						if (obj) then \
							obj:SetShader("'+shaderspath+'/'+shader+'") \
						end';
			render.sceneLua(luasrc);

			core.objProperty[name].shader = shader;

			core.SyncObjectList();
			core.Render();
		}}(this));

		socket.on('KVToolsCore-RenderMode',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.setRendererMode(data.mode);
			core.Render();
		}}(this));

		socket.on('KVToolsCore-SetPixelStep',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.setPixelStep(parseInt(data.step));
			core.Render();
		}}(this));

		socket.on('KVToolsCore-SyncObjectList',function(core){ return function(sdata){
			core.SyncObjectList();
		}}(this));

		socket.on('KVToolsCore-RequestShaderList',function(core){ return function(sdata){
			core.SyncShaderList();
		}}(this));
		
		socket.on('KVToolsCore-ExportScene', function(core){ return function(sdata){
			var data  = JSON.parse(sdata);
			var fpath = data.filepath;
			var buf  = 'local width  = 512 \n';
				buf += 'local height = 512 \n';
				buf += 'local fsaa = 4\n';
				buf += 'local outputfile = "output.jpg"\n';
				buf += 'camera = {\n';
				var eye = render.getEye(),
					tar = render.getLookat(),
					up  = render.getUp();
				buf += '    from = {'+eye[0]+','+eye[1]+','+eye[2]+'},\n';
				buf += '    to   = {'+tar[0]+','+tar[1]+','+tar[2]+'},\n';
				buf += '    up   = {'+ up[0]+','+ up[1]+','+ up[2]+'},\n';
				buf += '    fov  = '+render.getFov()+'\n';
				buf += '}\n';
				buf += 'obj = {\n';
				
				for (var i in core.objProperty){
					var obj = core.objProperty[i];
					buf += '    { file="'+obj.path+'"';
					buf += ', shader="'+obj.shader+'"';
					buf += ', translate={'+obj.translation[0]+','+obj.translation[1]+','+obj.translation[2]+'}';
					buf += ', rotate={'   +obj.rotation[0]   +','+obj.rotation[1]   +','+obj.rotation[2]   +'}';
					buf += ', scale={'    +obj.scale[0]      +','+obj.scale[1]      +','+obj.scale[2]      +'}';
					buf += ', vec4={ color={'+obj.color[0]+','+obj.color[1]+','+obj.color[2]+','+obj.color[3]+'} }';
					buf += ' },\n';
				}
				buf += '}\n\n';
				buf += 'krender(outputfile, width, height, fsaa)\n';

			fs.writeFile(fpath, buf, function(err){
				if (err){
					console.log('Failed to write scene file:'+fpath);
				}
			});
		}}(this));
	}
	
	KVToolsCore.prototype.SyncObjectList = function(){
		this.socket.emit('KVToolsCore-UpdateObjectList',JSON.stringify(this.objProperty));
	}
	
	KVToolsCore.prototype.SyncShaderList = function(){
		fs.readdir(shaderspath, function(thisptr){ return function(err,files){
			var shaderList = [];
			for (var i in files){
				var ext = path.extname(files[i]);
				if (ext === '.frag'){
					shaderList.push(files[i]);
				}
			}
			thisptr.socket.emit('KVToolsCore-UpdateShaderList',JSON.stringify(shaderList));
		}}(this));
	}

	module.exports = KVToolsCore;
	
	
} else { // client.js
	
	var KVToolsCore = function(socket, width, height, renderedFunc){
		this.socket = socket;
		this.data = {};
		this.updateFunc = null;
		this.updateShaderListFunc = null;
		
		socket.on('KVToolsCore-UpdateObjectList',function(thisptr){ return function(sdata){
			//console.log('KVToolsCore-UpdateObjectList');
			var data = JSON.parse(sdata);
			thisptr.data = data;
			if (thisptr.updateFunc)
				thisptr.updateFunc(data);
		}}(this));
		socket.on('KVToolsCore-UpdateShaderList',function(thisptr){ return function(sdata){
			var data = JSON.parse(sdata);
			if (thisptr.updateShaderListFunc)
				thisptr.updateShaderListFunc(data);
		}}(this));

		this.simage = new ServerImager(renderedFunc, function(thisptr,w,h){ return function(){
			thisptr.Render(w,h);
		}}(this,width,height));
	}
	KVToolsCore.prototype.GetObjectList = function(){
		return this.data;
	}
	
	KVToolsCore.prototype.SyncObjectList = function(){
		this.socket.emit('KVToolsCore-SyncObjectList',JSON.stringify({}));
	}
	KVToolsCore.prototype.RequestShaderList = function(){
		this.socket.emit('KVToolsCore-RequestShaderList',JSON.stringify({}));
	}
	
	KVToolsCore.prototype.Render = function(w,h){
		this.simage.Render(w,h);
	}
	KVToolsCore.prototype.on = function(event, func){
		if(event === 'update'){
			this.updateFunc = func;
		}else if(event === 'updateShaderList'){
			this.updateShaderListFunc = func;
		}
	}
	KVToolsCore.prototype.LoadModel = function(modelpath,name){
		this.socket.emit('KVToolsCore-Loadmodel',JSON.stringify({path:modelpath,name:name}));
	}
	KVToolsCore.prototype.RemoveModel = function(name){
		this.socket.emit('KVToolsCore-RemoveModel',JSON.stringify({name:name}));
	}
	KVToolsCore.prototype.RemoveAllModels = function(name){
		this.socket.emit('KVToolsCore-RemoveAllModels',JSON.stringify({}));
	}

	KVToolsCore.prototype.Mouse = function(mouseevent,x,y){
		this.socket.emit('KVToolsCore-mousecommand',JSON.stringify({event:mouseevent,x:x,y:y}));
	}
	
	KVToolsCore.prototype.SetTransform = function(name,tx,ty,tz,rx,ry,rz,sx,sy,sz){
		if (!this.data[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-Transform', JSON.stringify({
			name:name,
			translate_x:tx,
			translate_y:ty,
			translate_z:tz,
			rotate_x:rx,
			rotate_y:ry,
			rotate_z:rz,
			scale_x:sx,
			scale_y:sy,
			scale_z:sz
		}));
	}
	
	KVToolsCore.prototype.SetTranslate = function(name,tx,ty,tz){
		var tobj = this.data[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var sx = tobj.scale[0],
			sy = tobj.scale[1],
			sz = tobj.scale[2],
			rx = tobj.rotation[0],
			ry = tobj.rotation[1],
			rz = tobj.rotation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz);
	}
	KVToolsCore.prototype.SetRotate = function(name,rx,ry,rz){
		var tobj = this.data[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var sx = tobj.scale[0],
			sy = tobj.scale[1],
			sz = tobj.scale[2],
			tx = tobj.translation[0],
			ty = tobj.translation[1],
			tz = tobj.translation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz);
	}
	KVToolsCore.prototype.SetScale = function(name,sx,sy,sz){
		var tobj = this.data[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var tx = tobj.translation[0],
			ty = tobj.translation[1],
			tz = tobj.translation[2],
			rx = tobj.rotation[0],
			ry = tobj.rotation[1],
			rz = tobj.rotation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz);
	}
	KVToolsCore.prototype.SetColor = function(name,red,green,blue,alpha){
		var tobj = this.data[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-ChangeColor', JSON.stringify({
			name:name,
			r:red,
			g:green,
			b:blue,
			a:alpha
		}));
	}
	
	KVToolsCore.prototype.SetShader = function(name,shadername){
		var tobj = this.data[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetShader', JSON.stringify({
			name:name,
			shader:shadername
		}));
	}
	
	KVToolsCore.prototype.SetRenderMode = function(mode){
		this.socket.emit('KVToolsCore-RenderMode', JSON.stringify({ mode:mode }));
	}
	
	KVToolsCore.prototype.ExportScene = function(scenepath){
		this.socket.emit('KVToolsCore-ExportScene', JSON.stringify({ filepath:scenepath }));
	}
	KVToolsCore.prototype.SetPixelStep = function(step){
		this.socket.emit('KVToolsCore-SetPixelStep', JSON.stringify({ step:step }));
	}
	

}
