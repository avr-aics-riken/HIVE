var wid,hei;
var core;

var shaderList = [];

var filedialog = new FileDialog('KVToolsObjectDialog',true,false);

document.oncontextmenu = function(e){ return false }

window.onload = function() {
	kvtoolsUI_init();
		
	canvasResizing();
	
	function renderedFunc(buf){
		var buffer = new Uint8Array(buf.data);
		var rc = document.getElementById('result');
		var tcan = document.getElementById('tmp')
		var rctx = rc.getContext('2d');
		var tctx = tcan.getContext("2d");
		var rimageData = tctx.createImageData(wid, hei);
		var pixels = rimageData.data;
		pixels.set(buffer, 0, buffer.length);
		rctx.fillRect(0, 0, rc.width, rc.height);
		tctx.putImageData(rimageData, 0, 0);
		rctx.drawImage(tcan, 0, 0);
	}
	var socket = io.connect();
	socket.on('connect',function(){
		console.log('socket.io connected');
	});
	filedialog.registerSocketEvent(socket);
	
	core = new KVToolsCore(socket, wid, hei, renderedFunc);
	core.on('update',function(data){
		// update list
		var lst = $('list-itemlist');
		lst.Clear();
		for(item in data){
			var itemid = 'listitem-'+item;
			lst.AddItem(item,itemid);
			// HACK code. need to refactor
			var d = document.getElementById(itemid);
			d.addEventListener('click',function(item){return function(e){
				setProperty(item);
			}}(item));
			var dust = document.getElementById(itemid+'-dustbtn');
			if (dust){
				dust.addEventListener('click',function(item){return function(e){
					e.stopPropagation();
					core.RemoveModel(item);
				}}(item));
			}
		}
	});
	core.on('updateShaderList',function(data){
		//console.log(data);
		shaderList = [];
		for (var i in data){
			shaderList.push(data[i]);
		}
	});

	core.SyncObjectList();
	core.RequestShaderList();
	
	function setProperty(name){
		var dt = core.GetObjectList();
		if (!dt[name]) {
			console.log('not found item:'+name);
			return;
		}
		document.getElementById('objname').value = name;
		document.getElementById('translate_x').value = dt[name].translation[0];
		document.getElementById('translate_y').value = dt[name].translation[1];
		document.getElementById('translate_z').value = dt[name].translation[2];
		document.getElementById('rotate_x').value = dt[name].rotation[0];
		document.getElementById('rotate_y').value = dt[name].rotation[1];
		document.getElementById('rotate_z').value = dt[name].rotation[2];
		document.getElementById('scale_x').value = dt[name].scale[0];
		document.getElementById('scale_y').value = dt[name].scale[1];
		document.getElementById('scale_z').value = dt[name].scale[2];
		document.getElementById('color_r').value = dt[name].color[0];
		document.getElementById('color_g').value = dt[name].color[1];
		document.getElementById('color_b').value = dt[name].color[2];
		document.getElementById('color_a').value = dt[name].color[3];
		for (var i in shaderList){
			$('shader_name').AddItem(shaderList[i]);
		}
		document.getElementById('shader_name').value = dt[name].shader;
	}
	
	$('list-addbutton').clickFunc = function(){
		//core.LoadModel('/Users/kioku/git/lsgl_github/app/KAnimRender/bunny.obj');
		openfileDialog('/');
	}

	$('updatebutton').clickFunc = function(){
		var name = document.getElementById('objname').value,
			tx = document.getElementById('translate_x').value,
			ty = document.getElementById('translate_y').value,
			tz = document.getElementById('translate_z').value,
			rx = document.getElementById('rotate_x').value,
			ry = document.getElementById('rotate_y').value,
			rz = document.getElementById('rotate_z').value,
			sx = document.getElementById('scale_x').value,
			sy = document.getElementById('scale_y').value,
			sz = document.getElementById('scale_z').value;
			cr = document.getElementById('color_r').value,
			cg = document.getElementById('color_g').value,
			cb = document.getElementById('color_b').value,
			ca = document.getElementById('color_a').value,
			shr = document.getElementById('shader_name').value;
		core.SetTransform(name, tx,ty,tz,rx,ry,rz,sx,sy,sz);
		core.SetColor(name, cr,cg,cb,ca);
		console.log('SHAER='+shr);
		core.SetShader(name,shr);
	}
	$('rendermodebtn').clickFunc = function(){
		var mode = this.getValue();
		if (mode == 'OpenGL') {
			this.setValue('LSGL');
			core.SetRenderMode('LSGL')
			$('pixelstep').Show(true);
		} else {
			this.setValue('OpenGL');
			core.SetRenderMode('OPENGL');
			$('pixelstep').Show(false);
		}
	}
	
	$('pixelstep').onChangedFunc = function(val){
		core.SetPixelStep(val);
	}
	
	$('exportbtn').clickFunc = function(){
		alert('saved "scene.scn"');
		core.ExportScene('scene.scn');
	}
	
	var view = document.getElementById('result');
	view.addEventListener('mousedown', function(e){
		var press = true;
		e.preventDefault();
		e.stopPropagation();
		//console.log(e.button);
		if (e.button == 0)
			core.Mouse('mouseleftdown',e.clientX,e.clientY);
		else if (e.button == 1)
			core.Mouse('mousemiddledown',e.clientX,e.clientY);
		else if (e.button == 2)
			core.Mouse('mouserightdown',e.clientX,e.clientY);
				
		var mmove = function(e){
			if (press){
				core.Mouse('mousemove',e.clientX,e.clientY);
				core.Render(wid,hei);
			}
		}
		var mup = function(e){
			document.removeEventListener('mousemove',mmove);
			document.removeEventListener('mouseup',mup);
			press = false;
			core.Mouse('mouseleftup',e.clientX,e.clientY);
			core.Mouse('mousemiddleup',e.clientX,e.clientY);
			core.Mouse('mouserightup',e.clientX,e.clientY);
		}
		document.addEventListener('mousemove', mmove);
		document.addEventListener('mouseup', mup);
	});
}


//-----------------------------------
var tarPath = '';
function openfileDialog(path)
{
	//console.log('OFD:'+path);
	tarPath = path;
	var i = document.getElementsByClassName("popup_center")[0];
	i.style.display="block";

	var c = document.getElementById('projdir_path');
	c.value = path;
	filedialog.FileList(path);
}
function closefileDialog()
{
	var i = document.getElementsByClassName("popup_center")[0];
	i.style.display="none";
}

function open_selectedFile()
{
	console.log("OPENPATH:"+tarPath);
	var sp = tarPath.split('/');
	console.log(sp);
	if (sp.length < 2){
		console.log('invalid path');
		return;
	}
	var fname = sp[sp.length-1];
	var fsp = fname.split('.');
	if (fsp.length < 1){
		console.log('NO extenstoin');
		return;
	}
	
	var oppath = '';
	var ext = fsp[fsp.length - 1];
	if (ext == 'obj' || ext == 'stl' ||
		ext == 'sph' || ext == 'vol' ||
		ext == 'lpt'){
		oppath = tarPath;
	} else {
		console.log("Unknown extension type:"+ext);
	}
	
	// open
	if (oppath != '') {
		console.log('LoadModel:'+oppath);
		closefileDialog();
		core.LoadModel(oppath);//'/Users/kioku/git/lsgl_github/app/KAnimRender/bunny.obj');
	}
}

function canvasResizing(){
	var w = document.getElementById('window-view').clientWidth,
		h = document.getElementById('window-view').clientHeight;
	var rc = document.getElementById('result');
	var tcan = document.getElementById('tmp')
	rc.width    = w;
	rc.height   = h;
	tcan.width  = w;
	tcan.height = h;
	wid = w;
	hei = h;
}

window.onresize = function(){
	canvasResizing();
	core.Render(wid,hei);
}
