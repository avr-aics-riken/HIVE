var _kvtools_UIs = {};
function $(id_name){
	return _kvtools_UIs[id_name];
}
//------------------------------------------------------

var KListClass = function(wrapper){
	this.wrapper = wrapper;
}
	
// methods
KListClass.prototype = {
	AddItem:function(itemname,idname){
		var itm = document.getElementById('KList-Item');
		if (!itm){
			console.log('Not found ID:KList-Item');
			return;
		}
		itm =  itm.children[0];

		var newitem = itm.cloneNode(true);
		newitem.setAttribute('id',idname);
		//console.log(newitem);
		
		var s = newitem.getElementsByClassName('KList-Item-Caption');
		if (s.length){
			s[0].innerHTML = itemname;
		}
		var d = newitem.getElementsByClassName('KDustButton');
		if (d.length>0){
			d[0].setAttribute('id',idname+'-dustbtn');
		}
		
		this.wrapper.appendChild(newitem);
	},
	
	Clear:function(){
		this.wrapper.innerHTML = '';
	}
}

KListClass.Init = function(){
	var lst = document.getElementsByClassName('KList');
	for (var i=0; i<lst.length;++i) {
		console.log(lst[i].id);
		_kvtools_UIs[lst[i].id] = new KListClass(lst[i]);
	}
}


//------------------------------------------------------

var KButtonClass = function(wrapper){
	this.wrapper = wrapper;
	
	// register events
	wrapper.addEventListener('click',function(inst){
		return function(e){inst.onClick(e)}
	}(this));
}

// methods
KButtonClass.prototype = {
	onClick:function(e){
		//console.log('Button clicked.');
		if (this.clickFunc)
			this.clickFunc();
	},
	setValue:function(val){
		this.wrapper.innerHTML = val;
	},
	getValue:function(){
		return this.wrapper.innerHTML;
	}
}

KButtonClass.Init = function(){
	var lst = document.getElementsByClassName('KButton');
	for (var i=0; i<lst.length;++i) {
		console.log(lst[i].id);
		_kvtools_UIs[lst[i].id] = new KButtonClass(lst[i]);
	}
}


//------------------------------------------------------

var KWindowClass = function(wrapper){
	this.wrapper = wrapper;
	
	// register events
	this.dragging = false;
	this.mstartx = 0;
	this.mstarty = 0;
	var sx = wrapper.style.left.split('px');
	var sy = wrapper.style.top.split('px');
	this.x = (sx.length > 0 ? parseInt(sx[0]) : 0)
	this.y = (sy.length > 0 ? parseInt(sy[0]) : 0)
	
	var res = wrapper.getElementsByClassName('KWindow-TitleBar');
	if (res.length == 0)
		return;
	var movewrapper = res[0];
	movewrapper.addEventListener('mousedown',function(inst){return function(e){
		inst.dragging = true;
		inst.mstartx = e.clientX;
		inst.mstarty = e.clientY;

		function mup(inst){return function(e){
			inst.dragging = false;
			document.removeEventListener('mouseup',inst.mup);
			document.removeEventListener('mousemove',inst.mmove);
		}}
		function mmove(inst){return function(e){
			if (inst.dragging){
				var dx = e.clientX - inst.mstartx;
				var dy = e.clientY - inst.mstarty;
				inst.x += dx;
				inst.y += dy;
				inst.wrapper.style.top  = inst.y +'px';
				inst.wrapper.style.left = inst.x +'px';
			}
			inst.mstartx = e.clientX;
			inst.mstarty = e.clientY;
		}}
		
		inst.mmove = mmove(inst);
		inst.mup   = mup(inst);
		document.addEventListener('mouseup',inst.mup);
		document.addEventListener('mousemove',inst.mmove);
	}}(this));
}
KWindowClass.Init = function(){
	var lst = document.getElementsByClassName('KWindow');
	for (var i=0; i<lst.length;++i) {
		console.log(lst[i].id);
		_kvtools_UIs[lst[i].id] = new KWindowClass(lst[i]);
	}
}
//------------------------------------------------------
KCaptionClass = function(wrapper){
	this.wrapper = wrapper;
}

KCaptionClass.prototype = {
	SetCaption:function(cap){
		this.wrapper.innerHTML = cap;
	}
}

KCaptionClass.Init = function(){
	var lst = document.getElementsByClassName('KCaption');
	for (var i=0; i<lst.length;++i) {
		//console.log(lst[i].id);
		_kvtools_UIs[lst[i].id] = new KCaptionClass(lst[i]);
	}
}

//------------------------------------------------------
KDropdownListClass = function(wrapper){
	this.wrapper = wrapper;
	this.prototype = KListClass.prototype;
	this.onChangedFunc = null;
	
	this.wrapper.addEventListener('change', function(thisptr){ return function(){
		var val = thisptr.wrapper.value;
		if (thisptr.onChangedFunc)
			thisptr.onChangedFunc(val);
	}}(this));

}

KDropdownListClass.prototype.AddItem = function(cap){
	//<option value="cap">cap</option>
	var newitem = document.createElement('option');
	newitem.setAttribute('value',cap);
	newitem.innerHTML = cap;
	
	this.wrapper.appendChild(newitem);
}

KDropdownListClass.prototype.Show = function(show){
	this.wrapper.style.display = (show ? "" : "none");
}

KDropdownListClass.Init = function(){
	var lst = document.getElementsByClassName('KDropdownList');
	for (var i=0; i<lst.length;++i) {
		//console.log(lst[i].id);
		_kvtools_UIs[lst[i].id] = new KDropdownListClass(lst[i]);
	}
}

//------------------------------------------------------

function kvtoolsUI_init(){
	KButtonClass.Init();
	KListClass.Init();
	KWindowClass.Init();
	KCaptionClass.Init();
	KDropdownListClass.Init();
}

//------------------------------------------------------
