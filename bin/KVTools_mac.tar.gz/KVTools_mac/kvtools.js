/*jslint devel:true*/
/*global require, process*/

var	KVToolsCore = require('./root/KVToolsCore'),
	ShaderEditor = require('./root/ShaderEditor'),
	io = require('socket.io'),
	http = require('http'),
	filedialog = require('./root/filedialog'),
	fs = require('fs'),
	filedlg = require('./root/filedlg');


var mode = process.argv.slice(2);
console.log("mode=" + mode);

var server = http.createServer(function (request, response) {
	'use strict';
	var filePath = null,
		data;
	if (request.url === '/') {
		if (mode.toString() === 'shader') {
			filePath = './root/shader.html';
		} else {
			filePath = './root/index.html';
		}
	} else {
		filePath = './root' + request.url;
	}
	
	console.log((new Date()) + " Received request for " + request.url);
	function readFunc(response) {
		return function (err, data) {
			if (err) {
				response.end("Bad request.");
				return;
			}
			response.end(data);
		};
	}
	data = fs.readFile(filePath, readFunc(response));
});

// Core
var core = new KVToolsCore();


var io = io.listen(server);
//io.set('log level', 1);

io.sockets.on('connection', function (socket) {
	'use strict';
	console.log('socket.io connected:' + socket.id);
	
	// Core Event
	core.RegisterSocketIO(socket);
	filedialog.SocketEvent(socket, 'KVToolsObjectDialog');
	ShaderEditor.SocketEvent(socket);
	filedlg.SocketEvent(socket, 'opensavedialog');
	
	socket.on('disconnect', function () {
		console.log("disconnect:" + socket.id);
	});
});


server.listen(8082, function () {
	'use strict';
	console.log((new Date()) + " Server is listening on port 8082");
});


