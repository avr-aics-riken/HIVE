## Mac

mesa_glsl_compiler_path = "glsl/bin/macosx64/glsl_compiler"
cxx_compiler_path = "clang++"
additional_compiler_options = ["-O2"]


## K/FX10 cross
#mesa_glsl_compiler_path = "/home/ra000004/a03026/work/lsgl/glsl/bin/linux_x64/glsl_compiler"
#cxx_compiler_path = "FCCpx"
#additional_compiler_options = ["-Kfast"]

## Windows example.
#mesa_glsl_compiler_path = "Z:/git/lsgl_github/glsl/bin/windows_x64/glsl_compiler.exe"
#cxx_compiler_path = "C:/Users/kioku/Desktop/mingw64/bin/x86_64-w64-mingw32-g++.exe"
#additional_compiler_options = ["-O2"]
