var filedlg = (function () {
	"use strict";

	if (typeof window === 'undefined') { // Node.js

		var fs = require('fs'),
			path = require('path'),
			getFiles = function (dir, list) {
				try {
					var files = fs.readdirSync(dir),
						i,
						name;
					if (!files) {
						return false;
					}
					if (dir.substr(dir.length - 1) !== "/") {
						dir += "/";
					}
					
					for (i in files) {
						if (files.hasOwnProperty(i)) {
							name = dir + files[i];
							if (fs.statSync(name).isDirectory()) {
								//getFiles(name,list);
								list.push({"name": files[i], "type": "dir", "path": name});
							} else if (files[i].substring(0, 1) !== '.') {
								//console.log(name);
								list.push({"name": files[i], "type": "file", "path": name, "exttype":path.extname(files[i])});
							}
						}
					}
					return true;
				} catch (e) {
					list = [];
					console.log("not found dir:" + dir);
					return false;
				}
			},
			filedialog = {
				SocketEvent: function (socket, name) {
					var updateFileList = function (path) {
						var list = [];
						
						if (getFiles(path, list)) {//;list.length !== 0) {
							socket.emit(name + ':updatedFileList', JSON.stringify({path:path, list:list}));
						}
					};

					socket.on(name + ':requestFileList', function (data) {
						updateFileList(data);
					});
				}
			};
		module.exports = filedialog;

	} else {

		var tarPath = "";
		var FileDialog = function (name, ignoreDotFile) {
			this.name = name;
			this.exttype = "";
			this.dir_only = false;
			this.ignoreDotFile = ignoreDotFile;
			this.domNode = null;
			this.cssNode = null;
		};

		var xrequet = function (url, callback_online, callback_offline) {
			if (callback_offline === undefined) {
				callback_offline = callback_online;
			}
			var xhr = new XMLHttpRequest();
			xhr.open("GET", url, true);
			xhr.onreadystatechange = function(){
				if (xhr.readyState === 4 && xhr.status === 200 && callback_online){ // online
					callback_online(this.responseText);
				}
				if (xhr.readyState === 4 && xhr.status === 0 && callback_offline){ // offline
					callback_offline(this.responseText);
				}
			}
			xhr.send(null);
		}

		FileDialog.prototype.OpenDir = function (callback) {
			this.Show("OpenDir", "", callback);
		};
		FileDialog.prototype.OpenFile = function (exttype, callback) {
			this.Show("Open", exttype, callback);
		};
		FileDialog.prototype.SaveFile = function (exttype, callback) {
			this.Show("Save", exttype, callback);
		};
		
		FileDialog.prototype.Show = function (mode, exttype, callback) {
			var htmlpath = "filedlg.html",
				csspath  = "css/filedlg.css";
						
			function appendDlg(self,mode, exttype, callback) {
				var d = document.createElement('div'),
					fdtemplate = document.getElementById('filedlg-template');
				if (fdtemplate === null) {
					console.log('NOT Found filedlg-template');
					return;
				}
				d.innerHTML = fdtemplate.innerHTML;
				self.domNode = d;
				var savebtn   = (d.getElementsByClassName("filedlg_button_save"))[0],
					cancelbtn = (d.getElementsByClassName("filedlg_button_cancel"))[0],
					btnname = (savebtn.getElementsByClassName("filedlg_text_button_action"))[0],
					filetext = (self.domNode.getElementsByClassName('filedlg_input_filedialog'))[0],
					fileext = (self.domNode.getElementsByClassName('filedlg_filepath_ext'))[0],
					filtertext = d.getElementsByClassName('filedlg_filter')[0];
				fileext.innerHTML = exttype;
				self.exttype = exttype;
				
				console.log(filtertext);
				if (filtertext) {
					filtertext.addEventListener('keyup', function(self){ return function() {
						var keyw = filtertext.value,
							ls = (self.domNode.getElementsByClassName('filedlg_filebrowser filedlg_filedialog'))[0],
							fileitems = ls.getElementsByClassName('filedlg_fileitem'),
							flabels = ls.getElementsByClassName('filedlg_filelabel'),
							fname,
							i;
							
						
						// visible reset
						for (i = 0; i < fileitems.length; i += 1) {
							fileitems[i].style.display = '';
						}
						if (keyw === '') {
							return;
						}
						for (i = 0; i < flabels.length; i += 1) {
							fname = flabels[i].innerHTML;
							keyw = keyw.toLowerCase();
							fname = fname.toLowerCase();
							if (fname.indexOf(keyw) === -1 && fname !== '..') {
								flabels[i].parentNode.style.display = 'none';
							}
						}
					}}(self));
				}
				if (savebtn) {
					if (mode.toLowerCase() === "open") {
						self.dir_only = false;
						btnname.innerHTML = "Open";
						filetext.setAttribute("readonly", "readonly");
						//fileext.style.display = "none";
					} else if (mode.toLowerCase() === "save") {
						self.dir_only = false;
						btnname.innerHTML = "Save";
					} else if (mode.toLowerCase() === "opendir") {
						self.dir_only = true;
						btnname.innerHTML = "Open";
						filetext.value = "";
						filetext.style.display = "none";
						fileext.style.display = "none";
					} else {
						console.log("Error: Unknown file dialog type.");
					}
					
					savebtn.addEventListener('click', function (self) { return function () {
						//console.log('save!!!!');
						var fpath = (self.domNode.getElementsByClassName('filedlg_filepath_filedialog'))[0].innerHTML,
							fname = (self.domNode.getElementsByClassName('filedlg_input_filedialog'))[0].value;
			
						if (fname === '') {
							return;
						}
						// append ext
						var fileTypes = fname.split(".");
						var len = fileTypes.length;
						console.log(fileTypes,len,self.exttype);
						if (self.exttype !== "" && ("."+fileTypes[fileTypes.length - 1]) !== self.exttype) {
							fname += self.exttype;
						}
						
						if (fpath.slice(-1) !== '/') {
							fpath += '/';
						}
						fpath += fname;
						
						console.log('Select->' + fpath);
						if (callback) {
							callback(fpath);
							document.body.removeChild(self.domNode); // close
						}
					}}(self));
				}
				if (cancelbtn) {
					cancelbtn.addEventListener('click', function (self) { return function () {
						//console.log('cancel!!!!');
						//console.log(self);
						document.body.removeChild(self.domNode); // close
					}}(self));
				}
				document.body.appendChild(d);
				
				// get file list
				self.FileList('/');
			}
		
			var dlgtemplate = document.getElementById('filedlg-template');
			if (dlgtemplate !== null) { // Cached
				appendDlg(this, mode, exttype, callback);
			} else { // not cached
				var ff = document.getElementById('filedlg-folder');
				if (ff === null) {
					ff = document.createElement('div');
					ff.setAttribute('id','filedlg-folder');
					ff.style.display = "none";
					document.body.appendChild(ff);
				}
				
				// Add CSS
				var fileref = document.createElement('link');
				fileref.setAttribute('rel', 'stylesheet');
				fileref.setAttribute('type', 'text/css');
				fileref.setAttribute('href', csspath);
				this.cssNode = fileref;
				ff.appendChild(fileref);
				
				xrequet(htmlpath, function (self, callback) { return function (htmldata) {
					dlgtemplate = document.createElement('div');
					dlgtemplate.setAttribute('id','filedlg-template');
					dlgtemplate.innerHTML = htmldata;
					ff.appendChild(dlgtemplate);
					appendDlg(self, mode, exttype, callback);
				}}(this, callback));
			}
			
		};

		FileDialog.prototype.registerSocketEvent = function (socket) {
			this.socket = socket;
			var ev, eventname = this.name + ':updatedFileList';
			//console.log('FileDialog:' + eventname);

			ev = function (thisptr) {
				return function (data) {
					thisptr.updateDirlist(data);
				};
			};
			socket.on(eventname, ev(this));
		};
		FileDialog.prototype.dispPath = function (p) {
			(this.domNode.getElementsByClassName('filedlg_filepath_filedialog'))[0].innerHTML = p;
		};
		FileDialog.prototype.FileList = function (path) {
			//this.dispPath(path);
			//console.log("FileList:"+path);
			this.socket.emit(this.name + ":requestFileList", path);
		};

		//--------------
		FileDialog.prototype.updateDirlist = function (jsonlist) {
			var getUpDir, makeUpNode, makeNode,	unode, list, i, newbtn, ls, filtertext;
			getUpDir = function (path) { // fix me beautiful
				var p = path.split("/"),
					uppath = "/",
					i;
				if (path === "/") {
					return "/";
				}
				if (p[p.length - 1] === "") {
					p.pop();
				}

				for (i = 0; i < p.length - 1; i += 1) {
					if (p[i] !== "") {
						uppath += p[i] + '/';
					}
				}
				if (uppath === "//") {
					uppath = "/";
				}
				return uppath;
			};
			makeUpNode = function (self) {
				var newbtn = document.createElement('div'),
					fileicon = document.createElement('div'),
					filelabel = document.createElement('p'),
					upath = getUpDir(self.tarPath);

				newbtn.setAttribute('class', "filedlg_fileitem");
				newbtn.setAttribute('draggable', "false");

				fileicon.setAttribute('class', 'filedlg_back');
				newbtn.appendChild(fileicon);

				filelabel.setAttribute('class', "filedlg_filelabel");
				filelabel.innerHTML = "..";
				newbtn.appendChild(filelabel);

				//console.log("UPATH="+upath);
				//newbtn.setAttribute('onclick', 'openfileDialog("' + upath + '")');
				newbtn.addEventListener('click', function (self, p) { return function () {
					self.FileList(p);
				}}(self, upath));
				return newbtn;
			};
			makeNode = function (self, name, path, type) {
				var newbtn = document.createElement('div'),
					fileicon = document.createElement('div'),
					filelabel = document.createElement('p');

				newbtn.setAttribute('class', "filedlg_fileitem");
				newbtn.setAttribute('draggable', "false");

				newbtn.appendChild(fileicon);

				filelabel.setAttribute('class', "filedlg_filelabel");
				filelabel.innerHTML = name;
				newbtn.appendChild(filelabel);
				
				if (type === "file") {
					fileicon.setAttribute('class', 'filedlg_file');
					newbtn.addEventListener('click', function (self, p) { return function () {
						var names = p.split('/');
						(self.domNode.getElementsByClassName('filedlg_input_filedialog'))[0].value = names[names.length - 1];
					}}(self, path));
				} else if (type === "dir") {
					fileicon.setAttribute('class', 'filedlg_dir');
					newbtn.addEventListener('click', function (self, p) { return function () {
						self.FileList(p);
					}}(self, path));
				}
				return newbtn;
			};

			filtertext = this.domNode.getElementsByClassName('filedlg_filter')[0];
			filtertext.value  = '';
			
			ls = (this.domNode.getElementsByClassName('filedlg_filebrowser filedlg_filedialog'))[0];
			ls.innerHTML = ''; // clear
			
			// up dir
			var plist = JSON.parse(jsonlist);
			this.tarPath = plist.path;
			unode = makeUpNode(this);
			list = plist.list;
			this.dispPath(plist.path);
			
			ls.appendChild(unode);
			for (i in list) {
				//console.log('ADDDDD:'+list[i]);
				if (list[i].type !== "file" && list[i].type !== "dir") {
					console.log("Unknown file type -> " + list[i].type);
					continue;
				}
				if (list[i].name.charAt(0) === "." && this.ignoreDotFile) {
					continue;
				}
				if (list[i].type === "file" && this.dir_only) { // ignore files
					continue;
				}
				if (this.exttype !== "" && list[i].type === "file" && this.exttype.toLowerCase() !== list[i].exttype.toLowerCase()) {
					continue;
				}
				newbtn = makeNode(this, list[i].name, list[i].path, list[i].type);

				ls.appendChild(newbtn);
			}
		};
		return FileDialog;
	}
	
})();