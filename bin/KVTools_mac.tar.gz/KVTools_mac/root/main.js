/*jslint devel:true */
/*global FileDialog, filedlg, SVG, kvtoolsUI_init, svgNodeUI, io */
var wid, hei;
var core;

var shaderList = [];

var filedialog = new FileDialog('KVToolsObjectDialog', true, false);
var opensavedlg = new filedlg("opensavedialog", true);

document.oncontextmenu = function (e) { "use strict"; return false; };

var nui;

window.onload = function () {
	"use strict";
	
	function makeOBJLoadNode(filepath) {
		return {
			nodeData: [
				{
					name: 'OBJLoader',
					pos: [200, 100],
					varname: 'inst1',
					funcname: 'Load',
					deletable: false,
					input: [
						{name: 'filepath', type: 'string', value: '"' + filepath + '"'}
					],
					output: [
						{name: 'Position', type: 'Vec3Buffer'},
						{name: 'Normal', type: 'Vec3Buffer'},
						{name: 'Material', type: 'FloatBuffer'},
						{name: 'Index', type: 'UintBuffer'}
					]
				},
				{
					name: 'PolygonModel',
					pos: [500, 100],
					varname: 'root',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'vertexbuf', type: 'Vec3Buffer'},
						{name: 'normalbuf', type: 'Vec3Buffer'},
						{name: 'materialbuf', type: 'FloatBuffer'},
						{name: 'indexbuf', type: 'UintBuffer'}
					],
					output: [
						{name: 'this', type: 'RenderObject'}
					]
				}
			],
			plugData: [
				{output: {node: 'inst1', plug: 'Position'}, input: {node: 'root', plug: 'vertexbuf'}},
				{output: {node: 'inst1', plug: 'Normal'}, input: {node: 'root', plug: 'normalbuf'}},
				{output: {node: 'inst1', plug: 'Material'}, input: {node: 'root', plug: 'materialbuf'}},
				{output: {node: 'inst1', plug: 'Index'}, input: {node: 'root', plug: 'indexbuf'}}
			]
		};
	}
	
	function makeSTLLoadNode(filepath) {
		return {
			nodeData: [
				{
					name: 'STLLoader',
					pos: [200, 100],
					varname: 'inst1',
					funcname: 'Load',
					deletable: false,
					input: [
						{name: 'filepath', type: 'string', value: '"' + filepath + '"'}
					],
					output: [
						{name: 'Position', type: 'Vec3Buffer'},
						{name: 'Normal', type: 'Vec3Buffer'},
						{name: 'Material', type: 'FloatBuffer'},
						{name: 'Index', type: 'UintBuffer'}
					]
				},
				{
					name: 'PolygonModel',
					pos: [500, 100],
					varname: 'root',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'vertexbuf', type: 'Vec3Buffer'},
						{name: 'normalbuf', type: 'Vec3Buffer'},
						{name: 'materialbuf', type: 'FloatBuffer'},
						{name: 'indexbuf', type: 'UintBuffer'}
					],
					output: [
						{name: 'this', type: 'RenderObject'}
					]
				}
			],
			plugData: [
				{output: {node: 'inst1', plug: 'Position'}, input: {node: 'root', plug: 'vertexbuf'}},
				{output: {node: 'inst1', plug: 'Normal'}, input: {node: 'root', plug: 'normalbuf'}},
				{output: {node: 'inst1', plug: 'Material'}, input: {node: 'root', plug: 'materialbuf'}},
				{output: {node: 'inst1', plug: 'Index'}, input: {node: 'root', plug: 'indexbuf'}}
			]
		};
	}
	
	function makeSPHLoadNode(filepath) {
		return {
			nodeData: [
				{
					name: 'SPHLoader',
					pos: [200, 100],
					varname: 'inst1',
					funcname: 'Load',
					deletable: false,
					input: [
						{name: 'filepath', type: 'string', value: '"' + filepath + '"'}
					],
					output: [
						{name: 'Width', type: 'int'},
						{name: 'Height', type: 'int'},
						{name: 'Depth', type: 'int'},
						{name: 'Component', type: 'int'},
						{name: 'Buffer', type: 'FloatBuffer'}
					]
				},
				{
					name: 'FloatsToFloatBuffer',
					pos: [200, 300],
					varname: 'inst2a',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'buffer', type: 'FloatBuffer'},
						{name: 'compo', type: 'int'},
						{name: 'RED', type: 'int', value: '0'}
					],
					output: [
						{name: 'Buffer', type: 'FloatBuffer'},
						{name: 'Component', type: 'int'}
					]
				},
				{
					name: 'FloatsToFloatBuffer',
					pos: [500, 300],
					varname: 'inst2b',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'buffer', type: 'FloatBuffer'},
						{name: 'compo', type: 'int'},
						{name: 'GREEN', type: 'int', value: '1'}
					],
					output: [
						{name: 'Buffer', type: 'FloatBuffer'},
						{name: 'Component', type: 'int'}
					]
				},
				{
					name: 'FloatsToFloatBuffer',
					pos: [800, 300],
					varname: 'inst2c',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'buffer', type: 'FloatBuffer'},
						{name: 'compo', type: 'int'},
						{name: 'BLUE', type: 'int', value: '2'}
					],
					output: [
						{name: 'Buffer', type: 'FloatBuffer'},
						{name: 'Component', type: 'int'}
					]
				},
				{
					name: 'VolumeModel',
					pos: [700, 100],
					varname: 'root',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'width', type: 'int'},
						{name: 'height', type: 'int'},
						{name: 'depth', type: 'int'},
						{name: 'component', type: 'int'},
						{name: 'voldata', type: 'FloatBuffer'}
					],
					output: [
						{name: 'this', type: 'RenderObject'}
					]
				}
			],
			plugData: [
				{output: {node: 'inst1', plug: 'Width'}, input: {node: 'root', plug: 'width'}},
				{output: {node: 'inst1', plug: 'Height'}, input: {node: 'root', plug: 'height'}},
				{output: {node: 'inst1', plug: 'Depth'}, input: {node: 'root', plug: 'depth'}},
				{output: {node: 'inst1', plug: 'Component'}, input: {node: 'root', plug: 'component'}},
				{output: {node: 'inst1', plug: 'Buffer'}, input: {node: 'root', plug: 'voldata'}},
//				{output: {node: 'inst2', plug: 'Component'}, input: {node: 'root', plug: 'component'}},
//				{output: {node: 'inst2', plug: 'Buffer'}, input: {node: 'root', plug: 'voldata'}}

			]
		};
	}

	function makeVOLLoadNode(filepath) {
		return {
			nodeData: [
				{
					name: 'VOLLoader',
					pos: [200, 100],
					varname: 'inst1',
					funcname: 'Load',
					deletable: false,
					input: [
						{name: 'filepath', type: 'string', value: '"' + filepath + '"'}
					],
					output: [
						{name: 'Width', type: 'int'},
						{name: 'Height', type: 'int'},
						{name: 'Depth', type: 'int'},
						{name: 'Component', type: 'int'},
						{name: 'Buffer', type: 'FloatBuffer'}
					]
				},
				{
					name: 'VolumeModel',
					pos: [500, 100],
					varname: 'root',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'width', type: 'int'},
						{name: 'height', type: 'int'},
						{name: 'depth', type: 'int'},
						{name: 'component', type: 'int'},
						{name: 'voldata', type: 'FloatBuffer'}
					],
					output: [
						{name: 'this', type: 'RenderObject'}
					]
				}
			],
			plugData: [
				{output: {node: 'inst1', plug: 'Width'}, input: {node: 'root', plug: 'width'}},
				{output: {node: 'inst1', plug: 'Height'}, input: {node: 'root', plug: 'height'}},
				{output: {node: 'inst1', plug: 'Depth'}, input: {node: 'root', plug: 'depth'}},
				{output: {node: 'inst1', plug: 'Component'}, input: {node: 'root', plug: 'component'}},
				{output: {node: 'inst1', plug: 'Buffer'}, input: {node: 'root', plug: 'voldata'}}
			]
		};
	}

	function makeLPTLoadNode(filepath) {
		return {
			nodeData: [
				{
					name: 'LPTLoader',
					pos: [200, 100],
					varname: 'inst1',
					funcname: 'Load',
					deletable: false,
					input: [
						{name: 'filepath', type: 'string', value: '"' + filepath + '"'}
					],
					output: [
						{name: 'Position', type: 'Vec3Buffer'},
						{name: 'Radius', type: 'FloatBuffer'},
						{name: 'Material', type: 'FloatBuffer'}
					]
				},
				{
					name: 'ParticleModel',
					pos: [500, 100],
					varname: 'root',
					funcname: 'Create',
					deletable: false,
					input: [
						{name: 'vertexbuf', type: 'Vec3Buffer'},
						{name: 'radiusbuf', type: 'FloatBuffer'},
						{name: 'materialbuf', type: 'FloatBuffer'}

					],
					output: [
						{name: 'this', type: 'RenderObject'}
					]
				}
			],
			plugData: [
				{output: {node: 'inst1', plug: 'Position'}, input: {node: 'root', plug: 'vertexbuf'}},
				{output: {node: 'inst1', plug: 'Radius'}, input: {node: 'root', plug: 'radiusbuf'}},
				{output: {node: 'inst1', plug: 'Material'}, input: {node: 'root', plug: 'materialbuf'}}
			]
		};
	}

	
	kvtoolsUI_init();
		
	canvasResizing();
	var item,
		draw = SVG('nodecanvas').size(4000, 4000);
	nui = svgNodeUI(draw);
		
	var aaimg = new Image();
	aaimg.onload = function() {
		var rc = document.getElementById('result'),
		rctx = rc.getContext('2d');
		rctx.drawImage(this, 0, 0);
	}

	function renderedFunc(buf, compMode) {
		if (compMode == 1) {
			var buffer = new Uint8Array(buf.data),
				blob = new Blob([buffer], {type: "image/jpeg"}),
				url = URL.createObjectURL(blob);
			aaimg.src = url;
		} else {
			var buffer = new Uint8Array(buf.data),
				rc = document.getElementById('result'),
				tcan = document.getElementById('tmp'),
				rctx = rc.getContext('2d'),
				tctx = tcan.getContext("2d"),
				rimageData = tctx.createImageData(wid, hei),
				pixels = rimageData.data;
			pixels.set(buffer, 0, buffer.length);
			rctx.fillRect(0, 0, rc.width, rc.height);
			tctx.putImageData(rimageData, 0, 0);
			rctx.drawImage(tcan, 0, 0);
		}
	}
	
	var socket = io.connect();
	socket.on('connect', function () {
		console.log('socket.io connected');
	});
	filedialog.registerSocketEvent(socket);
	opensavedlg.registerSocketEvent(socket);
	
	core = new KVToolsCore(socket, wid, hei, renderedFunc);
	//core.SetImageCompMode(0);
	core.SetRenderMode('OPENGL'); // mode change and redraw
	core.on('update', function (objdata) {
		var data   = objdata.objProperty;
		var tldata = objdata.objTimeline;
		console.log('UPDATE:',data, tldata);
		
		var tl = $('timeline');
		tl.setTimelineData(tldata);
		tl.drawGraph();
		
		var lst = $('list-itemlist');
		// get selected item
		var oldselect = lst.GetSelectedValue();
		
		// update list
		lst.Clear();
		for (item in data) {
			var itemid = 'listitem-'+item;
			lst.AddItem(item,itemid);
			// HACK code. need to refactor
			var d = document.getElementById(itemid);
			d.addEventListener('click',function (item) { return function (e) {
				$('list-itemlist').Select(item);
				setProperty(item);
			}}(item));
			var dust = document.getElementById(itemid + '-dustbtn');
			var icon = d.getElementsByClassName('KList-Item-Icon')[0];
			if (dust){
				if (data[item].modeltype === "camera") {
					dust.style.display = 'none';
					icon.style.backgroundColor = "#ff9d00";
				} else {
					if (data[item].modeltype === "polygon") {
						icon.style.backgroundColor = "#0F0";
					} else if (data[item].modeltype === "volume") {
						icon.style.backgroundColor = "#F00";
					} else if (data[item].modeltype === "particle") {
						icon.style.backgroundColor = "#00F";
					}
					dust.addEventListener('click',function (item) { return function (e) {
						e.stopPropagation();
						core.RemoveModel(item, true);
					}}(item));
				}
			}
		}
		
		// set selected item
		lst.Select(oldselect);
		setProperty(oldselect);
	});
	core.on('updateShaderList', function (data) {
		shaderList = [];
		for (var i in data) {
			shaderList.push(data[i]);
		}
	});
	
	function toLocaleString( date )
	{
		return [
			date.getFullYear(),
			date.getMonth() + 1,
			date.getDate()
			].join( '/' ) + ' '
			+ date.toLocaleTimeString();
	}
	
	core.on('console', function (data) {
		var ca = document.getElementById('consoleArea');
		//ca.innerHTML += ('\n --- ' + toLocaleString(new Date) + ' ---\n' + data);
		if (data !== "") {
			ca.innerHTML += data;
			ca.style.display = '';
			ca.scrollTop = ca.scrollHeight;
		}
	});

	var getTargetShader = function (val) {
		var targetShader = null,
			i;
		for (i in shaderList) {
			if (shaderList[i].file == val) {
				targetShader = shaderList[i];
			}
		}
		return targetShader;
	}
	$('shader_name').ChangeCallback( function (val) {
		//console.log('SELECT SHADER = ' + val);
		
		var targetShader = getTargetShader(val);
		if (targetShader === null)
			return;
		//console.log('targetShader = ', targetShader);
		
		// Uniforms
		var unif = targetShader.param.uniforms;
		var pp = document.getElementById('uniformproperty');
		pp.innerHTML = ''; // clear
		
		//console.log('unif=',unif);
		
		// Add UIs
		for (i in unif) {
			if (unif[i].ui == 'colorpicker') {
				var paramname = unif[i].name;
				var d = document.createElement('div');
				d.classList.add('ppTable');
				d.innerHTML = '<div class="ppRow">' +
							'<div class="ppCell ppTri"><div class="KCaption">'+unif[i].label+':</div></div>' +
							'<div class="ppCell"><div class="KColorPicker" id="'+paramname+'"></div></div>' +
							'</div>';
				pp.appendChild(d);
			} else if (unif[i].ui == 'slider') {
				var paramname = unif[i].name;
				var d = document.createElement('div');
				d.classList.add('ppTable');
				d.innerHTML = '<div class="ppRow"><div class="ppCell ppTri">' +
					'<div class="KCaption">'+unif[i].label+':</div></div>' +
					'<div class="ppCell"><div class="KSlider" id="'+paramname+'"></div>' +
					'</div></div>';
				pp.appendChild(d);
			} else if (unif[i].ui == 'vec3') {
				var paramname = unif[i].name;
				var d = document.createElement('div');
				d.classList.add('ppTable');
				d.innerHTML = '<div class="ppRow">' +
					'<div class="ppCell ppTri"><div class="KCaption">'+unif[i].label+':</div></div>' +
					'<div class="ppCell"><input class="KInput ppFull" id="'+paramname+'_x" type="number"></div>' +
					'<div class="ppCell"><input class="KInput ppFull" id="'+paramname+'_y" type="number"></div>' +
					'<div class="ppCell"><input class="KInput ppFull" id="'+paramname+'_z" type="number"></div>' +
					'</div>';
				pp.appendChild(d);
			
			} else if (unif[i].ui == 'transferfunction') {
				var paramname = unif[i].name;
				var d = document.createElement('div');
				d.classList.add('ppTable');
				d.innerHTML = '<div class="ppRow"><div class="ppCell ppTri"><div class="KCaption">'+unif[i].label+':</div></div></div>'
				pp.appendChild(d);
				
				d = document.createElement('div');
				d.classList.add('ppTable');
				d.innerHTML = '<div class="ppRow">' +
					'<div class="ppCell" style="width:8px"></div>' +
					'<div class="ppCell">' +
					'<div class="KTransferFunction" id="'+paramname+'"></div>' +
					'</div></div>';
				pp.appendChild(d);
			} else {
				console.log('Error: Unkown UI type -> ' + unif[i].ui + ' - ' + unif[i].name);
			}
		}
		kvtoolsUI_update(pp);
		
		// set parameters
		console.log($('list-itemlist'));
		var name = $('list-itemlist').GetSelectedValue(); // selected item name
		var dt = core.GetObjectList();
		console.log('!!!!!SET PARAMETERS!!:' + name);
		if (!dt[name]) {
			console.log('not found item:'+name);
			return;
		}

		for (i in unif) {
			console.log('label = ' + unif[i].label, 'name = ' + unif[i].name, 'val = ' + unif[i].val);
			var paramname = unif[i].name;
			console.log('paramname=' + paramname);
			if (unif[i].ui === 'colorpicker') {
				console.log('data.vec4[name]:',dt[name].vec4[paramname]);
				if (dt[name].vec4[paramname]) {
					$(paramname).setColor(dt[name].vec4[paramname][0],
										  dt[name].vec4[paramname][1],
										  dt[name].vec4[paramname][2],
										  dt[name].vec4[paramname][3]);
				} else {
					console.log('Default value = ', unif[i].val);
					$(paramname).setColor(unif[i].val[0], unif[i].val[1], unif[i].val[2], unif[i].val[3]);
				}
			} else if (unif[i].ui === 'slider') {
				console.log('setslider:',dt[name].float[paramname]);
				$(paramname).setMaxValue(unif[i].max);
				$(paramname).setMinValue(unif[i].min);
				if (dt[name].float[paramname]) {
					$(paramname).setValue(dt[name].float[paramname]);
				} else {
					console.log('UI = ', $(paramname));
					console.log('Default value = ', unif[i].val);
					$(paramname).setValue(unif[i].val);
				}
				
			} else if (unif[i].ui == 'vec3') {
				console.log('data.vec3[name]:',dt[name].vec3[paramname]);
				if (dt[name].vec3[paramname]) {
					document.getElementById(paramname+'_x').value = dt[name].vec3[paramname][0];
					document.getElementById(paramname+'_y').value = dt[name].vec3[paramname][1];
					document.getElementById(paramname+'_z').value = dt[name].vec3[paramname][2];
					
				} else {
					console.log('Default value = ', unif[i].val);
					document.getElementById(paramname+'_x').value = unif[i].val[0];
					document.getElementById(paramname+'_y').value = unif[i].val[1];
					document.getElementById(paramname+'_z').value = unif[i].val[2];
				}
			} else if (unif[i].ui === 'transferfunction') {
				if (dt[name].volumeAnalyzeResult) {
					if (unif[i].component) {
						$(paramname).setAnalyzeResult(dt[name].volumeAnalyzeResult, parseInt(unif[i].component));
					} else {
						$(paramname).setAnalyzeResult(dt[name].volumeAnalyzeResult, 0);
					}
				}
				if (dt[name].vec4array[paramname]) {
					
					console.log('vec4array['+paramname+'] = ',dt[name].vec4array[paramname]);
					// TODO
					var i,
						num = dt[name].vec4array[paramname][0],
						src = dt[name].vec4array[paramname][1],
						volMin = dt[name].vec3['vol_min'],
						volMax = dt[name].vec3['vol_max'];
					
					for (i = 0; i < 255; ++i) {
						$(paramname).setGraphValue(i, src[4*i], src[4*i+1], src[4*i+2], src[4*i+3]);
					}
					console.log('SET MIN:',volMin);
					if (volMin) {
						console.log('SET MIN:',volMin[0]);
						$(paramname).setMinValue(volMin[0]);
					}
					if (volMax) {
						$(paramname).setMaxValue(volMax[0]);
					}
					
				}
				$(paramname).drawGraph();
			}
		}
	});
	
	core.SyncObjectList();
	core.RequestShaderList();
	
	var setProperty = function (name){
		var dt = core.GetObjectList();
		if (!dt[name]) {
			console.log('not found item:'+name);
			return;
		}
		console.log('setProperty');
		setPropertyMode(dt[name].modeltype);
		setObjectProperty(name);
	};

	var setPropertyMode = function (mode){
		if (mode === 'camera') {
			document.getElementById('object-transformshader').style.display = 'none';
			document.getElementById('object-viewsyncbutton').style.display = '';
		} else {
			document.getElementById('object-transformshader').style.display = '';
			document.getElementById('object-viewsyncbutton').style.display = 'none';
		}
	}
	var setObjectProperty = function (name){
		var dt = core.GetObjectList();
		document.getElementById('objname').value = name;
		document.getElementById('translate_x').value = dt[name].translation[0];
		document.getElementById('translate_y').value = dt[name].translation[1];
		document.getElementById('translate_z').value = dt[name].translation[2];
		document.getElementById('rotate_x').value = dt[name].rotation[0];
		document.getElementById('rotate_y').value = dt[name].rotation[1];
		document.getElementById('rotate_z').value = dt[name].rotation[2];
		document.getElementById('scale_x').value = dt[name].scale[0];
		document.getElementById('scale_y').value = dt[name].scale[1];
		document.getElementById('scale_z').value = dt[name].scale[2];
	
		var shadername = dt[name].shader,
			targetShader = null,
			i;
		$('shader_name').Clear();
		for (i in shaderList) {
			if (shaderList[i].param.type !== dt[name].modeltype) {
				continue;
			}
			if (shaderList[i].file == shadername)
				targetShader = shaderList[i];
			
			var idname = shaderList[i].file.replace('.','_');
			idname = 'SHADERITEM_' + idname;
			$('shader_name').AddItem(shaderList[i].file, shaderList[i].image, idname);
		
			var it = document.getElementById(idname),
				slist = document.getElementById('shader_name');
			it.onclick = function (filename,it,slist) { return function() {
				$('shader_name').Select(filename);
			}}(shaderList[i].file,it,slist);
		}
		$('shader_name').Select(dt[name].shader); // add shader parameters after SELECT.
		
	}
	
	$('showconsole').clickFunc = function(){
		var ca = document.getElementById('consoleArea');
		if (ca.style.display === "none") {
			ca.style.display = '';
		} else {
			ca.style.display = 'none';
		}
	};
	
	$('list-addbutton').clickFunc = function(){
		//openfileDialog('/');
		opensavedlg.OpenFile('', function (filename) {
			console.log("OPENPATH:" + filename);
			var sp = filename.split('/');
			var fname = sp[sp.length-1];
			var fsp = fname.split('.');
			if (fsp.length < 1){
				console.log('NO extenstoin');
				return;
			}
	
			var oppath = '';
			var ext = fsp[fsp.length - 1];
			if (ext === 'obj' || ext === 'stl' ||
				ext === 'sph' || ext === 'vol' ||
				ext === 'lpt'){
				oppath = filename;
			} else {
				console.log("Unknown extension type:" + ext);
			}
	
			// open
			if (oppath !== '') {
				console.log('LoadModel:' + oppath);
				
				// Default load function
				//core.LoadModel(oppath, '', true);
				
				
				// custom load function
				var makeNodeFuncs = {
						'obj': makeOBJLoadNode,
						'stl': makeSTLLoadNode,
						'sph': makeSPHLoadNode,
						'vol': makeVOLLoadNode,
						'lpt': makeLPTLoadNode
					},
					nodes = makeNodeFuncs[ext];
				
				nui.clearNodes();
				nui.makeNodes(nodes(oppath));
				
				var nodeDialog = document.getElementById('nodeDialog');
				nodeDialog.style.display = '';
				
				var okbtn = nodeDialog.getElementsByClassName('button_open')[0];
				var cancelbtn = nodeDialog.getElementsByClassName('button_cancel')[0];
				okbtn.onclick = function () {
					nodeDialog.style.display = 'none';
					
					var customlua = nui.exportLua();
					core.CustomLoadModel(oppath, '', customlua, true);
				}

				cancelbtn.onclick = function () {
					nodeDialog.style.display = 'none';
				}
				
			}
		});
	}
	
	$('object-viewsyncbutton').clickFunc = function () {
		core.SyncCameraView('Camera');
	}
	
	$('loadscenebtn').clickFunc = function () {
		opensavedlg.OpenFile(".json",function (filename) {
			core.LoadScene(filename);
		});
	}
	$('savescenebtn').clickFunc = function () {
		opensavedlg.SaveFile(".json", function (filename) {
			core.SaveScene(filename);
		});
	}
	
	$('projsetting').clickFunc = function () {
		$('window-projectproperty').SetShow(!$('window-projectproperty').GetShow());
	}
	$('backcolorpick').setColor(0, 0, 0, 1);
	$('backcolorpick').ChangeColorCallback(function(red,green,blue,alpha){
		console.log([red,green,blue,alpha]);
		core.SetBackGroundColor([red,green,blue,alpha]);
	});

	$('timeline').ChangeTimeCallback(function(tm) {
		$('viewmode').SetCaption('[Camera]');
		core.UpdateTime(tm, true);
	});

	$('timeline').DeleteCallback(function(name, tm) {
		core.RemoveKeyframe(name, tm);
	});

	$('timeline').SelectCallback(function(name, tm) {
		core.UpdateTime(tm);
		var lst = $('list-itemlist');
		lst.Select(name);
	});


	$('updatebutton').clickFunc = function(){
		var name = document.getElementById('objname').value,
			tx = document.getElementById('translate_x').value,
			ty = document.getElementById('translate_y').value,
			tz = document.getElementById('translate_z').value,
			rx = document.getElementById('rotate_x').value,
			ry = document.getElementById('rotate_y').value,
			rz = document.getElementById('rotate_z').value,
			sx = document.getElementById('scale_x').value,
			sy = document.getElementById('scale_y').value,
			sz = document.getElementById('scale_z').value,
			shr = $('shader_name').GetSelectedValue();

		core.SetTransform(name, tx,ty,tz,rx,ry,rz,sx,sy,sz);

		// Uniform UIs
		var targetShader = getTargetShader(shr);
		if (targetShader === null)
			return;

		var unif = targetShader.param.uniforms;
		for (var i in unif) {
			var paramname = unif[i].name;
			if (unif[i].ui === 'colorpicker') {
				var col = $(paramname).getColor();
				core.SetVec4(name, paramname, col[0], col[1], col[2], col[3]);
			} else if (unif[i].ui === 'vec3') {
				var tx = parseFloat(document.getElementById(paramname+'_x').value);
				var ty = parseFloat(document.getElementById(paramname+'_y').value);
				var tz = parseFloat(document.getElementById(paramname+'_z').value);
				core.SetVec3(name, paramname, tx, ty, tz);
			} else if (unif[i].ui === 'slider') {
				var v = $(paramname).getValue();
				core.SetFloat(name, paramname, v);
			} else if (unif[i].ui === 'transferfunction') {
				var v_r = $(paramname).getGraphValueRed(),
					v_g = $(paramname).getGraphValueGreen(),
					v_b = $(paramname).getGraphValueBlue(),
					v_a = $(paramname).getGraphValueAlpha(),
					n = $(paramname).getNumValues(),
					v_min = $(paramname).getMinValue(),
					v_max = $(paramname).getMaxValue();
				
				// TODO
				var i, v4 = [4*i];
				for (i = 0; i < n; ++i) {
					v4[4*i  ] = v_r[i];
					v4[4*i+1] = v_g[i];
					v4[4*i+2] = v_b[i];
					v4[4*i+3] = v_a[i];
				}
				core.SetVec4Array(name, paramname, n, v4);
				console.log('TRASNFERFUNC',v_min, v_max);
				core.SetVec3(name, 'vol_min', [v_min,v_min,v_min]);
				core.SetVec3(name, 'vol_max', [v_max,v_max,v_max]);
			}
		}
		
		if (name == 'Camera') {
			core.CommitCamera('Camera');
		}
		
		core.SetShader(name, shr, true); // with update render image.
		
		// Add keyframe
		var tl = $('timeline');
		core.AddKeyframe(name, tl.getTimeValue());
	}
	
	$('rendermodebtn').clickFunc = function(){
		var mode = this.getValue();
		if (mode == 'OpenGL') {
			this.setValue('LSGL');
			core.SetRenderMode('LSGL')
			$('pixelstep').Show(true);
		} else {
			this.setValue('OpenGL');
			core.SetRenderMode('OPENGL');
			$('pixelstep').Show(false);
		}
	}
	
	$('pixelstep').onChangedFunc = function(val){
		core.SetPixelStep(val);
	}
	$('imageCompMode').onChangedFunc = function(val){
		core.SetImageCompMode(val);
	}
	
	$('exportbtn').clickFunc = function(){

		opensavedlg.SaveFile(".scn", function (filename) {
			var w = document.getElementById('screen_width').value;
			var h = document.getElementById('sceeen_height').value;
			var a = document.getElementById('screen_antialias').value;
			if (w == '')
				w = 512;
			if (h == '')
				h = 512;
			if (a == '')
				a = 1;
			var outfile = document.getElementById('outImageFile').value;
			if (outfile == '')
				outfile = 'output';
			var exttype = document.getElementById('outImageExt').value;
			
			var starttime = document.getElementById('tlStartTime').value;
			var endtime = document.getElementById('tlEndTime').value;
			var fps = document.getElementById('tlFps').value;

			core.ExportScene(filename, w, h, a, outfile, exttype, starttime, endtime, fps);
			alert('saved "' + filename + '"');
		});
	}
	
	var view = document.getElementById('result');
	view.addEventListener('mousedown', function(e){
		$('viewmode').SetCaption('[View]');
		var press = true;
		e.preventDefault();
		e.stopPropagation();
		//console.log(e.button);
		if (e.button == 0)
			core.Mouse('mouseleftdown',e.clientX,e.clientY);
		else if (e.button == 1)
			core.Mouse('mousemiddledown',e.clientX,e.clientY);
		else if (e.button == 2)
			core.Mouse('mouserightdown',e.clientX,e.clientY);
				
		var mmove = function(e){
			if (press){
				core.Mouse('mousemove',e.clientX,e.clientY);
				core.Render(wid,hei);
			}
		}
		var mup = function(e){
			document.removeEventListener('mousemove',mmove);
			document.removeEventListener('mouseup',mup);
			press = false;
			core.Mouse('mouseleftup',e.clientX,e.clientY);
			core.Mouse('mousemiddleup',e.clientX,e.clientY);
			core.Mouse('mouserightup',e.clientX,e.clientY);
		}
		document.addEventListener('mousemove', mmove);
		document.addEventListener('mouseup', mup);
	});
	view.addEventListener('touchstart', function(e){
		$('viewmode').SetCaption('[View]');
		var press = true;
		e.preventDefault();
		e.stopPropagation();
		//console.log(e.button);
		if (e.touches.length == 1) {
			core.Mouse('mouseleftdown',e.touches[0].clientX,e.touches[0].clientY);
		} else if (e.touches.length == 2) {
			var cx = (e.touches[0].clientX + e.touches[1].clientX) * 0.5,
				cy = (e.touches[0].clientY + e.touches[1].clientY) * 0.5;
			core.Mouse('mouserightdown',cx,cy);
		}
		var mmove = function(e){
			if (press){
				core.Mouse('mousemove',e.touches[0].clientX,e.touches[0].clientY);
				core.Render(wid,hei);
			}
		}
		var mup = function(e){
			document.removeEventListener('mousemove',mmove);
			document.removeEventListener('mouseup',mup);
			press = false;
			core.Mouse('mouseleftup',e.touches[0].clientX,e.touches[0].clientY);
			core.Mouse('mousemiddleup',e.touches[0].clientX,e.touches[0].clientY);
			core.Mouse('mouserightup',e.touches[0].clientX,e.touches[0].clientY);
		}
		document.addEventListener('touchmove', mmove);
		document.addEventListener('touchend', mup);
	});

}

function canvasResizing(){
	var w = document.getElementById('window-view').clientWidth,
		h = document.getElementById('window-view').clientHeight;
	var rc = document.getElementById('result');
	var tcan = document.getElementById('tmp')
	rc.width    = w;
	rc.height   = h;
	tcan.width  = w;
	tcan.height = h;
	wid = w;
	hei = h;
}

window.onresize = function(){
	canvasResizing();
	core.Render(wid,hei);
}
