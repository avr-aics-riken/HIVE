gen_patch.sh

変更前 dir : ~/src/Mesa-9.0.1.org/src/glsl
変更後 dir : ~/src/Mesa-9.0.1.lsgl/src/glsl

として patch を生成する.
