/*jslint devel:true*/
/*jslint nomen: true*/
/*global __dirname, require*/
/*jslint nomen: false*/

if (typeof (window) === 'undefined') { // node.js
	/*jslint nomen: true*/
	var dirname = __dirname;
	/*jslint nomen: false*/
	var path = require('path'),
		ServerImager = require('./ServerImager'),
		render = require(dirname + '/../node/krender'),
		fs = require('fs'),
		os = require('os'),
		exec = require('child_process').exec;
	
	/*var VOLUMEANALYZE_EXE  = './volanalyze.exe';
	if (os.platform() === "darwin") {
		VOLUMEANALYZE_EXE  = './volanalyze_mac';
	} else if (os.platform() === "linux") {
		VOLUMEANALYZE_EXE  = './volanalyze_linux';
	}*/
	
	var localCmd = function (cmd, callback) {
		'use strict';
		var child = exec(cmd,
			function (cb) {
				return function (error, stdout, stderr) {
					console.log('stdout: ' + stdout);
					console.log('stderr: ' + stderr);
					if (error !== null) {
						console.log('exec error: ' + error);
					}
					if (cb) {
						cb(error, stdout, stderr);
					}
				};
			}(callback));
	};
	
	var shaderspath = dirname + '/../shader'; // relative path from this file.

	var copyFile = function (src, dest) {
		'use strict';
		fs.createReadStream(src).pipe(fs.createWriteStream(dest));
	};
	
	var KVToolsCore = function () {
		this.r_w = 0;
		this.r_h = 0;
		this.rendering = false;
		this.backgroundColor = [0.0, 0.0, 0.0, 1.0];
		
		render.makeContext(128, 128, shaderspath); // default buffer.
		
		this.socket = null;
		this.objProperty = {};
		this.objTimeline = {};
		
		var core = this;
		
		function renderFunc(w, h, renderCompMode) {
			//console.log('render mode = ', w , h, renderCompMode);
			// TODO: rendering queing system
			if (core.rendering) {
				return;
			}
			core.rendering = true;

			var buf = this.GetBuffer();
			if (core.r_w !== w || core.r_h !== h) {
				console.log('create context', w, h);
				render.makeContext(w, h, shaderspath);
				render.setPixelStep(1);
				core.SetBackGroundColor(core.backgroundColor);
				core.r_w = w;
				core.r_h = h;
			}
			render.renderCallback(w, h, buf, (renderCompMode | 0), function (si, buf) { return function (imageSize) {
				//console.log('imageSize = ' + imageSize);
				var sendbuf = buf;
				if (w * h * 4 > imageSize) {
					sendbuf = buf.slice(0, imageSize);
				}
				si.SendImage(sendbuf);
				core.rendering = false;
			}; }(this, buf));
		}
		this.AddCamera();
		this.simage = new ServerImager(renderFunc);
	};
	
	KVToolsCore.prototype.Render = function () {
		'use strict';
		this.simage.Render();
	};
	KVToolsCore.prototype.ResizeRender = function (w, h) {
		'use strict';
		this.simage.Resize(w, h);
	};
	
	KVToolsCore.prototype.NewObject = function (name, datapath, shaderfile, modeltype) {
		'use strict';
		this.objProperty[name] = {
			translation: [0, 0, 0],
			rotation: [0, 0, 0],
			scale: [1, 1, 1],
			vec4: {},
			vec3: {},
			vec2: {},
			vec4array: {},
			float: {},
			path: datapath,
			shader: shaderfile,
			modeltype: modeltype,
			loadLua: ''
		};
	};
	KVToolsCore.prototype.DeleteObject = function (name, datapath) {
		'use strict';
		delete this.objProperty[name];
		delete this.objTimeline[name];
	};

	KVToolsCore.prototype.DeleteAllObjects = function (name, datapath) {
		'use strict';
		this.objProperty = {};
		this.objTimeline = {};
	};
	
	KVToolsCore.prototype.AddCamera = function () {
		'use strict';
		var name = 'Camera';
		this.NewObject(name, '', 'camera.frag', 'camera');
		this.objProperty[name].vec3.eye    = [0, 0, 300];
		this.objProperty[name].vec3.lookat = [0, 0, 299];
		this.objProperty[name].vec3.up     = [0, 1, 0];
		this.objProperty[name].float.near  = 1.0;
		this.objProperty[name].float.far   = 1000.0;
		this.objProperty[name].float.fov   = 60.0;
	};

	function dataClone(orgobj) {
		return JSON.parse(JSON.stringify(orgobj));
	}
/*	function dataClone(obj) {
		 if (null == obj || "object" != typeof obj) return obj;
		var copy = obj.constructor();
		for (var attr in obj) {
			if (obj.hasOwnProperty(attr)){
				copy[attr] = obj[attr];
			}
		}
		return copy;
	}*/

	
	KVToolsCore.prototype.UpdateTime = function (tm) {
		var name,
			i, t, n, k, r, p0, p1, j, h, vp0, vp1, tpp,
			tl = this.objTimeline;
		
		for (name in tl) {
			if (tl.hasOwnProperty(name)) {
				//console.log('obj name = ', name);
				n = tl[name].length;
				if (n === 0) { // no key
					continue; // next Obj
				}
				if (n === 1 || tm <= tl[name][0].time) { // 1 key
					//console.log("key=0");
					this.objProperty[name] = dataClone(tl[name][0].data);
					continue;
				}

				// some keys
				k = n;
				for (i = 0; i < n - 1; i += 1) {
					if (tl[name][i].time <= tm && tm < tl[name][i+1].time) { // find
						k = i;
						break;
					}
				}
				if (k === n) { // last key
					//console.log("key=",n-1);
					this.objProperty[name] = dataClone(tl[name][n-1].data);
				} else {
					
					this.objProperty[name] = dataClone(tl[name][k].data); // no interpolate
										
					// interpolate
					r = (tm - tl[name][i].time) / (tl[name][i+1].time - tl[name][i].time);
					p0 = tl[name][i  ].data;
					p1 = tl[name][i+1].data;
					
					//console.log("key=",k, r);
					
					// transform

					for (j = 0; j < 3; j += 1) {
						this.objProperty[name].translation[j] = p0.translation[j] + (p1.translation[j] - p0.translation[j]) * r;
						this.objProperty[name].rotation[j]    = p0.rotation[j]    + (p1.rotation[j]    - p0.rotation[j]   ) * r;
						this.objProperty[name].scale[j]       = p0.scale[j]       + (p1.scale[j]       - p0.scale[j]      ) * r;
					}
					//console.log('trans', this.objProperty[name].translation[0], this.objProperty[name].translation[1], this.objProperty[name].translation[2]);
					//console.log('rot', this.objProperty[name].rotation[0], this.objProperty[name].rotation[1], this.objProperty[name].rotation[2]);
					//console.log('scale', this.objProperty[name].scale[0], this.objProperty[name].scale[1], this.objProperty[name].scale[2]);
					
					// Uniforms
					for (j in p0.vec4) {
						this.objProperty[name].vec4[j][0] = p0.vec4[j][0] + (p1.vec4[j][0] - p0.vec4[j][0]) * r;
						this.objProperty[name].vec4[j][1] = p0.vec4[j][1] + (p1.vec4[j][1] - p0.vec4[j][1]) * r;
						this.objProperty[name].vec4[j][2] = p0.vec4[j][2] + (p1.vec4[j][2] - p0.vec4[j][2]) * r;
						this.objProperty[name].vec4[j][3] = p0.vec4[j][3] + (p1.vec4[j][3] - p0.vec4[j][3]) * r;
					}
					for (j in p0.vec3) {
						this.objProperty[name].vec3[j][0] = p0.vec3[j][0] + (p1.vec3[j][0] - p0.vec3[j][0]) * r;
						this.objProperty[name].vec3[j][1] = p0.vec3[j][1] + (p1.vec3[j][1] - p0.vec3[j][1]) * r;
						this.objProperty[name].vec3[j][2] = p0.vec3[j][2] + (p1.vec3[j][2] - p0.vec3[j][2]) * r;
					}
					for (j in p0.vec2) {
						this.objProperty[name].vec2[j][0] = p0.vec2[j][0] + (p1.vec2[j][0] - p0.vec2[j][0]) * r;
						this.objProperty[name].vec2[j][1] = p0.vec2[j][1] + (p1.vec2[j][1] - p0.vec2[j][1]) * r;
					}
					for (j in p0.float) {
						this.objProperty[name].float[j] = p0.float[j] + (p1.float[j] - p0.float[j]) * r;
					}

					for (j in p0.vec4array) {
						tpp = this.objProperty[name].vec4array[j];
						vp0 = p0.vec4array[j];
						vp1 = p1.vec4array[j];
						tpp[0] = vp0[0]; // num
						if (vp1) {
							for (h = 0; h < vp0[1].length; h += 1) { //values
								tpp[1][h] = vp0[1][h] + (vp1[1][h] - vp0[1][h]) * r;
							}
						}
					}

					// ignore shader interpolate
					/*
					for (j = 0; j < p.shader.length; j += 1) {
					}
					*/
					
					// TODO
					this.objProperty[name].shader = p0.shader;
				}

			}
		}
		
		this.SyncObjectList();
	};
	
	KVToolsCore.prototype.RemoveKeyframe = function (objname, tm) {
		var frameTime = tm.toFixed(3),
			i;

		for (i = 0; i < this.objTimeline[objname].length; i += 1) {
			if(this.objTimeline[objname][i].time === frameTime) {
				this.objTimeline[objname].splice(i,1);
				break;
			}
		}
		this.SyncObjectList();
	};
	KVToolsCore.prototype.AddKeyframe = function (objname, tm) {
		console.log('AddkeyFrame:'+objname, tm);
		if (!this.objProperty.hasOwnProperty(objname)) {
			console.log('not found name:' + objname);
			return;
		}
		var i,
			frameTime = tm.toFixed(3),
			tdata = {
				time: frameTime,
				data: dataClone(this.objProperty[objname])
			};
		//console.log(frameTime, tdata);
		
		if (!this.objTimeline[objname]) {
			this.objTimeline[objname] = [];
		}
		
		// delete old frame
		for (i = 0; i < this.objTimeline[objname].length; i += 1) {
			if(this.objTimeline[objname][i].time === frameTime) {
				this.objTimeline[objname].splice(i,1);
				break;
			}
		}
		// new frame
		this.objTimeline[objname].push(tdata);
		
		this.objTimeline[objname].sort(
			function(a,b) {
				return a.time - b.time;
			}
		);
		
		// overwrite shaders
		/*for (i = 0; i < this.objTimeline[objname].length; i += 1) {
			this.objTimeline[objname][i].data.shader = this.objProperty[objname].shader;
		}*/
		
		this.SyncObjectList();
	};
	
	function setVolumeAnalyzeResult(core, name, datapath, shaderfile, modeltype) {
		'use strict';
		return function (err, stdout, stderr) {
			if (!err) {
				core.objProperty[name].volumeAnalyzeResult = JSON.parse(stdout);
				console.log(core.objProperty[name].volumeAnalyzeResult);
				var res = core.objProperty[name].volumeAnalyzeResult,
					dataset = {};
				if (res && res.type === 'vector') {
					dataset.vol_min = [res.min[0], res.min[1], res.min[2]];
					dataset.vol_max = [res.max[0], res.max[1], res.max[2]];
					core.SetVec3s(name, dataset);
				} else if (res && res.type === 'scalar') {
					dataset.vol_min = [res.min, res.min, res.min];
					dataset.vol_max = [res.max, res.max, res.max];
					core.SetVec3s(name, dataset);
				} else {
					console.log('[Error] VolumeAnalyzer unknown data type.');
				}
				core.objProperty[name].vec3['vol_min'] = dataset.vol_min;
				core.objProperty[name].vec3['vol_max'] = dataset.vol_max;
				
				core.SyncObjectList();
			}
		};
	}
	
	function exportLua(customjson) {
		'use strict';
		// TODO
	}
	
	KVToolsCore.prototype.CustomLoadModel = function (name, datapath, customlua) {
		'use strict';
		var srclua,
			ext = path.extname(datapath).toLowerCase(),
			tarModel = '',
			shaderfile,
			e,
			modeltype;
		
		if (ext === '.obj') {
			tarModel = 'PolygonModel';
		} else if (ext === '.stl') {
			tarModel = 'PolygonModel';
		} else if (ext === '.vol') {
			tarModel = 'VolumeModel';
		} else if (ext === '.sph') {
			tarModel = 'VolumeModel';
		} else if (ext === '.lpt') {
			tarModel = 'ParticleModel';
		} else {
			console.log('Unsupported data format:' + ext);
			return;
		}

		console.log("Type=" + tarModel, datapath);

		var volAnalyzeFunc = null;
		
		if (tarModel === 'PolygonModel') {
			shaderfile = 'def_polygon.frag';
			modeltype = 'polygon';
			
			this.NewObject(name, datapath, shaderfile, modeltype);
			this.SyncObjectList();
			
		} else if (tarModel === 'VolumeModel') {
			shaderfile = 'def_volume.frag';
			modeltype = 'volume';

			this.NewObject(name, datapath, shaderfile, modeltype);
			//localCmd(VOLUMEANALYZE_EXE + ' ' + datapath, setVolumeAnalyzeResult(this, name, datapath, shaderfile, modeltype));
			volAnalyzeFunc = setVolumeAnalyzeResult(this, name, datapath, shaderfile, modeltype);

		} else if (tarModel === 'ParticleModel') {
			shaderfile = 'def_point.frag';
			modeltype = 'particle';
			
			this.NewObject(name, datapath, shaderfile, modeltype);
			this.SyncObjectList();
			
		} else {
			console.log('Unsupported model type:' + tarModel);
			return;
		}
		
		this.objProperty[name].loadLua = customlua;
		
		srclua = customlua;
		srclua += 'root:SetShader("' + shaderspath + '/' + shaderfile + '");';
		//srclua += 'print("metatable=",getmetatable(root));';
		srclua += 'local c = Core();';
		srclua += 'c:AddRenderObject("' + name + '",root);';
		
		//console.log(srclua);
		e = render.sceneLua(srclua);
		
		if (volAnalyzeFunc){
			var vainfo = render.getVolumeAnalyzeData(name);
			//console.log(vainfo);
			volAnalyzeFunc('',vainfo,'');
		}
		//console.log('Script:' + e);
		this.ConsoleLog(e);

		console.log('Loaded model:' + name);
	};
	
	KVToolsCore.prototype.LoadModel = function (name, datapath) {
		'use strict';
		var luasrc,
			ext = path.extname(datapath).toLowerCase(),
			tarModel = '',
			shaderfile,
			e,
			modeltype;
		
		if (ext === '.obj') {
			luasrc = 'local objdata = OBJLoader();';
			tarModel = 'PolygonModel';
		} else if (ext === '.stl') {
			luasrc = 'local objdata = STLLoader();';
			tarModel = 'PolygonModel';
		} else if (ext === '.vol') {
			luasrc = 'local objdata = VOLLoader();';
			tarModel = 'VolumeModel';
		} else if (ext === '.sph') {
			luasrc = 'local objdata = SPHLoader();';
			tarModel = 'VolumeModel';
		} else if (ext === '.lpt') {
			luasrc = 'local objdata = LPTLoader();';
			tarModel = 'ParticleModel';
		} else {
			console.log('Unsupported data format:' + ext);
			return;
		}

		console.log("Type=" + tarModel, datapath);

		luasrc += 'objdata:Load("' + datapath + '");';
		if (tarModel === 'PolygonModel') {
			luasrc += 'local mdl = PolygonModel();';
			luasrc += 'mdl:Create(objdata:Position(), objdata:Normal(), objdata:Material(), objdata:Index());';
			shaderfile = 'def_polygon.frag';
			modeltype = 'polygon';
			
			this.NewObject(name, datapath, shaderfile, modeltype);
			this.SyncObjectList();
			
		} else if (tarModel === 'VolumeModel') {
			luasrc += 'local mdl = VolumeModel();';
			luasrc += 'mdl:Create(objdata:Width(), objdata:Height(), objdata:Depth(), objdata:Component(), objdata:Buffer());';
			shaderfile = 'def_volume.frag';
			modeltype = 'volume';
			
			this.NewObject(name, datapath, shaderfile, modeltype);
			//localCmd(VOLUMEANALYZE_EXE + ' ' + datapath, setVolumeAnalyzeResult(this, name, datapath, shaderfile, modeltype));
			
		} else if (tarModel === 'ParticleModel') {
			luasrc += 'local mdl = ParticleModel();';
			console.log("TODO:ParticleModel func");
			luasrc += 'mdl:Create(objdata:Position(), objdata:Radius(), objdata:Material());';
			shaderfile = 'def_point.frag';
			modeltype = 'particle';
			
			this.NewObject(name, datapath, shaderfile, modeltype);
			this.SyncObjectList();
			
		} else {
			console.log('Unsupported model type:' + tarModel);
			return;
		}
		luasrc += 'mdl:SetShader("' + shaderspath + '/' + shaderfile + '");';
		luasrc += 'print("metatable=",getmetatable(mdl));';
		luasrc += 'local c = Core();';
		luasrc += 'c:AddRenderObject("' + name + '",mdl);';
		e = render.sceneLua(luasrc);
		console.log('Error:' + e);
		
		console.log('Loaded model:' + name);
		
	};
	
	KVToolsCore.prototype.GetLuaTransform = function (name, data) {
		'use strict';
		var tx = parseFloat(data.translation[0]),
			ty = parseFloat(data.translation[1]),
			tz = parseFloat(data.translation[2]),
			rx = parseFloat(data.rotation[0]),
			ry = parseFloat(data.rotation[1]),
			rz = parseFloat(data.rotation[2]),
			sx = parseFloat(data.scale[0]),
			sy = parseFloat(data.scale[1]),
			sz = parseFloat(data.scale[2]),
			luasrc = 'local obj = Core():GetRenderObjectByName("' + name + '");\n';
		
		luasrc += 'if (obj) then\n';
		luasrc += '	obj:SetTranslate(' + tx + ',' + ty + ',' + tz + ')\n';
		luasrc += '	obj:SetRotate(' + rx + ',' + ry + ',' + rz + ')\n';
		luasrc += '	obj:SetScale(' + sx + ',' + sy + ',' + sz + ')\n';
		luasrc += 'end\n';
		return luasrc;
	};
	KVToolsCore.prototype.SetTransform = function (name, data) {
		'use strict';
		var luasrc = this.GetLuaTransform(name, data);
		render.sceneLua(luasrc);

		var tx = parseFloat(data.translation[0]),
			ty = parseFloat(data.translation[1]),
			tz = parseFloat(data.translation[2]),
			rx = parseFloat(data.rotation[0]),
			ry = parseFloat(data.rotation[1]),
			rz = parseFloat(data.rotation[2]),
			sx = parseFloat(data.scale[0]),
			sy = parseFloat(data.scale[1]),
			sz = parseFloat(data.scale[2]);
		this.objProperty[name].translation = [tx, ty, tz];
		this.objProperty[name].rotation    = [rx, ry, rz];
		this.objProperty[name].scale       = [sx, sy, sz];
	};
	
	KVToolsCore.prototype.GetLuaShader = function (name, shader, shaderPath) {
		'use strict';
		var luasrc = 'local obj = Core():GetRenderObjectByName("' + name + '");\n';
		luasrc += 'if (obj) then\n';
		luasrc += '	obj:SetShader("' + shaderPath + shader + '")\n';
		luasrc += 'end\n';
		return luasrc;
	};
	KVToolsCore.prototype.SetShader = function (name, shader) {
		'use strict';
		console.log('SET shader>' + name + ':' + shader);
		var luasrc = this.GetLuaShader(name, shader, shaderspath + '/'),
			i;
		render.sceneLua(luasrc);
		
		this.objProperty[name].shader = shader;
		/*if (this.objTimeline[name]) {
			console.log('AAAA', this.objTimeline[name].length);
			for (i = 0; i < this.objTimeline[name].length; i += 1) {
				this.objTimeline[name][i].shader = shader;
			}
		}*/
	};

	KVToolsCore.prototype.GetLuaFloats = function (name, vals) {
		'use strict';
		if (vals.length === 0) {
			return '';
		}
		var i,
			uniformName,
			val,
			luasrc = 'local obj = Core():GetRenderObjectByName("' + name + '");\n';
		luasrc += 'if (obj) then\n';
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				uniformName = i;
				val = vals[i];
				luasrc += 'obj:SetFloat("' + uniformName + '",' + val + ');\n';
			}
		}
		luasrc += 'end\n';
		return luasrc;
	};
	KVToolsCore.prototype.SetFloats = function (name, vals) {
		'use strict';
		var luasrc = this.GetLuaFloats(name, vals),
			i;
		if (luasrc !== '') {
			render.sceneLua(luasrc);
		}
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				this.objProperty[name].float[i] = vals[i];
			}
		}
	};
	

	KVToolsCore.prototype.GetLuaVec4Arrays = function (name, vals) {
		'use strict';
		if (vals.length === 0) {
			return '';
		}
		var nameext = name.split('.'),
			luasrc = 'local obj = Core():GetRenderObjectByName("' + name + '");\n',
			i,
			j,
			val,
			varname,
			uniformName;
		// make vec4buffer
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				val = vals[i];
				varname = nameext[0] + '_' + nameext[1] + '_v4_' + i;

				luasrc += 'local ' + varname + ' = Vec4Buffer();\n';
				luasrc += varname + ':Create(' + 256 + ');\n';
				for (j = 0; j < val[0]; j += 1) {
					luasrc += varname + ':Set(' + j + ',' + val[1][4 * j] + ',' + val[1][4 * j + 1] + ',' + val[1][4 * j + 2] + ',' + val[1][4 * j + 3] + ');\n';
				}
			}
		}
		
		luasrc += 'if (obj) then \n';
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				val = vals[i];
				varname = nameext[0] + '_' + nameext[1] + '_v4_' + i;
				uniformName = i;
				luasrc += '	obj:SetVec4Array("' + uniformName + '",' + varname + '); \n';
			}
		}
		luasrc += 'end\n';
		
		//console.log('src=', luasrc);
		return luasrc;
	};
	KVToolsCore.prototype.SetVec4Arrays = function (name, vals) {
		'use strict';
		var luasrc = this.GetLuaVec4Arrays(name, vals),
			i;
		if (luasrc !== '') {
			render.sceneLua(luasrc);
		}
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				this.objProperty[name].vec4array[i] = vals[i]; // [num, data]
			}
		}
	};
	
	KVToolsCore.prototype.GetLuaVec4s = function (name, vals) {
		'use strict';
		if (vals.length === 0) {
			return '';
		}
		var luasrc = 'local obj = Core():GetRenderObjectByName("' + name + '");\n',
			i,
			uniformName,
			val;
		luasrc += 'if (obj) then\n';
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				uniformName = i;
				val = vals[i];
				luasrc += '	obj:SetVec4("' + uniformName + '",' + val[0] + ',' + val[1] + ',' + val[2] + ',' + val[3] + ')\n';
			}
		}
		luasrc += 'end\n';
		render.sceneLua(luasrc);
		return luasrc;
	};
	KVToolsCore.prototype.SetVec4s = function (name, vals) {
		'use strict';
		var luasrc = this.GetLuaVec4s(name, vals),
			i;
		if (luasrc !== '') {
			render.sceneLua(luasrc);
		}
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				this.objProperty[name].vec4[i] = vals[i];
			}
		}
	};

	KVToolsCore.prototype.GetLuaVec3s = function (name, vals) {
		'use strict';
		if (vals.length === 0) {
			return '';
		}
		var luasrc = 'local obj = Core():GetRenderObjectByName("'+name+'");\n',
			i;
		luasrc += 'if (obj) then\n'
		for (i in vals) {
			var uniformName = i;
			var val = vals[i];
			luasrc += '	obj:SetVec3("'+uniformName+'",'+val[0]+','+val[1]+','+val[2]+')\n';
		}
		luasrc += 'end\n';
		return luasrc;
	};
	KVToolsCore.prototype.SetVec3s = function (name, vals) {
		'use strict';
		var luasrc = this.GetLuaVec3s(name, vals),
			i;
		if (luasrc !== '') {
			render.sceneLua(luasrc);
		}
		for (i in vals) {
			if (vals.hasOwnProperty(i)) {
				this.objProperty[name].vec3[i] = vals[i];
			}
		}
	};
	
	KVToolsCore.prototype.GetLuaVec2s = function (name, vals) {
		'use strict';
		if (vals.length === 0) {
			return '';
		}
		var luasrc = 'local obj = Core():GetRenderObjectByName("'+name+'");\n',
			i;
		luasrc += 'if (obj) then\n'
		for (i in vals) {
			var uniformName = i;
			var val = vals[i];
			luasrc += '	obj:SetVec2("'+uniformName+'",'+val[0]+','+val[1]+')\n';
		}
		luasrc += 'end\n';
		return luasrc;
	};
	KVToolsCore.prototype.SetVec2s = function (name, vals) {
		'use strict';
		var luasrc = this.GetLuaVec2s(name, vals),
			i;
		if (luasrc !== '') {
			render.sceneLua(luasrc);
		}
		for (var i in vals) {
			var uniformName = i;
			var val = vals[i];
			luasrc += 'obj:SetVec2("'+uniformName+'",'+val[0]+','+val[1]+')';
			this.objProperty[name].vec2[uniformName] = val;
		}

	};

	KVToolsCore.prototype.GetLuaBackGroundColor = function (val) {
		'use strict';
		if (!val) {
			return '';
		}
		this.backgroundColor = [val[0], val[1], val[2], val[3]];
		var luasrc = 'Core():ClearColor(' + val[0] + ',' + val[1] + ',' + val[2] + ',' + val[3] + ')';
		return luasrc;
	};

	KVToolsCore.prototype.SetBackGroundColor = function (val) {
		'use strict';
		if (!val) {
			return;
		}
		var luasrc = this.GetLuaBackGroundColor(val);
		render.sceneLua(luasrc);
	};

	
	KVToolsCore.prototype.CommitCamera = function (name) {
		// Test function
		//console.log('commit camera:'+name);
		if (!this.objProperty[name]) {
			console.log('Not found object property:' + name);
			return ;
		}
		var eye = this.objProperty[name].vec3['eye'],
			lookat = this.objProperty[name].vec3['lookat'],
			up = this.objProperty[name].vec3['up'],
			fov = this.objProperty[name].float['fov'],
			nearval = this.objProperty[name].float['near'],
			farval = this.objProperty[name].float['far'];
		render.lookAt(eye[0],eye[1],eye[2],
						lookat[0],lookat[1],lookat[2],
						up[0],up[1],up[2]);
		render.setFov(fov);
		render.setNearFar(nearval, farval);
		this.Render();
	}
	
	KVToolsCore.prototype.genFrameScene = function(basepath, outputFileName) {
		var core = this,
			buf = "";
		
		buf += 'local outputfile = "' + outputFileName + '"\n';
		
		// Camera
		buf += 'camera = {\n';
		var cameraName = 'Camera';
		var eye = core.objProperty[cameraName].vec3['eye'],
			tar = core.objProperty[cameraName].vec3['lookat'],
			up = core.objProperty[cameraName].vec3['up'],
			fovval = core.objProperty[cameraName].float['fov'];
			
		buf += '    from = {'+eye[0]+','+eye[1]+','+eye[2]+'},\n';
		buf += '    to   = {'+tar[0]+','+tar[1]+','+tar[2]+'},\n';
		buf += '    up   = {'+ up[0]+','+ up[1]+','+ up[2]+'},\n';
		buf += '    fov  = '+fovval+'\n';
		buf += '}\n';
		buf += 'Core():ClearColor('+core.backgroundColor[0]+
			','+core.backgroundColor[1]+
			','+core.backgroundColor[2]+
			','+core.backgroundColor[3]+')\n';

		var i,j,k;

		// ---- Vec4Array -> Texture ----
		for (i in core.objProperty) {
			var obj = core.objProperty[i];
			for (j in obj.vec4array) {
				var fnames = path.basename(obj.path).split('.'),
					texname = fnames[0] + '_' + fnames[1] + '_'+ j,
					val = obj.vec4array[j][1],
					vnum = obj.vec4array[j][0];
				buf += 'local ' + texname + '={data={';
				for (k = 0; k < 4*vnum; ++k) {
					buf += Math.floor(val[k]*255) + ','
				}
				buf += '}}\n';
				// debug
				//buf += 'print("'+texname+'", #'+texname+'.data)\n';
			}
		}

		//console.log("Basepath = "+basepath);
		var e,exts = ['obj','stl','sph','vol','lpt'];
		for (e in exts) {
			buf += exts[e] + ' = {\n';
			for (i in core.objProperty){
				var obj = core.objProperty[i],
					objRelativePath = path.relative (basepath, obj.path),
					exttype = path.extname(obj.path).toLowerCase();
				//console.log("Relative=" + objRelativePath);
				if (exttype !== ("."+exts[e])) {
					continue;
				}
				buf += '    { file="' + objRelativePath + '"';
				buf += ', shader="'+obj.shader+'"';
				buf += ', translate={'+obj.translation[0]+','+obj.translation[1]+','+obj.translation[2]+'}';
				buf += ', rotate={'   +obj.rotation[0]   +','+obj.rotation[1]   +','+obj.rotation[2]   +'}';
				buf += ', scale={'    +obj.scale[0]      +','+obj.scale[1]      +','+obj.scale[2]      +'}';
				/*if (exts[e] === 'sph' || exts[e] === 'vol') {
					buf += ', size={'    +obj.volsize[0]      +','+obj.volsize[1]      +','+obj.volsize[2]      +'}';
				}*/

				// ---- VEC4 ----
				buf += ', vec4={';
				for (j in obj.vec4) {
					buf += j + '={'+obj.vec4[j][0]+','+obj.vec4[j][1]+','+obj.vec4[j][2]+','+obj.vec4[j][3]+'}, ';
				}
				buf += ' }';
				// ---- VEC3 ----
				buf += ', vec3={';
				for (j in obj.vec3) {
					buf += j + '={'+obj.vec3[j][0]+','+obj.vec3[j][1]+','+obj.vec3[j][2]+'}, ';
				}
				buf += ' }';
				// ---- VEC2 ----
				buf += ', vec2={';
				for (j in obj.vec2) {
					buf += j + '={'+obj.vec2[j][0]+','+obj.vec2[j][1]+'}, ';
				}
				buf += ' }';
				// ---- Float ----
				buf += ', float={';
				for (j in obj.float) {
					buf += j + '='+obj.float[j]+',';
				}
				buf += ' }';
				// ---- Vec4Array ----
				buf += ', texture={';
				for (j in obj.vec4array) {
					var fnames = path.basename(obj.path).split('.');
					var texname = fnames[0] + '_' + fnames[1] + '_'+ j;
					buf += j + '=' + texname + ', ';
				}
				buf += ' }';
				// --------------
				buf += ' },\n';

				//Shader copy
				copyFile(path.join(shaderspath,obj.shader), path.join(basepath,obj.shader));
			}
			buf += '}\n\n';
		}

		buf += 'krender(outputfile, width, height, fsaa)\n';
		return buf;
	}
	
	
	KVToolsCore.prototype.genFrameScene2 = function(basepath, outputFileName) {
		// krender2 format
		var core = this,
			buf = "";
		
		buf += 'local sceneRenderObj = {}\n';
		buf += 'local loadFunc\n';
		buf += 'local outputfile = "' + outputFileName + '"\n';
		
		// Camera
		buf += 'camera = {\n';
		var cameraName = 'Camera';
		var eye = core.objProperty[cameraName].vec3['eye'],
			tar = core.objProperty[cameraName].vec3['lookat'],
			up = core.objProperty[cameraName].vec3['up'],
			fovval = core.objProperty[cameraName].float['fov'];
			
		buf += '    from = {'+eye[0]+','+eye[1]+','+eye[2]+'},\n';
		buf += '    to   = {'+tar[0]+','+tar[1]+','+tar[2]+'},\n';
		buf += '    up   = {'+ up[0]+','+ up[1]+','+ up[2]+'},\n';
		buf += '    fov  = '+fovval+'\n';
		buf += '}\n';
		buf += 'Core():ClearColor('+core.backgroundColor[0]+
			','+core.backgroundColor[1]+
			','+core.backgroundColor[2]+
			','+core.backgroundColor[3]+')\n';

		var i,j,k;


		for (i in core.objProperty){
			buf += 'loadFunc = function () '
			if (i !== 'Camera') {
				var obj = core.objProperty[i],
					objRelativePath = path.relative (basepath, obj.path); // TODO!!!!!
					customloadlua = obj.loadLua;
				
				// replace data path
				customloadlua = customloadlua.replace('"' + obj.path + '"', '"' + objRelativePath + '"');
				
				buf += customloadlua + '\n';
				buf += 'Core():AddRenderObject("'+i+'", root)\n'
				buf += core.GetLuaShader(i, obj.shader, '');
				buf += core.GetLuaTransform(i, obj);
				buf += core.GetLuaVec4s(i, obj.vec4);
				buf += core.GetLuaVec3s(i, obj.vec3);
				buf += core.GetLuaVec2s(i, obj.vec2);
				buf += core.GetLuaFloats(i, obj.float);
				buf += core.GetLuaVec4Arrays(i, obj.vec4array);

				//Shader copy
				copyFile(path.join(shaderspath,obj.shader), path.join(basepath,obj.shader));
				
				// Register
				buf += 'local obj = Core():GetRenderObjectByName("' + i + '");\n';
				//buf += 'sceneRenderObj["' + i + '"] = obj;\n';
				
			}
			buf += 'end\n';
			buf += 'loadFunc()\n';
		}
		buf += 'krender2(sceneRenderObj, {"DummyCamera"}, outputfile, width, height, fsaa)\n';
		return buf;
	}
	
	KVToolsCore.prototype.SyncCameraView = function (cameraName)
	{
		var core = this,
			eye    = render.getEye(),
			lookat = render.getLookat(),
			up     = render.getUp(),
			camera = cameraName; // 'Camera';
			if (!core.objProperty[camera]) {
				console.log("!!Error!!: Not found object:"+camera+". create default camera");
				return;
			}
		var oldeye = core.objProperty[camera].vec3['eye'],
			oldlookat = core.objProperty[camera].vec3['lookat'],
			oldup = core.objProperty[camera].vec3['up'];

		if (oldeye[0] !== eye[0] || oldeye[1] !== eye[1] || oldeye[2] !== eye[2] ||
			oldlookat[0] !== lookat[0] || oldlookat[1] !== lookat[1] || oldlookat[2] !== lookat[2] ||
			oldup[0] !== up[0] || oldup[1] !== up[1] || oldup[2] !== up[2] ){
			//console.log('change camera');
			core.objProperty[camera].vec3['eye']    = [eye[0], eye[1], eye[2]];
			core.objProperty[camera].vec3['lookat'] = [lookat[0], lookat[1], lookat[2]];
			core.objProperty[camera].vec3['up']     = [up[0], up[1], up[2]];
			core.SyncObjectList();
		}
	}
	
	KVToolsCore.prototype.RegisterSocketIO = function(socket){
		this.socket = socket;
		socket.on('message', function(message) {
			
		});
		
		socket.on('KVToolsCore-AddKeyframe',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				name = data.name,
				time = data.time;
				console.log('AddkeyFrame', name, time);
				core.AddKeyframe(name, time);
		}}(this));

		socket.on('KVToolsCore-RemoveKeyframe',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				name = data.name,
				time = parseFloat(data.time);
				console.log('RemovekeyFrame', name, time);
				core.RemoveKeyframe(name, time);
		}}(this));

		socket.on('KVToolsCore-SyncCameraView',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				name = data.name;
			core.SyncCameraView(name);
		}}(this));

		socket.on('KVToolsCore-UpdateTime',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				time = data.time,
				name,
				oldShaders = {};
			
			for (name in core.objProperty) {
				oldShaders[name] = core.objProperty[name].shader;
			}
			
			core.UpdateTime(data.time);
			
			// Update Properties
			for (name in core.objProperty) {
				if (name === 'Camera') {
					var eye = core.objProperty[name].vec3['eye'],
						lookat = core.objProperty[name].vec3['lookat'],
						up = core.objProperty[name].vec3['up'],
						fov = core.objProperty[name].float['fov'],
						nearval = core.objProperty[name].float['near'],
						farval = core.objProperty[name].float['far'];
					render.lookAt(eye[0],eye[1],eye[2],
									lookat[0],lookat[1],lookat[2],
									up[0],up[1],up[2]);
					render.setFov(fov);
					render.setNearFar(nearval, farval);
					//console.log(eye, lookat, up, fov);
				} else {
					var p = core.objProperty[name];
					core.SetTransform(name, p);
					if (oldShaders[name] !== p.shader) {
						core.SetShader(name, p.shader);
					}
					core.SetVec4s(name, p.vec4);
					core.SetVec3s(name, p.vec3);
					core.SetVec2s(name, p.vec2);
					core.SetFloats(name, p.float);
					core.SetVec4Arrays(name, p.vec4array);
				}
			}
			
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-CustomLoadmodel',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				name = data.name,
				bname = path.basename(data.path);
			if (typeof name === 'undefined' || name === '') {
				name = bname;
				while (core.objProperty[name]) {
					name = name + '-2';
				}
			}
			core.CustomLoadModel(name, data.path, data.customlua);

			core.SyncObjectList();
			
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-Loadmodel',function(core){ return function(sdata){
			var data = JSON.parse(sdata),
				name = data.name,
				bname = path.basename(data.path);
			if (typeof name === 'undefined' || name === '') {
				name = bname;
				while (core.objProperty[name]) {
					name = name + '-2';
				}
			}
			core.LoadModel(name, data.path);
			
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		socket.on('KVToolsCore-RemoveModel',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			console.log('REMOVE:'+name);
			var luasrc = 'Core():RemoveRenderObject("'+name+'");';
			render.sceneLua(luasrc);

			core.DeleteObject(name);
			core.SyncObjectList();
			
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-RemoveAllModels',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.closeModel();
			
			core.DeleteAllObjects();
			core.AddCamera();
			core.SyncObjectList();
			
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-Transform', function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var p = { translation:[data.translate_x, data.translate_y, data.translate_z],
					  rotation:[data.rotate_x, data.rotate_y, data.rotate_z],
					  scale:[data.scale_x, data.scale_y, data.scale_z]};
			core.SetTransform(data.name, p);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-mousecommand',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var cmd = data.event;
			var x = data.x;
			var y = data.y;
			if(cmd == "mouseleftdown") {
				//console.log('mouseleftdown('+x+","+y+")");
				render.mouseleftdown(x,y);
			} else if(cmd == "mouseleftup") {
				//console.log('mouseleftup('+x+","+y+")");
				render.mouseleftup(x,y);
			} else if(cmd == "mouserightdown") {
				//console.log('mouserightdown('+x+","+y+")");
				render.mouserightdown(x,y);
			} else if(cmd == "mouserightup") {
				//console.log('mouserightup('+x+","+y+")");
				render.mouserightup(x,y);
			} else if(cmd == "mousemiddledown") {
				//console.log('mousemiddledown('+x+","+y+")");
				render.mousemiddledown(x,y);
			} else if(cmd == "mousemiddleup") {
				//console.log('mousemiddleup('+x+","+y+")");
				render.mousemiddleup(x,y);
			} else if(cmd == "mousemove") {
				//console.log('mousemove('+x+","+y+")");
				render.mousemove(x,y);
			}
			
			// Camera Update
/*			var eye    = render.getEye(),
				lookat = render.getLookat(),
				up     = render.getUp(),
				camera = 'Camera';
				if (!core.objProperty[camera]) {
					console.log("!!Error!!: Not found object:"+camera+". create default camera");
				}
				var oldeye = core.objProperty[camera].vec3['eye'],
					oldlookat = core.objProperty[camera].vec3['lookat'],
					oldup = core.objProperty[camera].vec3['up'];
			
				if (oldeye[0] !== eye[0] || oldeye[1] !== eye[1] || oldeye[2] !== eye[2] ||
					oldlookat[0] !== lookat[0] || oldlookat[1] !== lookat[1] || oldlookat[2] !== lookat[2] ||
					oldup[0] !== up[0] || oldup[1] !== up[1] || oldup[2] !== up[2] ){
					//console.log('change camera');
					core.objProperty[camera].vec3['eye']    = [eye[0], eye[1], eye[2]];
					core.objProperty[camera].vec3['lookat'] = [lookat[0], lookat[1], lookat[2]];
					core.objProperty[camera].vec3['up']     = [up[0], up[1], up[2]];
					core.SyncObjectList();
				}*/
		}}(this));
		
		socket.on('KVToolsCore-SetVec4',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var dataset = {};
			dataset[data.uniformName] = [parseFloat(data.x), parseFloat(data.y), parseFloat(data.z), parseFloat(data.w)];
			core.SetVec4s(name, dataset);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));

		socket.on('KVToolsCore-SetVec3',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var dataset = {};
			dataset[data.uniformName] = [parseFloat(data.x), parseFloat(data.y), parseFloat(data.z)];
			core.SetVec3s(name, dataset);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-SetVec2',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var dataset = {};
			dataset[data.uniformName] = [parseFloat(data.x), parseFloat(data.y)];
			core.SetVec2s(name, dataset);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));
		
		socket.on('KVToolsCore-SetFloat',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var dataset = {};
			dataset[data.uniformName] = parseFloat(data.x);
			core.SetFloats(name, dataset);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));

		socket.on('KVToolsCore-SetVec4Array',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var dataset = {};
			dataset[data.uniformName] = [data.num, data.val];
			core.SetVec4Arrays(name, dataset);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));

		
		socket.on('KVToolsCore-SetShader',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var name = data.name;
			var shader = data.shader;
			core.SetShader(name, shader);
			core.SyncObjectList();
			if (data.redraw) {
				core.Render();
			}
		}}(this));

		socket.on('KVToolsCore-CommitCamera',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			core.CommitCamera(data.name);
			if (data.redraw) {
				core.Render();
			}
		}}(this));

		socket.on('KVToolsCore-RenderMode',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.setRendererMode(data.mode);
			core.Render();
		}}(this));

		socket.on('KVToolsCore-SetPixelStep',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			render.setPixelStep(parseInt(data.step));
			core.Render();
		}}(this));

		socket.on('KVToolsCore-BackGroundColor',function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			core.SetBackGroundColor(data.color);
			core.Render();
		}}(this));
		
		
		socket.on('KVToolsCore-SyncObjectList',function(core){ return function(sdata){
			core.SyncObjectList();
		}}(this));

		socket.on('KVToolsCore-RequestShaderList',function(core){ return function(sdata){
			core.SyncShaderList();
		}}(this));

		socket.on('KVToolsCore-SaveScene', function(core){ return function(sdata){
			var data  = JSON.parse(sdata);
			var fpath = data.filepath;
			 
			var savedata = {objprop:core.objProperty, setting:{}, timeline:core.objTimeline};
			var jsondata = JSON.stringify(savedata);
			fs.writeFile(fpath, jsondata, function (err) {
				if (err){
					console.log('Failed to write scene file:' + fpath);
					return;
				}
				console.log('Saved file:' + fpath);
			});
		}}(this));

		socket.on('KVToolsCore-LoadScene', function(core){ return function(sdata){
			var data = JSON.parse(sdata);
			var fpath = data.filepath;
			
			fs.readFile(fpath, function(core) { return function (err, sdata) {
				if (err){
					console.log('Failed to read scene file:' + fpath);
					return;
				}
				console.log('Loaded file:' + fpath);
				var data;
				try {
					data  = JSON.parse(sdata);
				} catch (e) {
					console.log('Fail to load file:' + fpath, e);
					return;
				}
				// clear
				render.closeModel();
				core.DeleteAllObjects();
			
				// add data
				for (var i in data.objprop) {
					var p = data.objprop[i];
					var fpath = p.path;
					if (fpath !== '') {
						console.log('ADD name = ' + i , 'path = ' + fpath);
						core.LoadModel(i, fpath);
					} else {
						// Maybe camera
						core.AddCamera();
					}
					core.SetTransform(i, p);
					core.SetShader(i, p.shader);
					core.SetVec4s(i, p.vec4);
					core.SetVec3s(i, p.vec3);
					core.SetVec2s(i, p.vec2);
					core.SetFloats(i, p.float);
					core.SetVec4Arrays(i, p.vec4array);
				}
			
				// load properties
				core.objProperty = data.objprop;
				// = data.setting;
				
				if (data.timeline) {
					core.objTimeline = data.timeline;
				} else {
					core.objTimeline = {};
				}
				
				// has default camera?
				if (!core.objProperty['Camera']) {
					core.AddCamera();
				}
				
				// sync with client
				core.SyncShaderList();
				core.SyncObjectList();
				
				core.Render();
			}}(core));


		}}(this));
		
		var toZeroPadding = (function (Number, isNaN, Array) {
			function toZeroPadding (number, limit) {
				number = Number(number);
				if (isNaN(number)) {
					return null;
				}
				return (Array(limit).join('0') + number).slice(-limit);
			}
			return toZeroPadding;
		})(Number, isNaN, Array);
		
		socket.on('KVToolsCore-ExportScene', function(core){ return function(sdata){
			var data  = JSON.parse(sdata);
			var fpath = data.filepath;
			var basepath = path.dirname(fpath);
			var buf  = 'local width  = ' + data.width + ' \n';
				buf += 'local height = ' + data.height + ' \n';
				buf += 'local fsaa = ' + data.antialias + '\n';
			
			var tm, frame,
				fps = parseFloat(data.fps),
				startframe = parseInt(parseFloat(data.startTime) * fps);
				maxframe = parseInt(parseFloat(data.endTime) * fps),
				addCnt = 1;
			if (startframe > maxframe){
				addCnt = -1;
			} else if (startframe === maxframe){
				core.UpdateTime(parseFloat(data.startTime));
				var outputFileName = data.imagefile + data.imageExt;
				console.log('Exporting:' + outputFileName);
				buf += core.genFrameScene2(basepath, outputFileName);
			} else {
				
				for (frame = startframe; frame < maxframe; frame += addCnt) {
					tm = frame / fps;
					core.UpdateTime(tm);
					var outputFileName = data.imagefile + toZeroPadding(frame, 6) + data.imageExt;
					console.log('Exporting:' + outputFileName);
					buf += core.genFrameScene2(basepath, outputFileName);
				} // frame
			}
			
			fs.writeFile(fpath, buf, function(err){
				if (err){
					console.log('Failed to write scene file:'+fpath);
				}
			});
		}}(this));
	}
	
	KVToolsCore.prototype.SyncObjectList = function(){
		this.socket.emit('KVToolsCore-UpdateObjectList',JSON.stringify({objProperty:this.objProperty, objTimeline:this.objTimeline}));
	}
	
	KVToolsCore.prototype.SyncShaderList = function(){
		fs.readdir(shaderspath, function(thisptr){ return function(err,files){
			var shaderList = [];
			for (var i in files){
				var ext = path.extname(files[i]);
				if (ext === '.frag'){
					var imagefile = files[i].replace('.frag','-icon.data');
					var paramfile = files[i].replace('.frag','.json');
					//console.log('paramfile=',paramfile);
					//console.log('imagefile=',imagefile);
					var fragname = files[i];
					var data = '';
					var jparam = '';
					var param=[];
					try {
						data  = fs.readFileSync(shaderspath + '/' + imagefile);
						jparam = fs.readFileSync(shaderspath + '/' + paramfile);
					} catch (e) {
						console.log(fragname + '> file load error:'+e);
					}
					
					try {
						param = JSON.parse(jparam);
					} catch (e) {
						console.log(fragname + '> parse error:' + e);
					}

					//console.log('load fragfile=',data+"");
					shaderList.push({"file":fragname, "image" : data+"", "param" : param});
					
				}
			}
			thisptr.socket.emit('KVToolsCore-UpdateShaderList',JSON.stringify(shaderList));
		}}(this));
	}

	KVToolsCore.prototype.ConsoleLog = function (msg) {
		this.socket.emit('KVToolsCore-ConsoleMessage', JSON.stringify(msg));
	}

	module.exports = KVToolsCore;
	
	
} else { // client.js
	
	var KVToolsCore = function(socket, width, height, renderedFunc){
		this.socket = socket;
		this.data = {};
		this.updateFunc = null;
		this.updateShaderListFunc = null;
		this.consoleMessageFunc = null;
		this.width = width;
		this.height = height;
		
		socket.on('KVToolsCore-UpdateObjectList',function(thisptr){ return function(sdata){
			//console.log('KVToolsCore-UpdateObjectList');
			var data = JSON.parse(sdata);
			thisptr.data = data;
			if (thisptr.updateFunc)
				thisptr.updateFunc(data);
		}}(this));
		socket.on('KVToolsCore-UpdateShaderList',function(thisptr){ return function(sdata){
			var data = JSON.parse(sdata);
			if (thisptr.updateShaderListFunc)
				thisptr.updateShaderListFunc(data);
		}}(this));

		socket.on('KVToolsCore-ConsoleMessage',function(thisptr){ return function(sdata){
			var data = JSON.parse(sdata);
			if (thisptr.consoleMessageFunc)
				thisptr.consoleMessageFunc(data);
		}}(this));

		this.simage = new ServerImager(renderedFunc, function(thisptr,w,h){ return function(){
			thisptr.Render(w,h);
		}}(this,width,height));
	}
	KVToolsCore.prototype.GetObjectList = function(){
		return this.data.objProperty;
	}
	
	KVToolsCore.prototype.SyncObjectList = function(){
		this.socket.emit('KVToolsCore-SyncObjectList',JSON.stringify({}));
	}
	KVToolsCore.prototype.RequestShaderList = function(){
		this.socket.emit('KVToolsCore-RequestShaderList',JSON.stringify({}));
	}
	
	KVToolsCore.prototype.Render = function(w,h){
		if (w && h) {
			this.width = w;
			this.height = h;
		}
		this.simage.Render(this.width, this.height);
	}
	KVToolsCore.prototype.on = function(event, func){
		if (event === 'update') {
			this.updateFunc = func;
		} else if (event === 'updateShaderList') {
			this.updateShaderListFunc = func;
		} else if (event === 'console') {
			this.consoleMessageFunc = func;
		}
	}
	KVToolsCore.prototype.CustomLoadModel = function(modelpath, name, customlua, redraw){
		this.socket.emit('KVToolsCore-CustomLoadmodel',JSON.stringify({path:modelpath,name:name, customlua:customlua, redraw: redraw}));
	}

	KVToolsCore.prototype.LoadModel = function(modelpath, name, redraw){
		this.socket.emit('KVToolsCore-Loadmodel',JSON.stringify({path:modelpath,name:name, redraw: redraw}));
	}
	KVToolsCore.prototype.RemoveModel = function(name, redraw){
		this.socket.emit('KVToolsCore-RemoveModel',JSON.stringify({name:name, redraw: redraw}));
	}
	KVToolsCore.prototype.RemoveAllModels = function(name, redraw){
		this.socket.emit('KVToolsCore-RemoveAllModels',JSON.stringify({redraw: redraw}));
	}

	KVToolsCore.prototype.Mouse = function(mouseevent,x,y){
		this.socket.emit('KVToolsCore-mousecommand',JSON.stringify({event:mouseevent,x:x,y:y}));
	}
	
	KVToolsCore.prototype.SetTransform = function(name,tx,ty,tz,rx,ry,rz,sx,sy,sz, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-Transform', JSON.stringify({
			name:name,
			translate_x:tx,
			translate_y:ty,
			translate_z:tz,
			rotate_x:rx,
			rotate_y:ry,
			rotate_z:rz,
			scale_x:sx,
			scale_y:sy,
			scale_z:sz,
			redraw:redraw
		}));
	}
	
	KVToolsCore.prototype.SetTranslate = function(name,tx,ty,tz, redraw){
		var tobj = this.data.objProperty[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var sx = tobj.scale[0],
			sy = tobj.scale[1],
			sz = tobj.scale[2],
			rx = tobj.rotation[0],
			ry = tobj.rotation[1],
			rz = tobj.rotation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz,redraw);
	}
	KVToolsCore.prototype.SetRotate = function(name,rx,ry,rz, redraw){
		var tobj = this.data.objProperty[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var sx = tobj.scale[0],
			sy = tobj.scale[1],
			sz = tobj.scale[2],
			tx = tobj.translation[0],
			ty = tobj.translation[1],
			tz = tobj.translation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz,redraw);
	}
	KVToolsCore.prototype.SetScale = function(name,sx,sy,sz, redraw){
		var tobj = this.data.objProperty[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		var tx = tobj.translation[0],
			ty = tobj.translation[1],
			tz = tobj.translation[2],
			rx = tobj.rotation[0],
			ry = tobj.rotation[1],
			rz = tobj.rotation[2];
		this.SetTransform(name,tx,ty,tz,rx,ry,rz,sx,sy,sz,redraw);
	}
	
	KVToolsCore.prototype.SetVec4 = function(name, uniformName, x, y, z, w, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetVec4', JSON.stringify({ name: name, uniformName: uniformName, x: x, y: y, z: z, w: w, redraw:redraw }));
	}
	KVToolsCore.prototype.SetVec3 = function(name, uniformName, x, y, z, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetVec3', JSON.stringify({ name: name, uniformName: uniformName, x: x, y: y, z: z, redraw:redraw }));
	}
	KVToolsCore.prototype.SetVec2 = function(name, uniformName, x, y, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetVec2', JSON.stringify({ name: name, uniformName: uniformName, x: x, y: y, redraw:redraw}));
	}
	KVToolsCore.prototype.SetFloat = function(name, uniformName, x, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetFloat', JSON.stringify({ name: name, uniformName: uniformName, x: x, redraw:redraw}));
	}

	KVToolsCore.prototype.SetVec4Array = function(name, uniformName, num, val, redraw){
		if (!this.data.objProperty[name]){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetVec4Array', JSON.stringify({ name: name, uniformName: uniformName, num: num, val: val, redraw:redraw}));
	}

	
	KVToolsCore.prototype.SetShader = function(name,shadername, redraw){
		var tobj = this.data.objProperty[name];
		if (!tobj){
			console.log('not found name:'+name);
			return;
		}
		this.socket.emit('KVToolsCore-SetShader', JSON.stringify({
			name:name,
			shader:shadername,
			redraw:redraw
		}));
	}
	
	KVToolsCore.prototype.CommitCamera = function (name, redraw) {
		this.socket.emit('KVToolsCore-CommitCamera', JSON.stringify({ name:name, redraw:redraw }));
	}
	
	KVToolsCore.prototype.SetRenderMode = function (mode) {
		this.socket.emit('KVToolsCore-RenderMode', JSON.stringify({ mode:mode }));
	}
	
	KVToolsCore.prototype.ExportScene = function (scenepath, wid, hei, anti, imageFile, imageExt, startTime, endTime, fps) {
		this.socket.emit('KVToolsCore-ExportScene', JSON.stringify({ filepath:scenepath,
																	width:wid,
																	height:hei,
																	antialias:anti,
																	imagefile:imageFile,
																    imageExt:imageExt,
																    startTime:startTime,
																    endTime:endTime,
																    fps:fps}));
	}
	
	KVToolsCore.prototype.SaveScene = function (scenepath) {
		this.socket.emit('KVToolsCore-SaveScene', JSON.stringify({ filepath:scenepath }));
	}
	KVToolsCore.prototype.LoadScene = function (scenepath) {
		this.socket.emit('KVToolsCore-LoadScene', JSON.stringify({ filepath:scenepath }));
	}

	KVToolsCore.prototype.SetPixelStep = function (step) {
		this.socket.emit('KVToolsCore-SetPixelStep', JSON.stringify({ step:step }));
	}

	KVToolsCore.prototype.SetImageCompMode = function (mode) {
		this.simage.ChangeCompMode(mode);
		this.Render();
	}

	KVToolsCore.prototype.SetBackGroundColor = function (color) {
		this.socket.emit('KVToolsCore-BackGroundColor', JSON.stringify({ color:color }));
	}

	KVToolsCore.prototype.UpdateTime = function (tm, redraw) {
		this.socket.emit('KVToolsCore-UpdateTime', JSON.stringify({ time:tm, redraw:redraw }));
	}
	KVToolsCore.prototype.AddKeyframe = function (objname, tm) {
		this.socket.emit('KVToolsCore-AddKeyframe', JSON.stringify({ name: objname, time: tm }));
	}
	KVToolsCore.prototype.RemoveKeyframe = function (objname, tm) {
		this.socket.emit('KVToolsCore-RemoveKeyframe', JSON.stringify({ name: objname, time: tm }));
	}

	KVToolsCore.prototype.SyncCameraView = function (cameraName) {
		this.socket.emit('KVToolsCore-SyncCameraView', JSON.stringify({ name: cameraName }));
	}

}
