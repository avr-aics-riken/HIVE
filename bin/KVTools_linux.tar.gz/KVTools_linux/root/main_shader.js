var wid, hei;
var core;

var shaderList = [];

var lastEditedMsec = (new Date).getTime();
var editorChanged = false;
var hasChanged = false;
var gParamHasChanged = false;
var gParamLastEditedMsec = (new Date).getTime();
var gEditorChangedTick = 200; // in milliseconds
var gIconUpdateRequest = false;
var socket;

var opendlg = new filedlg("opensavedialog", true);


// Helper functions
function getUI(id_name) {
	return _kvtools_UIs[id_name];
}

var getTargetShader = function (val) {
	var targetShader = null;
	for (i in shaderList) {
		//console.log('shadername: ' + shaderList[i].shadername + ", val: " + val);
		if (shaderList[i].shadername == val) {
			targetShader = shaderList[i];
		}
	}
	return targetShader;
}

var getShaderParam = function (name) {
	var params = "{}";
	console.log("name: " + name);
	for (i in shaderList) {
		if (shaderList[i].shadername == name) {
			params = shaderList[i].params;
		}
	}

	if (params == "" || params == undefined) {
		params = "{}";
	}

	return params;
}

var updateShaderParam = function (name, params) {
	for (i in shaderList) {
		if (shaderList[i].shadername == name) {
			shaderList[i].params = params;
		}
	}
}

// Create new shader
function newShader(shaderName, shaderType) {
	if (shaderName == "" || shaderName == ".frag") {
		alert("Empty shader name");
		return;
	}
	var msg = {
		'shadername': shaderName,
		'shadertype': shaderType
	}
	socket.emit('shaderEditorNewShader', JSON.stringify(msg));
}

function deleteShader(shadername) {
	if (shadername == "") {
		alert("Empty shader name");
		return;
	}
	var msg = {
		'shadername': shadername
	}
	console.log('delete: ' + shadername);
	socket.emit('shaderEditorDeleteShader', JSON.stringify(msg));
}


function newShaderDialog() {
	$('#newshaderbuttonstate').text(""); // clear form state
	//$('#deleteShaderModal').trigger('closeModal'); // for safety	
	$('#newShaderModal').trigger('openModal');
}

function deleteShaderDialog() {
	$('#deleteshadername').text(""); // clear state
	//$('#newShaderModal').trigger('closeModal');	 // for safety
	$('#deleteShaderModal').trigger('openModal');
}

function clearShaderParameterUI() {
	var pp = document.getElementById('uniformproperty');
	pp.innerHTML = ''; // clear

	kvtoolsUI_update(pp);
}

function constructShaderParameterUI( /* params */ unif) {
	var pp = document.getElementById('uniformproperty');
	pp.innerHTML = ''; // clear

	// Add UIs
	for (i in unif) {
		if (unif[i].ui == 'colorpicker') {
			var paramname = unif[i].name;
			var d = document.createElement('div');
			d.classList.add('ppTable');
			d.innerHTML = '<div class="ppRow">' +
				'<div class="ppCell ppTri"><div class="KCaption">' + unif[i].label + ':</div></div>' +
				'<div class="ppCell"><div class="KColorPicker" id="' + paramname + '"></div></div>' +
				'</div>';
			pp.appendChild(d);
		} else if (unif[i].ui == 'slider') {
			var paramname = unif[i].name;
			var d = document.createElement('div');
			d.classList.add('ppTable');
			d.innerHTML = '<div class="ppRow"><div class="ppCell ppTri">' +
				'<div class="KCaption">' + unif[i].label + ':</div></div>' +
				'<div class="ppCell"><div class="KSlider" id="' + paramname + '"></div>' +
				'</div></div>';
			pp.appendChild(d);
		} else if (unif[i].ui == 'vec3') {
			var paramname = unif[i].name;
			var d = document.createElement('div');
			d.classList.add('ppTable');
			d.innerHTML = '<div class="ppRow">' +
				'<div class="ppCell ppTri"><div class="KCaption">' + unif[i].label + ':</div></div>' +
				'<div class="ppCell"><input class="KInput ppFull" id="' + paramname + '_x" type="number"></div>' +
				'<div class="ppCell"><input class="KInput ppFull" id="' + paramname + '_y" type="number"></div>' +
				'<div class="ppCell"><input class="KInput ppFull" id="' + paramname + '_z" type="number"></div>' +
				'</div>';
			pp.appendChild(d);
		} else if (unif[i].ui == 'transferfunction') {
			var paramname = unif[i].name;
			var d = document.createElement('div');
			d.classList.add('ppTable');
			d.innerHTML = '<div class="ppRow"><div class="ppCell ppTri">' + unif[i].label + '</div></div>'
			pp.appendChild(d);
			d = document.createElement('div');
			d.classList.add('ppTable');
			d.innerHTML = '<div class="ppRow">' +
				'<div class="ppCell" style="width:8px"></div>' +
				'<div class="ppCell">' +
				'<div class="KTransferFunction" id="' + paramname + '"></div>' +
				'</div></div>';
			pp.appendChild(d);
		} else {
			console.log('Error: Unkown UI type -> ' + unif[i].ui + ' - ' + unif[i].name);
		}
	}


	kvtoolsUI_update(pp);

	
	// Reconstruct UI value.
	for (var i in unif) {
		var paramname = unif[i].name;
		console.log(unif[i]);
		if (unif[i].ui === 'colorpicker' && unif[i]['val'] != undefined && getUI(paramname) != undefined) {
			var val = unif[i]['val'];
			getUI(paramname).setColor(val[0], val[1], val[2], val[3]);
			// @todo { reflesh view }
			//getUI(paramname).drawPickPoints();
		} else if (unif[i].ui === 'vec3' && unif[i]['val'] != undefined) {
			var val = unif[i]['val'];
			document.getElementById(paramname + '_x').value = String(val[0]);
			document.getElementById(paramname + '_y').value = String(val[1]);
			document.getElementById(paramname + '_z').value = String(val[2]);
		} else if (unif[i].ui === 'slider' && unif[i]['val'] != undefined && getUI(paramname) != undefined) {
			var val = unif[i]['val'];
			getUI(paramname).setValue(val);
	
			// reflesh view
			getUI(paramname).drawGraph();

		} else if (unif[i].ui === 'transferfunction' && unif[i]['val'] != undefined && getUI(paramname) != undefined) {
			// @fixme { Assume N equals to len(value) }
			var val = unif[i]['val'];
			n = getUI(paramname).getNumValues();
			
			if ((4*n) == val.length) {
				for (k = 0; k < n; k++) {
					var r = val[4*k+0];
					var g = val[4*k+1];
					var b = val[4*k+2];
					var a = val[4*k+3];
					
					getUI(paramname).setGraphValue(k, r, g, b, a);
				}
			}
			
			if (unif[i]['vol_min'] != undefined) {
				getUI(paramname).setMinValue(unif[i]['vol_min'][0]); // fixme
			}

			if (unif[i]['vol_max'] != undefined) {
				getUI(paramname).setMaxValue(unif[i]['vol_max'][0]); // fixme
			}
			
			// reflesh view
			getUI(paramname).drawGraph();
		}
	}

}

function shaderIdleTick( /* ace editor = */ editor, /* socket */ socket) {
	var msec = (new Date).getTime();

	if (hasChanged && ((msec - lastEditedMsec) > gEditorChangedTick)) {
		console.log("update");
		hasChanged = false;
		lastEditedMsec = msec;

		var shadername = document.getElementById('shadername').value;
		msg = {
			'shadername': shadername,
			'code': editor.getValue()
		}

		//console.log(socket);
		socket.emit('shaderEditorCodeUpdate', JSON.stringify(msg));

	}

	window.setTimeout(function () {
		shaderIdleTick(editor, socket);
	}, gEditorChangedTick);
}

function paramIdleTick( /* ace editor = */ editor, /* socket */ socket) {
	var msec = (new Date).getTime();

	if (gParamHasChanged && ((msec - gParamLastEditedMsec) > gEditorChangedTick)) {
		console.log("update");
		gParamHasChanged = false;
		gParamLastEditedMsec = msec;

		var shadername = document.getElementById('shadername').value;
		msg = {
			'shadername': shadername,
			'code': editor.getValue()
		}

		//@TODO
		//console.log(socket);
		//socket.emit('shaderEditorCodeUpdate', JSON.stringify(msg));

	}

	window.setTimeout(function () {
		paramIdleTick(editor, socket);
	}, gEditorChangedTick);
}

function updateShaderCode(code) {
	var editor = ace.edit("shader-editor");
	editor.getSession().setValue(code);
}

function updateParamCode(code) {
	var editor = ace.edit("param-editor");
	editor.getSession().setValue(code);
}

function shaderEditorInit( /* socket.io */ socket) {

	//
	// Setup ACE editor
	//
	console.log(document.getElementById('shader-editor'))
	var editor = ace.edit("shader-editor");
	//editor.setTheme("ace/theme/twilight");
	editor.setTheme("ace/theme/tomorrow_night_bright");
	//	editor.setOption("maxLines", 25); // use CSS setting
	editor.setOption("minLines", 25);
	//editor.setAutoScrollEditorIntoView();
	document.getElementById('shader-editor').style.fontSize = '15px';
	document.getElementById('shader-editor').style.fontFamily = "'Inconsolata', sans-serif"

	// Or read shader code from somewhere.
	editor.getSession().setValue('#ifdef GL_ES\nprecision mediump float;\n#endif\n\nvoid main(void) {\n  gl_FragColor = vec4(1,1,1,1);\n}');
	editor.getSession().setMode("ace/mode/glsl");
	editor.getSession().setTabSize(2)
	editor.getSession().setUseSoftTabs(true);
	editor.getSession().setUseWrapMode(true);

	var statusWindow = ace.edit("status-window");
	statusWindow.setTheme("ace/theme/twilight");
	//	statusWindow.setOption("maxLines", 8);  // use CSS setting
	statusWindow.setOption("minLines", 8);
	statusWindow.renderer.setShowGutter(false);
	//editor.setAutoScrollEditorIntoView();
	document.getElementById('status-window').style.fontSize = '15px';
	document.getElementById('status-window').style.fontFamily = "'Inconsolata', sans-serif"
	statusWindow.getSession().setValue("OK");
	statusWindow.getSession().setMode("ace/mode/glsl");
	statusWindow.getSession().setTabSize(2)
	statusWindow.getSession().setUseSoftTabs(true);
	statusWindow.getSession().setUseWrapMode(true);
	statusWindow.setReadOnly(true);


	editor.getSession().on('change', function (e) {
		hasChanged = true;
		lastEditedMsec = (new Date).getTime();

		//console.log("change");
	});

	window.setTimeout(function () {
		shaderIdleTick(editor, socket);
	}, gEditorChangedTick);

}

function paramEditorInit( /* socket.io */ socket) {

	//
	// Setup ACE editor
	//
	var elem_id = 'param-editor';
	console.log(document.getElementById(elem_id))
	var e = ace.edit(elem_id);
	//editor.setTheme("ace/theme/twilight");
	e.setTheme("ace/theme/tomorrow_night_bright");
	//	editor.setOption("maxLines", 25); // use CSS setting
	e.setOption("minLines", 25);
	//editor.setAutoScrollEditorIntoView();
	document.getElementById(elem_id).style.fontSize = '15px';
	document.getElementById(elem_id).style.fontFamily = "'Inconsolata', sans-serif"

	// Or read shader code from somewhere.
	e.getSession().setValue("");
	e.getSession().setMode("ace/mode/javascript");
	e.getSession().setTabSize(2)
	e.getSession().setUseSoftTabs(true);
	e.getSession().setUseWrapMode(true);

	console.log("worker : " + e.getSession().$worker);

	// NOTE:
	// 'javascript' mode in ace editor does syntax checking by default.
	// maybe getSession().setUseWorkers(false) disables syntax checking.
	//

	e.getSession().on('changeAnnotation', function () {
		//hasChanged = true;
		//lastEditedMsec = (new Date).getTime();

		//console.log("change");

		var annotations = e.getSession().getAnnotations();

		if (annotations == 0) {
			// No error found.

			// Requst saving JSON param
			var params = e.getSession().getValue();
			if (params != "" && params != "{}") {
				console.log(params);
				var shadername = document.getElementById('shadername').value;
				msg = {
					'shadername': shadername,
					'params': params, // string
				}
				//console.log("saving..." + msg);

				socket.emit('shaderEditorSaveParam', JSON.stringify(msg));

				// Also store shader param in memory.
				updateShaderParam(shadername, params);

				// Update UI
				var jparams = JSON.parse(params);
				constructShaderParameterUI(jparams.uniforms);
			}
		}
	});
}

document.oncontextmenu = function (e) {
	return false
}

window.onload = function () {
	kvtoolsUI_init();

	// Init socket io
	socket = io.connect();

	// ACE editor marker needs to be explicitly managed by app
	var editorMarkers = []


	// render canvas size
	wid = 300;
	hei = 300;
	document.getElementById('result').width = wid;
	document.getElementById('result').height = hei;
	document.getElementById('tmp').width = wid;
	document.getElementById('tmp').height = hei;

	function renderedFunc(buf) {
		var buffer = new Uint8Array(buf.data);
		var rc = document.getElementById('result');
		var tcan = document.getElementById('tmp')
		var rctx = rc.getContext('2d');
		var tctx = tcan.getContext("2d");
		var rimageData = tctx.createImageData(wid, hei);
		var pixels = rimageData.data;
		pixels.set(buffer, 0, buffer.length);
		rctx.fillRect(0, 0, rc.width, rc.height);
		tctx.putImageData(rimageData, 0, 0);
		rctx.drawImage(tcan, 0, 0);

		if (gIconUpdateRequest) {

			console.log('iconU');

			// Save canvas as DataURL png.
			var pngData = rc.toDataURL();

			var shadername = document.getElementById('shadername').value; // NOTE: absolutepath
			var msg = {
				'shaderpath': shadername,
				'dataURL': pngData
			};

			socket.emit('shaderEditorIconImage', JSON.stringify(msg));

			gIconUpdateRequest = false;

			console.log('iconU end');
		}
	}

	//
	// Socket.io
	//
	socket.on('connect', function () {
		console.log('socket.io connected');

		// Request shader browser reflesh
		socket.emit('shaderEditorRefreshShaderBrowser', "");
	});

	// New shader event from the server
	socket.on('shaderNewAck', function ( /* JSON str */ data) {
		var msg = JSON.parse(data);

		if (msg['status'] != 'ok') {
			alert(msg['message']);
		} else {
			// OK.
			console.log("shader new ok");

			// Request shader browser reflesh
			socket.emit('shaderEditorRefreshShaderBrowser', "");
		}

	});

	// Delete shader 
	socket.on('shaderDeleteAck', function ( /* JSON str */ data) {
		var msg = JSON.parse(data);

		if (msg['status'] != 'ok') {
			alert(msg['message']);
		} else {
			// OK.
			console.log("shader delete ok");

			// Request shader browser reflesh
			socket.emit('shaderEditorRefreshShaderBrowser', "");

		}
	});

	// Shader brower update request from the server
	socket.on('shaderBrowserData', function ( /* JSON str */ msg) {
		//console.log('browser:' + msg);
		var files = JSON.parse(msg);

		// Assume msg is list type.

		for (var i = 0; i < files.length; i++) {
			console.log('file:' + files[i]);
		}


		// Save to global 
		shaderList = [];
		for (var i in files) {
			shaderList.push(files[i]);
		}

		//var t = window.getElementById('shader-browser');

		var rr = $("#shader-browser table")

		// Remove existing list.
		rr.empty();

		// Append shader file item
		for (var i = 0; i < files.length; i++) {
			//console.log('icon:' + files[i]['icon-dataURL']);

			var escape_shadername = files[i]['shadername'].replace(".", "_");
			console.log(escape_shadername);
			var tag = '<tr><td id="shaderitem_' + escape_shadername + '"><img src="' + files[i]['icon-dataURL'] + '" width=64 height=64>' + files[i]['shadername'] + '</td></tr>';
			rr.append(tag);
		}

		// Highlight current shader file item

		// de-Highlight previos item.				
		$("#shader-browser tr td").each(function () {
			$(this).css('background-color', 'rgba(0,0,0,0)');
		});

		var shadername = document.getElementById('shadername').value;
		var escape_shadername = shadername.replace(".", "_");
		//console.log($('#shader-browser table tr').find('shadername_'+shadername));
		//console.log($('#shader-browser table tr').find("#shadername_*").css('background-color', 'rgba(128,1,0,0.5)'));
		$('#shaderitem_' + escape_shadername).css('background-color', 'rgba(128,1,0,0.5)');

		// Construct param UI for selected shader.
		clearShaderParameterUI();
		for (var i = 0; i < files.length; i++) {
			if (files[i]['shadername'] == shadername) {
				if (files[i]['params'] != "") {
					//console.log("xyz");
					var jparam = JSON.parse(files[i]['params']);
					if (jparam != undefined) {
						//console.log('params: ' + jparam.uniforms);
						constructShaderParameterUI(jparam.uniforms);
					}

					// update param editor
					updateParamCode(files[i]['params']);
				} else {
					// No param file? Fill with empty JSON
					updateParamCode("{}");
				}
			}
		}

		// Install event to table row
		$(function () {
			$("#shader-browser tr td").click(function (event) {
				// text() is shader filename.
				var shadername = $(this).text();

				// de-Highlight previos item.				
				$("#shader-browser tr td").each(function () {
					$(this).css('background-color', 'rgba(0,0,0,0)');
				});

				// Highlight selected item.
				$(this).css('background-color', 'rgba(128,1,0,0.5)');

				// Save shader filename.
				document.getElementById('shadername').value = shadername;

				// Notify the server for shader file changed.
				var msg = {
					'filename': shadername
				}
				socket.emit('shaderEditorFileChanged', JSON.stringify(msg));

			});
		});

	});

	// Shader code from the server.
	socket.on('shaderEditorCode', function ( /* JSON str */ msg) {
		var j = JSON.parse(msg);
		//console.log('shdcode:' + j['code']);
		if (j['status'] == 'ok') {
			updateShaderCode(j['code']);

			var shadername = document.getElementById('shadername').value;
			updateParamCode(getShaderParam(shadername));

			var jparam = JSON.parse(getShaderParam(shadername));
			constructShaderParameterUI(jparam.uniforms);

		} else {
			console.log('code err:' + msg['error']);
		}
	});

	// Shader compile result from the server.
	socket.on('shaderEditorCompileStatus', function ( /* JSON str */ msg) {

		var j = JSON.parse(msg);

		// First remove markers and clear annotations
		var editor = ace.edit("shader-editor");

		for (var i = 0; i < editorMarkers.length; i++) {
			editor.getSession().removeMarker(editorMarkers[i]);
		}
		editorMarkers = []
		editor.getSession().clearAnnotations();

		if (j['status'] == 'compile_error') {

			var results = j['info']['results']
			var annotations = []

			var range = ace.require('ace/range').Range;

			for (var i = 0; i < results.length; i++) {

				var ret = results[i];

				var lineno = ret['lineno'] - 1
				var column = ret['column']

				var annotation = {
					row: lineno,
					column: column,
					text: ret['error'],
					type: 'error'
				}
				annotations.push(annotation);

				var r = new range(lineno, column, lineno, 80);
				var marker = editor.getSession().addMarker(r, 'error', "line");
				editorMarkers.push(marker);
			}

			editor.getSession().setAnnotations(annotations);

		}

		// Update status window
		var statusWindow = ace.edit("status-window");
		if (j['status'] == 'ok') {
			statusWindow.getSession().setValue("OK")

			// Set shader
			var shadername = document.getElementById('shadername');
			console.log(shadername.value);
			core.SetShader('teapot', shadername.value);

			// Request icon update
			gIconUpdateRequest = true;

		} else {
			// Show compile log to statusWindow.
			var info = j['info'];
			statusWindow.getSession().setValue(info['log'])
		}

	});

	//
	// --
	//
	opendlg.registerSocketEvent(socket);

	core = new KVToolsCore(socket, wid, hei, renderedFunc);

	// This setTimeout function is HACK. Renderer's first makeContext will take some time.
	// send command Redraw with model load a little later.
	setTimeout(function () {
		core.RemoveModel('teapot'); // remove old model
		core.LoadModel('./teapot.obj', 'teapot', true);
	}, 500);

	// Events
	var rmode = "OPENGL";
	core.SetRenderMode(rmode); // set default mode.

	$('#rendermodebtn').html(rmode);
	$('#rendermodebtn').click(function () {
		if (rmode === "OPENGL") {
			rmode = "LSGL";
		} else {
			rmode = "OPENGL";
		}
		$('#rendermodebtn').html(rmode);
		core.SetRenderMode(rmode);
	});

	$('#loadmodelbtn').click(function () {
		opendlg.OpenFile('', function (filepath) {
			//console.log(filepath);
			core.RemoveModel('teapot'); // remove old model
			core.LoadModel(filepath, 'teapot');

			var shadername = document.getElementById('shadername');
			core.SetShader('teapot', shadername.value, true);
		});
	});

	var emode = 'GLSL';
	$('#editmodebtn').html(emode);
	$('#editmodebtn').click(function () {
		if (emode === "GLSL") {
			emode = "PARAM";
			$('#shader-editor').css('visibility', 'hidden');
			$('#param-editor').css('visibility', 'visible');
		} else {
			emode = "GLSL";
			$('#param-editor').css('visibility', 'hidden');
			$('#shader-editor').css('visibility', 'visible');
		}
		$('#editmodebtn').html(emode);
	});

	$('#shaderchangebtn').click(function () {
		var shadername = document.getElementById('shadername');
		core.SetShader('teapot', shadername.value);

		// Notify the server for shader file changed.
		var msg = {
			'filename': shadername.value
		}
		socket.emit('shaderEditorFileChanged', JSON.stringify(msg));
	});

	// Init editors and browser.
	paramEditorInit(socket);
	shaderEditorInit(socket);

	$('#updatebutton').click(function () {

		var shadername = document.getElementById('shadername').value;

		// Uniform UIs
		var targetShader = getTargetShader(shadername);
		if (targetShader === null)
			return;

		if (targetShader['params'] == null || targetShader['params'] == "") {
			return;
		}

		var jparam = JSON.parse(targetShader['params']);
		var unif = jparam.uniforms;

		// Send parameter to the renderer. 
		// Also store current UI status into JSON param.
		var name = 'teapot'; // @fixme
		for (var i in unif) {
			var paramname = unif[i].name;
			console.log(unif[i]);
			if (unif[i].ui === 'colorpicker') {
				var col = getUI(paramname).getColor();
				core.SetVec4(name, paramname, col[0], col[1], col[2], col[3], true);
				unif[i]['val'] = [col[0], col[1], col[2], col[3]];
			} else if (unif[i].ui === 'vec3') {
				var tx = parseFloat(document.getElementById(paramname + '_x').value);
				var ty = parseFloat(document.getElementById(paramname + '_y').value);
				var tz = parseFloat(document.getElementById(paramname + '_z').value);
				core.SetVec3(name, paramname, tx, ty, tz);
				unif[i]['val'] = [tx, ty, tz];
			} else if (unif[i].ui === 'slider') {
				var v = getUI(paramname).getValue();
				core.SetFloat(name, paramname, v, true);
				unif[i]['val'] = v;
			} else if (unif[i].ui === 'transferfunction') {
				var v_r = getUI(paramname).getGraphValueRed(),
					v_g = getUI(paramname).getGraphValueGreen(),
					v_b = getUI(paramname).getGraphValueBlue(),
					v_a = getUI(paramname).getGraphValueAlpha(),
					n = getUI(paramname).getNumValues(),
					v_min = getUI(paramname).getMinValue(),
					v_max = getUI(paramname).getMaxValue();

				// TODO
				var k, v4 = [4 * k];
				for (k = 0; k < n; ++k) {
					v4[4 * k] = v_r[k];
					v4[4 * k + 1] = v_g[k];
					v4[4 * k + 2] = v_b[k];
					v4[4 * k + 3] = v_a[k];
				}
				core.SetVec4Array(name, paramname, n, v4);
				console.log('TRASNFERFUNC', v_min, v_max);
				core.SetVec3(name, 'vol_min', [v_min, v_min, v_min]);
				core.SetVec3(name, 'vol_max', [v_max, v_max, v_max]);
				//console.log(unif[i]);
				unif[i]['val'] = v4;
				unif[i]['vol_min'] = [v_min, v_min, v_min];
				unif[i]['vol_max'] = [v_max, v_max, v_max];

			}

			// Update shader param editor
			updateParamCode(JSON.stringify(jparam));
		}
	});

	var view = document.getElementById('result');
	view.addEventListener('mousedown', function (e) {
		var press = true;
		e.preventDefault();
		e.stopPropagation();
		if (e.button == 0)
			core.Mouse('mouseleftdown', e.clientX, e.clientY);
		else if (e.button == 1)
			core.Mouse('mousemiddledown', e.clientX, e.clientY);
		else if (e.button == 2)
			core.Mouse('mouserightdown', e.clientX, e.clientY);

		var mmove = function (e) {
			if (press) {
				core.Mouse('mousemove', e.clientX, e.clientY);
				core.Render(wid, hei);
			}
		}
		var mup = function (e) {
			document.removeEventListener('mousemove', mmove);
			document.removeEventListener('mouseup', mup);
			press = false;
			core.Mouse('mouseleftup', e.clientX, e.clientY);
			core.Mouse('mousemiddleup', e.clientX, e.clientY);
			core.Mouse('mouserightup', e.clientX, e.clientY);
		}
		document.addEventListener('mousemove', mmove);
		document.addEventListener('mouseup', mup);

	});
}