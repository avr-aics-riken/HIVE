if (typeof (window) === 'undefined') { // node.js

	var glob = require('glob');
	var exec = require('child_process').exec;
	var fs = require('fs');
	var path = require('path');
	var os = require('os');
	var shaderBasePath = path.join(__dirname, '../shader'); // Assume current dir is krender/root. @todo: move kvtools.js


	// List shader file in the specified directory.
	function ListUpShaderFiles(callback) {
		var options = {}

		glob(path.join(shaderBasePath, "*.frag"), function (err, files) {
			if (err) {
				console.log("glob err:" + err);
			}

			var validFiles = []
			for (var i = 0; i < files.length; i++) {
				var pos = files[i].search("tmp.frag");
				if ((pos > -1) && ((pos + "tmp.frag".length) == files[i].length)) { // last match
					// tmp shader file. ignore
				} else {
					var shadername = path.basename(files[i], '.frag');
					var iconfilename = path.join(shaderBasePath, shadername + "-icon.data");
					var paramfile = path.join(shaderBasePath, shadername + ".json");
					var params = ""

					if (fs.existsSync(paramfile)) {
						params = fs.readFileSync(paramfile, 'utf-8');
						console.log('params:' + params);
					}

					var iconDataURL = undefined;
					if (fs.existsSync(iconfilename)) {
						console.log('got iconfile');
						iconDataURL = fs.readFileSync(iconfilename, 'utf-8'); // in DataURL format.
					}

					validFiles.push({
						'shadername': path.basename(files[i]),
						'params': params, // JSON formatted text
						'icon-dataURL': iconDataURL
					});
				}

			}

			//console.log(validFiles);

			callback(validFiles);
		});

	}

	function ExtractCompilerError(log) {
		var infos = {}
		infos['results'] = []
		infos['log'] = log

		lines = log.split(/(\r?\n)/g);
		//console.log('lines:' + lines);

		for (var i = 0; i < lines.length; i++) {
			var line = lines[i]
				//console.log('line:' + line);
			var reRange = /(\d+):(\d+)\((\d+)\): (\w.+): (.*)/
			var ret = reRange.exec(line)

			if (ret != null) {
				var lineno = ret[2]
				var column = ret[3]
				var err = ret[5]

				var info = {
					'lineno': lineno,
					'column': column,
					'error': err
				}
				infos['results'].push(info);
			}

			//console.log(ret);
		}
		return infos
	}

	// Compile shader code and return its log to callback
	function CompileShader( /* string */ shadername, /* string */ code, callback) {

		// Get GLSL compiler from ENV.
		var glslc = process.env.GLSL_COMPILER
		if (glslc == undefined) {
			console.log('GLSL_COMPILER is not set.');
			callback({
				'status': 'error',
				'log': 'GLSL_COMPILER is not set.'
			});
		}

		if (shadername == undefined) {
			var filename = path.join(shaderBasePath, 'input.tmp.frag');
		} else {
			var filename = path.join(shaderBasePath, shadername);
		}

		// Write temporary file
		fs.writeFileSync(filename, code);

		// Code suggestion features.
		var codeSuggestion,
			fnd = code.indexOf('#if LSGL_ES'); // search #if LSGL_ES
		if (fnd !== -1) {
			var fndstr = code.substr(0, fnd);
			var linenumber = (fndstr.split("\n").length);
			codeSuggestion = '\n0:' + linenumber + '(0): error: Found directive "#if LSGL_ES". You have to use -> "#ifdef LSGL_ES"\n';
		}
		if (codeSuggestion) {
			callback({
				'status': 'compile_error',
				'info': ExtractCompilerError('[Editor suggestion]\n' + codeSuggestion)
			});
			return;
		}

		// glsl_compiler --dump-lir input.frag
		var platformName, binext = '';
		if (os.platform() === 'darwin') {
			platformName = 'macosx64';
		} else if (os.platform() === 'linux') {
			platformName = 'linux_x64';
		} else if (os.platform().indexOf('win') === 0) {
			platformName = 'windows_x64';
			binext = '.exe';
		}
		var glcmd = path.dirname(glslc) + '/bin/' + platformName + '/glsl_compiler' + binext + ' --dump-lir ' + filename;

		var cmd = glslc + ' ' + filename;
		var c = exec(cmd, function (error, stdout, stderr) {
			console.log('stdout: ' + stdout);
			console.log('stderr: ' + stderr);
			if (error) {
				console.log('error: ' + error);
				callback({
					'status': 'compile_error',
					'info': ExtractCompilerError('[LSGL Shader Compile Error]\n' + stdout)
				});
			} else {
				c = exec(glcmd, function (error, stdout, stderr) {
					console.log('stdout: ' + stdout);
					console.log('stderr: ' + stderr);
					if (error) {
						console.log('error: ' + error);
						callback({
							'status': 'compile_error',
							'info': ExtractCompilerError('[OpenGL Shader Compile Error]\n' + stdout)
						});
					} else {
						callback({
							'status': 'ok'
						});
					}
				});
			}
		});
	}

	var shadereditor = {
		SocketEvent: function (socket) {

			socket.on('shaderEditorEvent', function (data) {
				console.log(data);
			});

			socket.on('shaderEditorNewShader', function ( /* JSON str */ data) {
				var j = JSON.parse(data);

				var pos = j['shadername'].search(".frag");
				if ((pos > -1) && ((pos + ".frag".length) == j['shadername'].length)) { // last match
					// Valid filename.
				} else {
					var msg = {
						'status': 'error',
						'message': 'Invalid shader filename: ' + j['shadername']
					};
					socket.emit('shaderNewAck', JSON.stringify(msg));
					return;
				}

				var filename = path.join(shaderBasePath, j['shadername']);

				// Check file exists.
				if (fs.existsSync(filename)) {
					console.log('file exists');

					var msg = {
						'status': 'error',
						'message': 'Shader file already exists: ' + j['shadername']
					};
					socket.emit('shaderNewAck', JSON.stringify(msg));
					return;
				}

				var s = '#ifdef GL_ES\nprecision mediump float;\n#endif\n\nvoid main(void) {\n  gl_FragColor = vec4(1,1,1,1);\n}';
				fs.writeFileSync(filename, s);

				var msg = {
					'status': 'ok',
					'message': 'Success to create shader file: ' + j['shadername']
				};
				socket.emit('shaderNewAck', JSON.stringify(msg));

			});

			socket.on('shaderEditorDeleteShader', function ( /* JSON str */ data) {

				console.log('del');

				var j = JSON.parse(data);

				var filename = path.join(shaderBasePath, j['shadername']);

				// Check file exists.
				if (fs.existsSync(filename)) {

					fs.unlinkSync(filename);

					if (fs.existsSync(filename)) { // maybe a permission problem?
						var msg = {
							'status': 'error',
							'message': 'Failed to delete shader file: ' + j['shadername']
						};

						socket.emit('shaderDeleteAck', JSON.stringify(msg));
					} else {

						// Remove icon file.
						var iconfilename = path.join(shaderBasePath, j['shadername'] + "-icon.data");
						fs.unlink(iconfilename); // @todo { check if icon file was deleted finely. }

						var msg = {
							'status': 'ok',
							'message': 'Deleted shader file: ' + j['shadername']
						};

						socket.emit('shaderDeleteAck', JSON.stringify(msg));
					}
				} else {
					var msg = {
						'status': 'error',
						'message': 'Shader file not found: ' + j['shadername']
					};

					socket.emit('shaderDeleteAck', JSON.stringify(msg));
				}
			});

			socket.on('shaderEditorSaveParam', function ( /* JSON str */ data) {
				var j = JSON.parse(data);
				//console.log(j);
				//return;

				var shaderbasename = path.basename(j['shadername'], '.frag');
				var paramfilename = shaderbasename + '.json';

				fs.writeFileSync(path.join(shaderBasePath, paramfilename), j['params']);
				console.log("saved:" + paramfilename);
			});

			socket.on('shaderEditorIconImage', function ( /* JSON str */ data) {
				var j = JSON.parse(data);

				console.log(j['shaderpath']);
				console.log(j['dataURL']);

				// /a/b/c/d.frag -> d-icon.data
				var filename = path.basename(j['shaderpath'], '.frag') + '-icon.data';
				//console.log('filename: ' + filename);
				//console.log("icon-path:" + path.join(shaderBasePath, filename));
				fs.writeFileSync(path.join(shaderBasePath, filename), j['dataURL']);

				// Refresh shader browser.
				ListUpShaderFiles(function (files) {
					socket.emit('shaderBrowserData', JSON.stringify(files));
				});

			});

			socket.on('shaderEditorRefreshShaderBrowser', function ( /* JSON str */ data) {
				ListUpShaderFiles(function (files) {
					socket.emit('shaderBrowserData', JSON.stringify(files));
				});
			});

			socket.on('shaderEditorFileChanged', function ( /* JSON str */ data) {
				var j = JSON.parse(data);
				console.log('filename:' + j['filename']);

				var filepath = path.join(shaderBasePath, j['filename'])
				console.log('filepath:' + filepath);

				fs.readFile(filepath, 'utf8', function (error, data) {
					if (err || (data == undefined)) {
						var stat = 'error'
						var err = 'File not found or read error:' + j['filename'];

						console.log(err);

						var msg = {
							'status': stat,
							'error': err
						}
						socket.emit('shaderEditorCode', JSON.stringify(msg));
					} else {
						console.log('code:' + data);
						var msg = {
							'status': 'ok',
							'shadername': j['filename'],
							'code': data
						}
						socket.emit('shaderEditorCode', JSON.stringify(msg));
					}
				});

			});

			socket.on('shaderEditorCodeUpdate', function ( /* JSON str */ data) {
				var j = JSON.parse(data);
				console.log('shadername:' + j['shadername']);
				console.log('code:' + j['code']);
				//console.log('param:' + j['param']);

				CompileShader(j['shadername'], j['code'], function (ret) {
					//console.log('ret_xyz=' + JSON.stringify(ret));
					socket.emit('shaderEditorCompileStatus', JSON.stringify(ret));
				});
			});
		}
	}

	module.exports = shadereditor;

} else { // client side js

	var shadereditor = {}

}